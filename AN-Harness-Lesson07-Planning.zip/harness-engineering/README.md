# 7교시 실습 자료

**AI Native 소프트웨어 개발: Harness Engineering — 학습 가이드북**

`07_planning_execution_preview.html`을 브라우저에서 열거나 `07_planning_execution.md`를 읽으며 시작합니다. 폴더·파일·ps1·Python 보조 도구의 설명은 가이드북 3절과 `07_files_commands.md`에 있습니다.

ZIP의 `harness-engineering` 폴더를 `C:\AI-Native`에 합칩니다. `lesson07.ps1`이 기존 `compose.yaml`과 같은 폴더에 있어야 합니다. 개인 workspace·records·인증 정보·Compose·공통 CSV는 ZIP에 포함되지 않습니다.

6교시 완료 상태에서 prepare로 시작합니다. 실제 SPEC와 인수조건을 이어받고, 현재 단계의 경계·인덱스·빈 PLAN·요청을 준비합니다. 모델과 입력 데이터는 그대로 사용합니다.

계획 작성 → 사람 검토 → P1만 승인 → 입력 검사 구현 → 세 사례 실행 → 기록 보관 순서로 진행합니다. 기록은 `records/lesson07/plan_review.md` 하나를 단계마다 채웁니다. `examples`의 예시는 실제 7교시 실행 결과를 대신하지 않습니다.

실수로 처음부터 시작해야 할 때만 가이드북 7)의 restore를 사용합니다. 복원 후에는 prepare를 반복하지 않고 컨테이너 시작, 새 Chat, check start를 거쳐 단계 2부터 진행합니다.
