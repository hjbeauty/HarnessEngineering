# 7교시. Planning & Controlled Execution — 계획한 범위만 구현하고 확인하기

**AI Native 소프트웨어 개발: Harness Engineering — 학습 가이드북**

## 1) 이번 교시에서 해결할 문제

**명세가 준비됐으니 “전부 구현해 주세요”라고 요청하면 될까요?**

6교시에서는 무엇을 만들고 어떤 결과를 확인할지 정했습니다. 이번에는 그 약속을 어떤 순서로 구현하고, 어디에서 멈춰 확인할지 정합니다. 한 번에 많은 파일을 만들면 무엇 때문에 실패했는지 찾기 어려워집니다. 그래서 먼저 계획을 읽고, 작은 범위만 승인한 다음 실제 실행 결과를 확인합니다.

구현 계획을 저장하는 파일의 이름은 `PLAN.md`입니다. 계획은 **P1 입력 검사, P2 계산과 보고서 생성, P3 다양한 입력으로 추가 검사**의 세 부분으로 나눕니다. P1·P2·P3은 이 실습에서 붙인 단계 이름입니다.

이번에는 `PLAN.md`에 전체 구현 순서를 적고 **P1 입력 검사만** 승인합니다. Agent가 판매 분석 프로그램인 `analyze_sales.py`의 입력 검사 부분을 작성하면, 다음 세 가지 상황에서 실행해 봅니다.

| 입력 사례 | 프로그램에 주는 입력 | 확인하려는 동작 |
|---|---|---|
| 정상 데이터 | 판매 기록 10행이 담긴 `sales_micro.csv` | 10행을 모두 읽고 입력이 정상이라고 알리는가? |
| 수량이 0인 데이터 | 수량이 0인 행이 포함된 `quantity_zero.csv` | 수량은 1 이상이어야 한다는 규칙에 따라 오류 위치와 이유를 알리고 멈추는가? |
| 존재하지 않는 파일 | 실제로 없는 파일의 경로 | 파일을 찾을 수 없다고 알리고 멈추는가? |

세 입력으로 프로그램을 실행하고 결과를 기록하는 **수업용 검사기**를 제공합니다. 세 번째 사례는 파일을 새로 만드는 작업이 아닙니다. 검사기가 존재하지 않는 경로를 프로그램에 전달해 파일이 없을 때의 처리를 확인합니다. 세 사례 모두 **미리 준비한 보존 확인용 파일**의 내용이 유지되는지도 함께 확인합니다. 프로그램 실행 때문에 다른 작업 결과가 바뀌지 않는지 살펴보기 위한 파일입니다. 이렇게 입력을 받아들이거나 거부하는 동작부터 확인한 뒤, 계산과 보고서 생성은 다음 구현 단계의 계획으로 남깁니다.

## 2) 학습목표와 완료 상태

프로그램이 끝나며 반환하는 숫자를 **종료코드**, 실행한 명령과 결과를 남긴 기록을 **실행 로그**라고 합니다. 실수했을 때 돌아갈 준비 직후의 시작 상태는 **진입점**이라고 부릅니다.

| 이번에 할 수 있게 되는 일 | 남길 결과 |
|---|---|
| 명세를 변경 대상과 확인 방법이 있는 계획으로 나눈다 | P1·P2·P3을 정리한 PLAN.md |
| 전체 계획 중 실행할 범위만 승인한다 | P1 승인 기록과 승인 당시 계획 사본 |
| 계획과 실제 변경을 대조한다 | analyze_sales.py와 파일·설정 검사 기록 |
| 종료코드·오류 메시지·파일 보존을 함께 확인한다 | 세 사례의 실행 로그와 관찰 기록 |
| 실수했을 때 시작 상태로 돌아가는 방법을 설명한다 | 진입점과 복원 절차 |

6교시에서 작성한 **인수조건(AC, Acceptance Criteria)**은 “어떤 행동을 했을 때 어떤 결과가 나오면 요구를 만족한 것으로 볼 것인가”를 정한 기준입니다. 세 조건의 이름과 뜻은 다음과 같습니다.

| 인수조건 | 확인할 내용 |
|---|---|
| AC-01 정상 입력 | 정상 판매 데이터를 계산해 정해진 값과 형식으로 결과 파일을 만드는가 |
| AC-02 오류와 기존 출력 보존 | 잘못된 입력에서 오류를 알리고, 전에 만들어 둔 결과 파일을 유지하는가 |
| AC-03 반복 실행 | 같은 프로그램과 환경에서 같은 입력으로 다시 실행하면 결과 파일 내용이 같은가 |

**이번 완료 상태는 ‘계획과 P1의 첫 실행 확인’입니다.** 총매출 56,000원과 보고서 두 파일을 생성하는 AC-01, 정상 분석 결과를 사용하는 AC-02 전체, 반복 실행의 AC-03은 P2 구현 이후에 확인할 계획으로 남깁니다. 전체 명세의 완료를 이번 P1 통과와 혼동하지 않습니다.

## 3) 시작 전 준비와 파일의 역할

### 3.1 6교시에서 무엇을 이어받나요?

시작 전에 6교시의 `CHECK_PASS: final`과 `BASELINE_INTEGRITY_PASS`, `draft_response.md`·`specified_response.md`·세션 JSON·`spec_review.md`의 저장 여부를 확인합니다. Docker Desktop을 실행해 둡니다.

`SPEC.md`는 프로그램이 지킬 규칙을 적은 명세입니다. **Context**는 Agent가 참고하는 업무 배경·환경·작성 규칙 문서입니다.

| 이어받는 것 | 7교시에서 사용하는 이유 |
|---|---|
| workspace/SPEC.md | 입력·계산·출력·오류 규칙을 다시 추측하지 않고 계획의 근거로 사용 |
| context의 업무·작성 관례·환경 문서 | 단가의 의미와 작성 규칙, 실행 장소를 유지 |
| records/lesson06/spec_review.md의 4절 | 직접 작성한 AC-01·AC-02·AC-03을 구현 계획에 연결 |
| inputs의 공통 CSV | 같은 데이터로 단계별 결과를 비교 |
| 3교시 Baseline과 앞 교시 기록 | 최초 실행의 응답·조건·증거를 보관한 비교 기준을 유지 |

준비 도구는 **실제로 사용하던 SPEC와 Context를 복사해 이어받습니다.** 그중 읽을 문서와 순서를 안내하는 `CONTEXT_INDEX.md`와 변경 가능한 범위를 정하는 `context/constraints.md`는 “문서 검토만 하는 6교시”에서 “계획 작성과 승인 후 P1 구현을 하는 7교시”의 범위로 바꿉니다. 6교시의 원래 작업 폴더는 따로 보관합니다.

### 3.2 어떤 화면에서 무엇을 하나요?

| 화면 | 하는 일 |
|---|---|
| Windows PowerShell | 수업 폴더 확인, 준비·승인 기록·검사·복원 명령 실행 |
| Hermes Web Dashboard → CHAT | 계획 요청과 승인한 P1 구현 요청 |
| 메모장 | 명세·계획을 읽고 자신의 관찰 기록 작성 |

Windows 작업 폴더는 `C:\AI-Native\harness-engineering`, Agent의 작업 폴더는 `/workspace`입니다. 예를 들어 Agent가 `/workspace/PLAN.md`에 쓰면 Windows의 `workspace\PLAN.md`에서 볼 수 있습니다.

### 3.3 폴더별로 맡은 일을 알아둡니다

폴더 설명에 나오는 **prepare**는 실습 자료를 준비하는 동작, **checkpoint**는 검사와 복원에 쓸 시작 상태의 사본입니다. **해시(SHA-256)**는 파일 내용으로 계산하는 식별값으로, 전후 값이 같은지 비교해 내용이 유지됐는지 확인합니다.

**Memory**는 Agent가 다음 대화에도 참고할 기억, **Skill**은 재사용할 작업 방법과 지침입니다. 이번에는 이 파일들을 변경하지 않으며, 준비 당시와 같은지 검사합니다.

로그에 나오는 **stdout(표준 출력)**과 **stderr(표준 오류)**는 프로그램이 메시지를 내보내는 두 통로입니다. 이 실습 프로그램은 정상 안내를 stdout에, 오류 안내를 stderr에 씁니다. **JSON**은 항목 이름과 값을 짝지어 저장하는 텍스트 형식으로, 검사 결과와 세션 내보내기에 사용합니다.

| Windows 작업 폴더 아래 위치 | 쉬운 설명 | 내용과 사용하는 때 |
|---|---|---|
| inputs/ | 읽을 원본 | 200행 판매 데이터, 10행 확인용 데이터와 오류·관계 검사 파일. 관계 검사는 행 순서를 바꿔도 합계가 같은지처럼 입력 변화와 결과의 관계를 확인하는 시험. 이번에는 sales_micro.csv와 quantity_zero.csv 사용 |
| workspace/ | Agent의 작업 책상 | 읽을 명세·Context, 작성할 PLAN과 analyze_sales.py |
| workspace/context/ | 배경과 경계 | 업무상 의미·작성 관례·실행 환경·이번 변경 범위 |
| workspace/lesson07/ | 이번 작업 안내 | TASK, 두 요청 파일, 6교시 인수조건 사본, 승인 사본 |
| workspace/lesson07/checks/ | 검사 도중 생기는 로그 | 세 사례의 stdout·stderr·report.json. 검사 때 자동 생성 |
| workspace/outputs/lesson07-p1/ | 보존 확인용 폴더 | summary.csv와 report.md에 시험용 문장이 들어 있음. P1이 건드리지 않는지 확인 |
| records/lesson07/ | 내 관찰과 실행 증거 | plan_review.md, 응답·세션, 검사 JSON, 승인 기록과 실행 로그 사본 |
| records/lesson07/checkpoint/ | 시작 상태 보관함 | prepare 직후 파일·일부 설정·Memory·Skill 사본과 해시. 검사·복원에 사용 |
| records/lesson07/prior-workspace/ | 6교시 작업의 사본 | 7교시 준비 전 작업 내용 확인용 |
| starter/lesson07/ | 배포한 시작 문서 | prepare가 workspace에 옮기는 바탕 파일. 실습 중 수정하는 곳은 workspace |
| templates/ | 빈 기록 양식 | prepare가 plan_review.md를 만들 때 사용 |
| examples/ | 작성 방법 참고 | 단계별 관찰 기록과 전체 작성 예시. 본인의 증거로 바꿔 작성 |
| course-tools/ | 수업용 보조 프로그램 | 준비·검사·복원을 일정한 방식으로 수행. Agent의 구현 대상은 아님 |

`records/lesson07/workspace-before-prepare`에는 준비 전에 옮겨 둔 작업 폴더도 있습니다. 직접 편집할 관찰 기록과 보관 사본을 구분하세요. **checkpoint와 보관 사본은 그대로 두고, 관찰은 plan_review.md에 적습니다.**

### 3.4 주요 파일은 언제 읽고 쓰나요?

`.ps1`은 PowerShell 명령을 모아 둔 스크립트이고, `.py`는 Python 프로그램 파일입니다. `lesson07.ps1` 뒤에 동작 이름을 붙이면 **prepare는 준비, check는 상태 검사, approve는 승인 기록, test는 프로그램 실행 검사, restore는 복원**을 수행합니다.

**보조 컨테이너**는 준비·검사·복원 도구를 실행하는 동안 잠시 사용하는 컨테이너입니다. **일반 실습 컨테이너**는 Hermes Web Dashboard가 실행 중인 컨테이너이며, 작성한 프로그램도 이곳에서 검사합니다.

| 파일 | 역할과 주요 내용 | 누가 어떻게 다루나요? |
|---|---|---|
| compose.yaml | 사용할 이미지, 연결 폴더, 포트 등 실행 설정 | Docker Compose가 읽음. 이번에 수정하지 않음 |
| lesson07.ps1 | PowerShell 명령과 Docker 안의 보조 도구를 연결 | 교육생이 prepare·check·approve·test·restore를 지정해 실행 |
| course-tools/lesson07_planning.py | 시작점 보관, 파일·설정 비교, 승인 기록, 실행 증거 복사, 복원 | ps1이 보조 컨테이너에서 실행 |
| course-tools/lesson07_probe.py | 작성된 프로그램을 세 입력으로 실행하고 관찰 | ps1의 test가 일반 실습 컨테이너에서 실행 |
| workspace/SPEC.md | 완성 프로그램이 지킬 계약 | 사람이 읽고 Agent가 계획·구현의 근거로 사용 |
| workspace/lesson07/ACCEPTANCE.md | 6교시 기록의 4절 사본 | 준비 도구가 추출. Agent가 계획과 연결할 때 읽음 |
| workspace/lesson07/TASK.md | 이번에 승인할 P1의 범위와 중간 확인 방법 | 계획·구현 전에 읽음 |
| workspace/PLAN.md | P1·P2·P3의 변경·검증·중단 계획 | Agent가 계획 단계에 작성, 사람이 읽고 승인 |
| workspace/lesson07/approval.json | P1만 승인했다는 정보와 PLAN 해시 | approve가 생성. Agent가 구현 전에 읽음 |
| workspace/analyze_sales.py | 앞으로 완성할 판매 분석 프로그램 | 이번에는 Agent가 P1 입력 검사 부분만 작성 |
| records/lesson07/plan_review.md | 실제로 무엇을 보고 판단했는지 | 교육생이 단계마다 이어서 작성 |

`SPEC.md`는 **완성품의 계약**, `TASK.md`는 **지금 구현할 부분**, `PLAN.md`는 **구현과 확인의 순서**입니다. 예를 들어 완성품은 정상 입력에서 보고서를 만들지만, 지금 P1은 입력을 검사한 뒤 `INPUT_VALID rows=10`을 보여 주고 끝납니다. `INPUT_VALID`는 입력 검사를 통과했다는 뜻이고, `rows=10`은 확인한 데이터가 10행이라는 뜻입니다. 보고서 생성은 계획의 P2에 남깁니다.

### 3.5 ps1과 Python 프로그램의 관계

```mermaid
flowchart TD
  A["PowerShell · lesson07.ps1"] --> B["보조 컨테이너 · planning.py"]
  B --> C["진입점·승인·관찰 기록"]
  A --> D["일반 실습 컨테이너 · probe.py"]
  D --> E["analyze_sales.py 실행"]
  E --> F["종료코드·stdout·stderr"]
  F --> D
  D -->|검사 파일 수집| B
```

`lesson07.ps1`은 Windows에서 순서를 조정합니다. 현재 수업 폴더로 이동하고, 필요한 파일을 확인하고, 상황에 맞는 Docker 명령으로 Python 보조 도구를 실행합니다. 따라서 Windows에 별도로 Python을 설치해 이 보조 도구를 실행할 필요가 없습니다.

`lesson07_planning.py`는 준비·검사·복원에 필요한 파일 작업을 합니다. 예를 들어 `check plan`에서는 PLAN만 달라졌는지 비교하고, `approve`에서는 검토한 계획의 사본과 해시를 남깁니다. **계획 내용의 적절성은 사람이 읽어 판단합니다.** 도구가 PLAN의 P1·P2·P3 표기를 찾았다고 좋은 계획이 되는 것은 아닙니다.

`lesson07_probe.py`는 Agent가 만든 `analyze_sales.py`를 실제로 실행하는 검사기입니다. 프로그램의 종료코드와 출력 문장을 받아 기록하고, 준비한 두 파일의 해시가 유지되는지 확인합니다. 분석 프로그램을 대신 작성하거나 고쳐 주지는 않습니다.

| 입력하는 명령 | 왜 실행하나요? | 일어나는 일과 남는 결과 |
|---|---|---|
| .\lesson07.ps1 prepare | 이전 결과를 이어받아 같은 진입점에서 시작 | 6교시 최종 상태·Baseline 확인, 앞 작업 보관, 시작 파일·checkpoint·관찰 양식 준비, Hermes 시작 |
| .\lesson07.ps1 check start | 첫 요청 전에 출발 상태 확인 | 준비된 파일과 현재 파일·설정 비교, START_READY |
| .\lesson07.ps1 check plan | 계획 단계에서 구현을 시작하지 않았는지 확인 | PLAN 외의 예상하지 않은 변경 검사, check-plan JSON |
| .\lesson07.ps1 approve | 사람이 검토한 계획과 승인 범위를 고정 | PLAN 사본, 해시, P1 승인 JSON |
| .\lesson07.ps1 check implemented | 승인 범위 안에서 파일을 만들었는지 확인 | 승인 PLAN과 보호 대상 유지, analyze_sales.py 존재, check-implemented JSON |
| .\lesson07.ps1 test | 만든 프로그램의 실제 행동 확인 | 정상·수량 0·없는 입력 실행, 로그와 보존 여부 기록, P1_CHECK_PASS 또는 실패 |
| .\lesson07.ps1 check final | 현재 코드와 검사 결과가 연결되는지 확인 | 실행한 코드 해시와 현재 코드, 승인 PLAN·설정·파일·앞 기록 확인 |
| .\lesson03.ps1 verify | 최초 비교 기준 보존 확인 | 3교시 Baseline 무결성 검사 |
| .\lesson07.ps1 restore | 실수로 시작 상태로 돌아가야 할 때 | 현재 시도 보관, prepare 직후 상태 복원, Hermes는 중지 상태 |

이 명령들 자체는 모델에게 질문하지 않습니다. 모델을 사용하는 곳은 Hermes Chat에 계획·구현 요청을 보내는 단계입니다.

## 4) 실습에 필요한 핵심 이론

### 4.1 계획에는 변경과 확인이 함께 있어야 합니다

“입력을 읽는다 → 계산한다 → 보고서를 만든다”는 작업 목록입니다. 여기에 **어느 파일을 바꿀지, 무엇을 확인하면 다음 단계로 갈지, 실패하면 어떻게 할지**를 붙이면 실행을 통제하는 계획이 됩니다.

| 단계 | 바꾸려는 것 | 확인할 것 | 다음 단계로 넘어가지 않는 조건 |
|---|---|---|---|
| P1 입력 검사 | analyze_sales.py의 읽기·검사·오류 처리 | 정상·수량 0·없는 입력의 진단과 기존 파일 유지 | 종료코드·진단·보존이 기대와 다름 |
| P2 계산·출력 | 같은 프로그램의 집계·출력 기능 | 56,000원·19개, 두 파일 형식, 정상 결과 보존·반복 | AC-01·AC-02·AC-03을 충족하지 못함 |
| P3 더 넓은 검증 | 필요한 검사 코드와 증거 | 다른 오류, 동률 정렬, 행·열 순서·인코딩 변화 등 | 규칙 누락·예상하지 않은 변경 발견 |

**동률**은 제품 매출이 같은 경우이고, **인코딩**은 문자를 파일에 저장하는 방식입니다. P3에서는 이런 입력의 차이가 있어도 명세대로 처리하는지 확인할 계획을 세웁니다.

P1에서는 세 사례를 먼저 확인합니다. 세 사례 밖의 모든 오류를 시험했다고 기록하지 않습니다. 계획에는 남은 검사도 적어 둡니다.

### 4.2 계획 승인과 도구 승인을 구분합니다

계획을 승인한다는 것은 “이 계획의 P1을 이 범위에서 진행하자”는 결정입니다. `approve` 명령은 그 결정과 당시 계획을 보관합니다. 이후 Chat에 P1 구현 요청을 보내야 Agent가 구현을 시작합니다.

도구 승인 화면은 실제 파일 쓰기나 명령 실행을 요청할 때 나타날 수 있습니다. 화면이 나오면 대상이 승인 범위 안인지 확인합니다. P1에서 쓰기 대상은 `analyze_sales.py` 하나이며 명령 실행은 교육생이 합니다. 승인 화면이 나타나면 대상 파일을 확인한 뒤 선택한 내용을 기록합니다. 승인 화면이 나타나지 않으면 ‘승인 화면 없음’으로 적습니다.

### 4.3 ‘검사 통과’의 범위를 읽습니다

| 결과 | 확인한 것 |
|---|---|
| CHECK_PASS: plan | 해당 단계의 파일·저장된 설정이 기대 상태와 일치 |
| APPROVE_PASS | 검토한 계획 사본과 P1 승인 기록 저장 |
| P1_CHECK_PASS | 세 사례의 기대 종료코드·기본 진단·보관 파일 유지 확인 |
| CHECK_PASS: final | 통과한 실행의 코드와 현재 코드가 같고 승인 계획과 경계가 유지됨 |

파일 검사는 사후 관찰입니다. Agent의 모든 행동을 사전에 막는 권한 장치는 아닙니다. 4교시에서 확인한 Docker의 읽기 전용 입력 경계, 요청의 범위, 사람의 확인, 검사 기록을 함께 사용합니다.

### 4.4 오류 종료코드 2가 시험에서는 정상일 수 있습니다

이 프로그램은 정상 입력 검사가 끝나면 종료코드 **0**, 입력 규칙에 맞지 않으면 **2**를 반환하도록 정합니다.

수량 0을 주면 분석 프로그램은 입력 오류를 알리며 **2로 종료해야** 합니다. 검사기는 “예상한 2가 나왔는가?”를 확인하므로 이 사례를 PASS로 표시합니다. 반면 수량 0을 건너뛰고 0으로 끝내면 검사 실패입니다.

검사기는 stdout과 stderr를 별도 파일에 저장합니다. 화면을 놓쳤더라도 해당 파일에서 정상 안내와 오류 원문을 다시 읽을 수 있습니다.

## 5) 전체 작업 흐름

```mermaid
flowchart TD
  A["6교시 결과로 진입점 준비"] --> B["계획 작성 · 사람 검토"]
  B --> C{"P1 범위와 확인 기준이 명확한가?"}
  C -->|아니오| B
  C -->|예| D["P1 승인 기록 · 구현"]
  D --> E{"세 사례와 파일 검사 통과?"}
  E -->|아니오| F["실패 원인과 기록 확인"]
  F -->|P1 코드 문제| J["승인 범위 안에서 수정"]
  J --> E
  F -->|진입점 복원 필요| H["restore · 새 Chat"]
  H --> B
  E -->|예| G["관찰 기록 완성 · 남은 계획 보관"]
```

계획부터 P1 구현까지 같은 새 Chat을 사용합니다. Agent가 자신이 작성한 계획과 사람의 승인 범위를 이어서 볼 수 있게 합니다. 복원으로 처음부터 다시 시작할 때는 새 Chat을 엽니다.

## 6) 단계별 실습

### 단계 1. 자료를 추가하고 진입점을 준비합니다

**1-1. ZIP을 압축 해제합니다 — Windows 파일 탐색기**

1. `AN-Harness-Lesson07-Planning.zip`을 다운로드합니다.
2. 압축 풀기 위치를 `C:\AI-Native`로 지정합니다.
3. ZIP 안의 `harness-engineering` 폴더가 현재 수업 폴더와 합쳐지게 합니다.
4. `C:\AI-Native\harness-engineering\lesson07.ps1`이 `compose.yaml`과 나란히 있는지 확인합니다.

압축 프로그램이 ZIP 이름의 폴더를 한 겹 더 만들면 그 안의 `harness-engineering` **내용물**을 현재 수업 폴더로 복사합니다. 같은 7교시 자료를 다시 받았다면 제공한 수업 파일을 교체합니다. 개인 `workspace`, `records`, `.env`, `compose.yaml`, 공통 CSV는 이 ZIP에 포함되지 않습니다.

**1-2. 위치와 준비물을 확인합니다 — PowerShell**

```powershell
Set-Location 'C:\AI-Native\harness-engineering'
Get-Location
Test-Path .\compose.yaml
Test-Path .\lesson07.ps1
Test-Path .\course-tools\lesson07_planning.py
Test-Path .\course-tools\lesson07_probe.py
Test-Path .\starter\lesson07\PLAN.md
Test-Path .\templates\plan_review.md
Test-Path .\workspace\SPEC.md
Test-Path .\records\lesson06\spec_review.md
Test-Path .\inputs\sales\sales_micro.csv
Test-Path .\inputs\sales\errors\quantity_zero.csv
```

모두 `True`이면 계속합니다. 수업 파일이 없으면 압축 해제 위치를 확인하고, 6교시 결과가 없으면 그 교시의 저장부터 마무리합니다. 빈 파일을 만들어 대신 통과시키지 않습니다.

**1-3. prepare가 하는 일을 확인하고 실행합니다**

메모장의 작업 파일을 저장하고 닫습니다. Hermes가 응답 생성 중이면 먼저 멈춥니다.

```powershell
Unblock-File -LiteralPath .\lesson03.ps1
Unblock-File -LiteralPath .\lesson06.ps1
Unblock-File -LiteralPath .\lesson07.ps1
.\lesson07.ps1 prepare
```

`Unblock-File`은 내려받은 스크립트의 실행 차단을 해제합니다. `prepare` 안에서 6교시 최종 검사와 3교시 검사를 사용하므로 세 스크립트를 해제합니다.

| 진행 순서 | 지금 하는 일 |
|---:|---|
| 1 | 6교시 최종 상태와 3교시 Baseline을 검사 |
| 2 | Hermes를 멈추고 6교시 workspace를 보관 |
| 3 | 실제 SPEC·업무 Context·환경을 이어받고 이번 인덱스·경계·빈 PLAN·요청·TASK를 준비 |
| 4 | 6교시 기록 4절을 ACCEPTANCE.md로 옮기고 보존 검사 파일 두 개를 준비 |
| 5 | 진입점과 설정·Memory·Skill·입력·앞 교시 기록의 해시를 보관, plan_review.md 양식 생성 |
| 6 | Baseline을 다시 검사하고 새 workspace로 Hermes를 시작 |

**준비 성공 메시지 예시:**

```text
CHECK_PASS: final
BASELINE_INTEGRITY_PASS
PREPARE_PASS: Lesson06 work preserved; Lesson07 entry checkpoint saved.
BASELINE_INTEGRITY_PASS
Next: check healthy, open a NEW Hermes Chat, then .\lesson07.ps1 check start
```

아래 기록 예시에 나오는 이름·날짜·파일명과 결과는 본인의 실행 내용에 맞게 적습니다.

처음의 `CHECK_PASS: final`은 **6교시 상태가 준비 조건에 맞는지 확인한 결과**입니다. 이어서 `PREPARE_PASS`가 나오면 7교시 시작 파일과 복원에 사용할 사본이 준비된 것입니다.

`Container ... Creating`은 준비 도구를 실행할 임시 컨테이너를 만드는 안내입니다. `Lesson07 already prepared`가 나오면 현재 단계에서 계속하거나, 처음으로 돌아가야 할 때 7)의 restore를 사용합니다.

**1-4. healthy를 확인하고 새 Chat을 엽니다**

```powershell
docker compose ps
```

**화면 예시:** STATUS에 `Up 31 seconds (healthy)`, PORTS에 `127.0.0.1:9119->9119/tcp`가 표시됩니다. 경과 시간보다 `healthy`와 포트 연결을 확인합니다.

`health: starting`이면 잠시 후 다시 확인합니다. `healthy`이면 브라우저의 `http://127.0.0.1:9119` → **CHAT → New chat**에서 다음 명령을 한 줄씩 입력합니다.

```text
/title planning-lesson07
/model z-ai/glm-5.3-flash
/reasoning low
/status
```

`/model`만 입력해 같은 모델을 선택해도 됩니다. 모델과 `reasoning: low`, 작업 폴더 `/workspace`를 확인합니다. 계속 준비되지 않으면 `docker compose logs --tail 80 hermes`로 로그를 확인합니다.

**1-5. 시작 상태를 검사하고 기록을 시작합니다**

PowerShell에서 실행합니다. 아직 계획 요청을 보내지 않습니다.

```powershell
.\lesson07.ps1 check start
notepad .\records\lesson07\plan_review.md
```

`START_READY`는 시작 상태가 준비됐다는 뜻입니다. JSON의 `true`는 조건을 만족함, `false`는 만족하지 않음, `[]`는 기록된 항목이 없는 목록을 뜻합니다. JSON의 `workspace_matches`, `settings_match`, `memory_and_skills_unchanged`, `common_inputs_unchanged`, `earlier_lesson_records_unchanged`는 `true`, 차이 목록은 `[]`여야 합니다.

**시작 검사 출력 예시:**

```text
{
  "stage": "start",
  "workspace_matches": true,
  "workspace_differences": [],
  "settings_match": true,
  "settings_differences": [],
  "memory_and_skills_unchanged": true,
  "common_inputs_unchanged": true,
  "earlier_lesson_records_unchanged": true,
  "spec_sha256": "80813a38ca366a3a8e1e454e039a7d677cd5aebdfa1aa5edcdb836a557bc3475",
  "plan_sha256": "53ad69841ce75a0a8d10cbc1b427a64f4418cb2c822636eace6425690de1cefc",
  "p1_probe_current_and_passed": null,
  "scope": "Stage-specific file observations and saved settings; review plan quality, actual tool use and approval in the Chat."
}
RECORDED: records/lesson07/check-start-20260911T072253975140Z-e0663f.json
START_READY
```

위 JSON에서 `spec_sha256`은 `workspace\SPEC.md`, `plan_sha256`은 `workspace\PLAN.md`의 내용으로 계산한 SHA-256 해시값입니다. 해시는 파일 내용을 비교하기 위한 긴 문자열로, 같은 내용이면 같은 값이 나옵니다. 지금의 `plan_sha256`은 아직 작성 전인 PLAN 양식의 값입니다. 단계 2에서 계획을 작성하면 달라질 수 있습니다.

`p1_probe_current_and_passed`는 **현재 코드와 승인한 계획에 맞는 P1 실행 검사가 통과했는지** 나타냅니다. 이 항목은 단계 6의 `check final`에서 판정합니다. 시작·계획·구현 검사에서는 `null`(이 검사 단계에서는 판정하지 않음)이 정상이며, 단계 5의 test 직후 출력되는 구현 검사에서도 `null`로 나옵니다.

`RECORDED:` 뒤는 **방금 검사 결과를 저장한 파일의 경로**입니다. 예를 들어 위 결과의 파일명은 `check-start-20260911T072253975140Z-e0663f.json`입니다. 파일명 끝의 시각·식별자는 기록을 구분하고, JSON 안의 해시값은 검사 대상 파일의 내용을 비교합니다. 둘은 용도가 다릅니다.

메모장에서 **1절 시작 상태**를 적습니다. 아직 내보내지 않은 세션 파일명은 ‘내보내기 전’으로 남깁니다.

```markdown
## 1. 시작 상태
- 작성자 / 날짜: Nuguna / 2026-09-11
- 모델 / 추론 설정: z-ai/glm-5.3-flash / low
- Chat 이름 / 세션 JSON: planning-lesson07 / 내보내기 전
- 6교시에서 이어받은 것: 구체화된 SPEC.md와 spec_review.md 4절의 인수조건
- prepare / healthy / check start 결과: PREPARE_PASS / healthy / START_READY
```

작성자와 날짜를 본인의 것으로 바꾸고, 화면에서 확인한 결과를 적습니다. **지금은 1절만 작성합니다.**

Ctrl+S로 저장하고 닫습니다. 앞으로 같은 `plan_review.md`를 계속 채웁니다.

### 단계 2. 읽을 근거를 확인하고 계획을 요청합니다

**2-1. 작업 안내와 인수조건을 읽습니다 — PowerShell → 메모장**

```powershell
notepad .\workspace\lesson07\TASK.md
notepad .\workspace\lesson07\ACCEPTANCE.md
notepad .\workspace\PLAN.md
```

TASK에서는 P1의 정상 메시지와 보고서를 만들지 않는 범위를 확인합니다. ACCEPTANCE에서는 자신이 6교시에 적은 세 조건이 옮겨졌는지 봅니다. PLAN은 아직 빈 양식입니다. 읽고 닫습니다.

`outputs/lesson07-p1/summary.csv`와 `report.md`는 보존 확인용 문장이 든 파일입니다. 완성된 매출 보고서가 아닙니다. P1 실행 전후 같은 내용인지 확인하기 위해 준비했습니다.

**2-2. 계획 요청을 보냅니다**

PowerShell에서 요청을 복사합니다.

```powershell
Get-Content -Raw -Encoding utf8 .\workspace\lesson07\plan_request.txt | Set-Clipboard
```

Hermes의 `planning-lesson07` 대화에 붙여넣고 한 번 전송합니다. 전체 요청은 다음과 같습니다.

```text
/workspace/CONTEXT_INDEX.md를 먼저 읽고, 그 목록의 문서를 순서에 맞춰 확인하세요.
추가로 읽을 입력은 /inputs/sales/sales_micro.csv와 /inputs/sales/errors/quantity_zero.csv입니다.
지금은 조사와 계획 단계입니다. /workspace/PLAN.md만 작성하고 프로그램 구현·명령 실행·그 외 파일 변경·패키지 설치·외부 검색은 하지 마세요.
SPEC의 전체 요구를 P1 입력 검사, P2 계산과 보고서, P3 더 넓은 검증으로 나누세요.
각 단계에 목적, 근거 파일과 명세 절, 변경할 파일, 확인 방법, 성공 기준, 실패 시 중단·복구를 적으세요. 6교시 인수조건 AC-01·AC-02·AC-03과의 연결도 적으세요.
이번 승인 대상은 lesson07/TASK.md의 P1뿐입니다. P1에서 정상 출력은 INPUT_VALID rows=N이며 보고서는 생성하지 않습니다. 이후 P2에서 SPEC의 정상 출력 계약을 구현하도록 계획하세요.
P1의 실행 확인은 교육생이 PowerShell에서 .\lesson07.ps1 test로 수행합니다. Agent가 실행한다고 적지 마세요.
명세·인수조건에 실제 충돌이 있으면 근거와 필요한 결정을 적고, 파일 수정 없이 질문으로 보고하세요. 표현 방식 같은 구현 선택은 구분하세요.
PLAN.md를 작성한 뒤 읽은 파일, 실제 도구, 변경 파일, P1의 완료 기준과 아직 승인되지 않은 일을 요약하고 멈추세요.
```

Agent가 읽기 도구와 PLAN 쓰기 도구를 사용하고, 계획 요약을 보고하면 기다림을 마칩니다. 응답 문구나 호출 횟수는 같을 필요가 없습니다. `analyze_sales.py`까지 작성하거나 명령을 실행하려 하면 중단하고 요청 범위를 확인합니다.

**계획 작성 과정 예시:**

| 순서 | 도구와 작업 | 확인한 내용 |
|---|---|---|
| 1 | `read_file` 10회 | CONTEXT_INDEX, Context 네 문서, SPEC, ACCEPTANCE, TASK, CSV 두 파일을 읽음 |
| 2 | `write_file` 1회 | `/workspace/PLAN.md`에 계획을 작성 |
| 3 | 계획 요약 응답 | P1·P2·P3와 확인 방법을 설명하고 P1 구현 승인을 기다리며 멈춤 |

도구 사용을 기록할 때는 **Chat의 Tool calls 목록을 확인**합니다. 위 예시라면 읽기 10회와 쓰기 1회이고, 본인의 호출 횟수는 다를 수 있습니다.

**2-3. 파일을 검사하고 계획·원래 응답을 확인합니다**

이 단계에서는 **계획을 읽고 검토할 점을 찾습니다.** P1 구현 승인과 프로그램 실행은 뒤에서 진행합니다. 먼저 자동 검사로 파일·설정 상태를 확인하고, 이어서 사람이 계획의 내용을 읽습니다.

```powershell
.\lesson07.ps1 check plan
notepad .\workspace\PLAN.md
```

검사 결과가 아래처럼 `CHECK_PASS: plan`이면 계속 읽습니다. 오류나 예상하지 않은 파일·설정 차이가 나오면 출력과 세션을 보관하고 7)의 문제 해결 안내를 확인합니다.

**계획 검사 출력 예시:**

```text
{
  "stage": "plan",
  "workspace_matches": true,
  "workspace_differences": [],
  "settings_match": true,
  "settings_differences": [],
  "memory_and_skills_unchanged": true,
  "common_inputs_unchanged": true,
  "earlier_lesson_records_unchanged": true,
  "spec_sha256": "80813a38ca366a3a8e1e454e039a7d677cd5aebdfa1aa5edcdb836a557bc3475",
  "plan_sha256": "d22778b9e0bee2b83ca01ca59098d4b1ab17f4521739dcc31b212e350f13dabb",
  "p1_probe_current_and_passed": null,
  "scope": "Stage-specific file observations and saved settings; review plan quality, actual tool use and approval in the Chat."
}
RECORDED: records/lesson07/check-plan-20260911T074118366849Z-748092.json
CHECK_PASS: plan
```

위 출력에서 **`"plan_sha256": "d22778…"`로 시작하는 줄**을 찾습니다. `RECORDED:`에 있는 `20260911T074118366849Z-748092`는 검사 기록 파일을 구분하는 시각·식별자입니다. `plan_sha256`은 **`check plan`의 결과 JSON에 나오는 항목 이름**이고, 콜론 오른쪽의 긴 문자열이 계획 파일의 해시값입니다. 예시와 본인의 계획 내용이 다르면 이 값도 다르므로 예시 값으로 맞추지 않습니다. 이 항목이 가리키는 대상은 Windows의 `workspace\PLAN.md`, 즉 Agent가 이번에 작성한 계획 파일입니다. 같은 파일이 컨테이너에서는 `/workspace/PLAN.md`로 보입니다.

점검 도구는 이 파일의 내용을 읽어 ‘파일의 지문’ 같은 **해시값**을 계산하고, JSON의 `plan_sha256` 항목 오른쪽에 긴 문자열로 표시합니다. 이름의 `plan`은 계획 파일을, `sha256`은 지문을 계산하는 방식인 SHA-256을 뜻합니다. **따라서 별도로 찾아 열 파일 이름이나 실행할 명령이 아니라, 계획 파일의 내용이 바뀌었는지 비교하는 점검 값입니다.**

예를 들어 시작 검사 때의 `PLAN.md`는 아직 작성 전인 양식입니다. Agent가 여기에 계획을 채우면 파일 내용이 바뀌므로 `plan_sha256`도 달라집니다. **이번 단계에서 시작 검사 때와 다른 값이 나오는 것은 정상입니다.** 문장 하나나 줄바꿈만 바뀌어도 값이 달라질 수 있습니다. 이 값을 외우거나 직접 입력할 필요는 없습니다.

해시값은 계획의 내용이 바뀌었는지 확인하는 데 사용하며, 계획을 잘 세웠는지 평가하는 점수는 아닙니다. `CHECK_PASS: plan`을 확인한 뒤에는 아래 예시처럼 **계획의 작업 범위·확인 방법·성공 기준을 직접 읽고 판단**합니다.

`CHECK_PASS: plan`은 이 단계에서 PLAN 외의 예상하지 않은 변경이 발견되지 않았다는 뜻입니다. 메모장의 실제 계획에 아래 내용이 있는지 읽습니다.

| 읽을 항목 | 승인 전에 확인할 내용 |
|---|---|
| P1 | 입력 검사와 오류 보고, analyze_sales.py 하나, 세 사례·기존 파일 유지, 실패 시 중단 |
| P2 | 집계·두 출력·정렬을 구현하고 AC-01·AC-02·AC-03 전체를 확인할 계획 |
| P3 | 다른 오류·동률·관계 검사를 확장할 계획 |
| 인수조건 | 6교시 기준과 연결되며 P1만으로 전부 완료한다고 하지 않음 |
| 실행 주체 | 이번 실행 검사는 교육생이 PowerShell의 test로 수행 |
| 범위 | 추가 패키지·다운로드·다른 파일 수정·설정 변경이 필요하지 않음 |

**계획을 읽고 판단하는 예시:**

| 항목 | 예시 계획의 내용 | 판단과 다음 행동 |
|---|---|---|
| P1 | analyze_sales.py에 입력 검사만 구현. 정상·수량 0·없는 입력의 종료코드와 메시지, 보존 파일 유지 확인 | 변경 파일과 확인 방법이 구체적인지 읽음 |
| P2 | 계산·summary.csv·report.md·정렬 및 인수조건 검증 | 계산과 보고서 생성이 P1 범위에 섞이지 않았는지 확인 |
| P3 | 다양한 오류와 관계 검사 | 세 사례 외에 더 확인할 입력과 규칙이 제시됐는지 확인 |
| 실행 주체 | 교육생이 PowerShell의 test로 검사하고 Agent는 실행하지 않음 | 이번 실습의 실행 주체와 일치 |
| AC-03 표현 | “동일 입력 재실행 시 동일 출력을 이미 만족”이라고 작성 | 아직 구현·실행하지 않았으므로 검토 기록에 남기고, 2-5에서 PLAN 표현 보완 |
| 최종 도구 요약 | “파일 읽기만”이라고 요약 | 실제 목록의 read_file 10회·write_file 1회를 검토 기록에 적음. 원래 응답은 그대로 보관 |

**자동 검사 통과와 계획 내용 검토는 서로 다른 확인입니다.** check plan은 “이미 만족” 같은 설명의 타당성을 판정하지 않습니다. 아직 실행하지 않은 결과를 완료로 설명했는지는 사람이 PLAN과 도구 기록을 대조합니다.

검토할 때는 “P1의 범위가 맞는가?”, “무엇으로 성공을 확인하는가?”, “계획을 이미 실행한 결과처럼 쓰지는 않았는가?”를 묻습니다. **발견한 점은 2-4에서 기록하고, PLAN의 범위·성공 기준·완료 표현을 고쳐야 하면 2-5에서 보완합니다.** 최종 응답의 도구 요약처럼 실제 이력과 다른 설명은 검토 기록에 차이를 남깁니다. 원래 응답을 사람이 고쳐 쓰지 않습니다.

메모장의 PLAN은 읽은 뒤 닫습니다. 아직 직접 수정하거나 승인하지 않습니다.

현재 받은 계획 응답을 그대로 보관합니다. Agent의 원래 표현을 사람이 고쳐서 저장하지 않습니다.

```powershell
notepad .\records\lesson07\plan_response.md
```

Chat에서 **도구 작업이 끝난 뒤 나온 마지막 계획 요약 응답**을 복사해 붙여넣습니다. 예를 들어 마지막 응답이 “PLAN.md 작성 완료. 요약:”으로 시작하여 “P1 승인을 기다리며 여기서 멈춥니다.”로 끝난다면, 그 시작부터 끝까지 복사합니다. 중간의 읽은 파일·사용한 도구·변경 파일·완료 기준 설명도 모두 포함합니다. 본인의 문구가 다르더라도 마지막 요약 응답 전체를 저장합니다.

입력한 요청, Tool calls 목록, `+`·`-`가 붙은 파일 변경 내역은 이 파일에 넣지 않습니다. 응답의 표현을 고치지 않고 그대로 붙여넣은 뒤 **Ctrl+S로 저장하고 닫습니다.**

| 보관할 내용 | 파일 |
|---|---|
| Agent의 마지막 계획 요약 응답 | `records\lesson07\plan_response.md` |
| 작성된 계획 전체 | `workspace\PLAN.md` |
| 요청·도구 호출·응답 전체 | 내보낸 세션 JSON |
| 계획을 읽고 판단한 내용 | `records\lesson07\plan_review.md` |

현재 세션을 JSON으로 내보내고, 다운로드한 파일을 파일 탐색기에서 `C:\AI-Native\harness-engineering\records\lesson07` 폴더로 복사합니다. 세션 파일명에는 본인의 실행 시각과 식별자가 들어가므로, 실제 파일명을 그대로 보관합니다.

**2-4. 기록의 2절에 검토 의견과 현재 판단을 적습니다**

```powershell
notepad .\records\lesson07\plan_review.md
```

1절은 유지하고 **2절만 채웁니다.** 아래는 앞의 실제 계획처럼 AC-03 표현을 보완해야 하는 경우의 기록 예시입니다. 본인의 PLAN에 같은 문제가 없으면 해당 지적을 넣지 않고 ‘보완 필요 없음’으로 적습니다. 호출 횟수와 파일명도 본인의 기록을 사용합니다.

```markdown
## 2. 계획 검토
- P1: 입력 규칙과 첫 오류를 analyze_sales.py에 구현한다. 실행 검사는 교육생이 PowerShell에서 정상·수량 0·없는 입력의 세 사례로 수행한다.
- P2: 계산과 두 출력 파일을 구현한 뒤 AC-01·AC-02·AC-03 전체를 확인한다.
- P3: 다른 오류·동률·관계 검사를 수행한다.
- P1 변경 파일: analyze_sales.py 하나. 계산과 보고서 생성은 P1에 포함하지 않았다.
- 계획 단계의 실제 도구와 변경 파일: read_file 10회, write_file 1회. PLAN.md를 작성했다.
- 최초 check plan 결과 / 파일명: CHECK_PASS: plan / check-plan-20260911T074118366849Z-748092.json.
- 검토 의견: P1·P2·P3의 구분과 실행 주체는 적절하다. 다만 AC-03의 “동일 입력 재실행 시 동일 출력을 이미 만족”은 아직 실행하지 않은 결과를 완료처럼 표현했다.
- 응답과 실제 이력의 차이: 최종 응답에는 “파일 읽기만”이라고 적혀 있으나 실제로는 PLAN 쓰기도 있었다. 원래 응답은 plan_response.md에 그대로 보관했다.
- 필요한 보완: AC-03을 앞으로 검증할 조건으로 고친다. P1에서 전체 인수조건을 완료했다고 쓰지 않는다.
- 보완 요청 / 결과: 아직 요청 전.
- 보완 후 check plan / 파일명: 아직 재검사 전.
- 현재 판단: PLAN 표현을 보완한 뒤 승인 여부를 판단한다. P1 구현은 아직 승인하지 않았다.
```

**Ctrl+S로 저장하고 닫습니다.** 위 예시의 ‘아직 요청 전’과 ‘아직 재검사 전’은 2-5를 수행하면서 실제 내용으로 바꿉니다. 아직 하지 않은 보완이나 검사를 완료했다고 미리 적지 않습니다.

**2-5. 필요한 경우 계획을 보완하고, 단계 3으로 갈 수 있는지 확인합니다**

계획의 범위·성공 기준·완료 표현에 문제가 없다면 보완 요청과 재검사는 생략합니다. 2절에 ‘보완 필요 없음. 계획 검토 완료, P1 승인 전’이라고 적고 단계 3으로 갑니다.

보완이 필요하면 **계획을 작성한 같은 Hermes Chat**에 구체적으로 요청합니다. 아래는 AC-03을 이미 만족했다고 쓴 경우에 사용할 요청입니다. 본인의 문제점이 다르면 지적과 요구를 그 내용에 맞게 바꿉니다.

```text
PLAN.md의 AC-03 설명을 보완하세요.
“동일 입력 재실행 시 동일 출력을 이미 만족”이라고 적혀 있지만, 아직 프로그램을 구현하거나 실행하지 않았습니다.
아직 확인하지 않은 결과를 완료로 표현하지 마세요.
P1에서는 입력 검사만 구현하며, AC-03의 전체 검증은 P2 구현 후 동일 입력으로 두 번 실행하고 summary.csv와 report.md 각각의 실행 간 해시를 비교해야 한다고 적으세요.
이번 요청은 계획 보완만 허용합니다. /workspace/PLAN.md만 수정하세요.
analyze_sales.py 작성, 프로그램·명령 실행, 그 외 파일·설정 변경은 하지 마세요.
보완한 부분을 요약한 뒤 멈추세요. P1 구현은 아직 승인하지 않았습니다.
```

**보완 대화에서 확인할 내용 — 실제 실행 예시:**

| 확인할 곳 | 예시에서 나타난 내용 | 읽고 판단할 점 |
|---|---|---|
| Tool calls | `Patch("/workspace/PLAN.md")` 1회 | Patch는 기존 파일의 일부를 고치는 도구입니다. 수정 대상이 PLAN인지 확인합니다. |
| 변경 내역 | AC-03의 완료 표현을, P1에서는 검증하지 않고 P2 구현 후 반복 실행과 파일별 SHA-256 비교로 검증한다는 설명으로 변경 | 아직 확인하지 않은 결과와 앞으로 수행할 검증을 구분했는지 읽습니다. |
| 마지막 응답 | “보완 완료 — /workspace/PLAN.md의 AC-03 항목만 수정했습니다.”로 시작하는 요약 | 수정 내용과 아직 승인하지 않은 P1 구현을 구분했는지 확인합니다. |

이 예시처럼 “이미 만족”이라는 말을 **확인된 결과가 없다는 설명 안에서 인용**할 수 있습니다. 특정 단어가 남았는지만 찾지 말고, 문장이 검증 완료를 주장하는지 읽습니다.

Agent가 보완 요약을 응답하면 **PowerShell**로 돌아와 실행합니다.

```powershell
.\lesson07.ps1 check plan
notepad .\workspace\PLAN.md
```

**보완 후 계획 검사 출력 예시:**

```text
{
  "stage": "plan",
  "workspace_matches": true,
  "workspace_differences": [],
  "settings_match": true,
  "settings_differences": [],
  "memory_and_skills_unchanged": true,
  "common_inputs_unchanged": true,
  "earlier_lesson_records_unchanged": true,
  "spec_sha256": "80813a38ca366a3a8e1e454e039a7d677cd5aebdfa1aa5edcdb836a557bc3475",
  "plan_sha256": "bd124587cdc364a2d1fdeaa46a1b799d9fe26afa58563c03749b51767f1af414",
  "p1_probe_current_and_passed": null,
  "scope": "Stage-specific file observations and saved settings; review plan quality, actual tool use and approval in the Chat."
}
RECORDED: records/lesson07/check-plan-20260911T112139204780Z-804634.json
CHECK_PASS: plan
```

`CHECK_PASS: plan`을 확인하고, PLAN에서 지적한 문장이 실제로 고쳐졌는지 읽습니다. 이미 검증을 마쳤다는 주장을 하지 않고 **검증할 시점·방법·기대 결과**가 분명해야 합니다. P1의 범위와 실행 주체도 그대로인지 확인합니다. PLAN 내용이 바뀌었으므로 `plan_sha256`이 최초 검사와 달라지는 것은 정상입니다.

위 예시의 최초 계획 해시는 `d22778…`, 보완 후 해시는 `bd1245…`입니다. PLAN 내용이 바뀌어 해시도 달라졌지만, 명세를 가리키는 `spec_sha256`은 그대로입니다. `p1_probe_current_and_passed: null`은 계획 검사에서 정상이며, P1 실행 검사는 뒤에서 수행합니다. 기록에는 생략 표시가 있는 짧은 값 대신 **본인 출력의 해시 전체와 RECORDED의 파일명**을 적습니다.

자동 검사가 통과해도 요청한 보완이 반영되지 않았다면 같은 Chat에 남은 문제를 설명하고, 보완 후 다시 검사합니다. 파일·설정 차이로 검사가 멈추면 해당 오류를 먼저 확인합니다. 문제가 남은 상태에서 단계 3으로 넘어가지 않습니다.

메모장의 PLAN을 닫고 보완 응답을 따로 보관합니다.

```powershell
notepad .\records\lesson07\plan_revision_response.md
```

보완 작업이 끝난 뒤 나온 **마지막 요약 응답 전체**를 그대로 붙여넣고 저장합니다. 위 대화 예시에서는 **“보완 완료 — /workspace/PLAN.md의 AC-03 항목만 수정했습니다.”부터 “P1 구현은 아직 승인 대기 상태입니다.”까지**입니다. 입력한 요청이나 Patch의 변경 내역은 이 응답 파일에 넣지 않습니다. 최초 응답인 `plan_response.md`는 유지합니다. 보완을 여러 번 했다면 `plan_revision_response.md` 끝에 ‘보완 2차’처럼 차수를 붙여 다음 응답을 추가합니다. 이 파일은 보완한 경우에만 만듭니다.

같은 세션을 다시 JSON으로 내보내 `records\lesson07`에 보관합니다. 2-3에서 보관한 최초 내보내기와 같은 이름으로 다운로드되면 최초 파일을 덮어쓰지 말고, 새 파일에 `-revised` 같은 접미사를 붙여 구분합니다. 실제 보관한 파일명을 기록에 적습니다.

**세션 파일을 구분하는 예시:**

| 파일명 | 담긴 대화 |
|---|---|
| `session-20260911_072037_30babd(1).json` | 최초 계획 작성과 요약까지 |
| `session-20260911_072037_30babd-revised.json` | 최초 계획에 이어 AC-03 보완 요청·Patch·보완 응답까지 |

파일명만 보고 내용을 단정하지 말고, 내보낼 때 현재 Chat에 보완 대화가 포함됐는지 확인합니다. `(1)`은 다운로드 중 같은 이름을 구분하기 위해 붙을 수 있으므로, 보완 여부 자체를 뜻하지 않습니다. **본인이 보관한 실제 파일명으로 기록하고 예시 이름에 맞춰 바꾸지 않습니다.**

저장한 응답과 세션 파일을 확인합니다.

```powershell
Get-Item .\records\lesson07\plan_revision_response.md
Get-ChildItem .\records\lesson07 -Filter 'session*.json'
notepad .\records\lesson07\plan_review.md
```

**보완 후 1·2절 전체 기록 예시**

아래는 앞의 보완 대화와 재검사 결과를 반영한 **1·2절 전체**입니다. 기존 기록의 1절 시작부터 2절 끝까지를 이 내용으로 교체할 수 있습니다. 3절 이후가 있다면 유지합니다. 단, 이름·날짜·도구 횟수·파일명·해시는 본인의 결과로 바꾸고, 자신의 다른 관찰 내용이 있다면 함께 남깁니다. 보완하지 않은 경우에는 2-4에서 작성한 본인의 기록을 유지합니다.

변경되는 부분은 1절의 세션 파일명과 2절의 보완 요청·검사 결과·현재 판단입니다. 최초 검사 결과와 최초 검토 의견은 **왜 보완했는지 보여 주므로 유지**합니다. ‘아직 요청 전·재검사 전’은 수행한 결과로 바꿉니다.

```markdown
## 1. 시작 상태

- 작성자 / 날짜: Nuguna / 2026-09-11
- 모델 / 추론 설정: z-ai/glm-5.3-flash / low
- Chat 이름 / 세션 JSON: planning-lesson07 / session-20260911_072037_30babd-revised.json
- 6교시에서 이어받은 것: 구체화된 SPEC.md와 spec_review.md 4절의 인수조건
- prepare / healthy / check start 결과: PREPARE_PASS / healthy / START_READY

## 2. 계획 검토

- P1: 입력 규칙과 첫 오류를 analyze_sales.py에 구현한다. 실행 검사는 교육생이 PowerShell에서 정상·수량 0·없는 입력의 세 사례로 수행한다.
- P2: 계산과 두 출력 파일을 구현한 뒤 AC-01·AC-02·AC-03 전체를 확인한다.
- P3: 다른 오류·동률·관계 검사를 수행한다.
- P1 변경 파일: analyze_sales.py 하나. 계산과 보고서 생성은 P1에 포함하지 않았다.
- 계획 단계의 실제 도구와 변경 파일: read_file 10회, write_file 1회. PLAN.md를 작성했다.
- 최초 check plan 결과 / 파일명: CHECK_PASS: plan / check-plan-20260911T074118366849Z-748092.json.
- 최초 검토 의견: P1·P2·P3의 구분과 실행 주체는 적절하다. 다만 AC-03의 “동일 입력 재실행 시 동일 출력을 이미 만족”은 아직 실행하지 않은 결과를 완료처럼 표현했다.
- 응답과 실제 이력의 차이: 최종 응답에는 “파일 읽기만”이라고 적혀 있으나 실제로는 PLAN 쓰기도 있었다. 원래 응답은 plan_response.md에 그대로 보관했다.
- 보완을 요청한 이유: AC-03을 앞으로 검증할 조건으로 고치고, P1에서 전체 인수조건을 완료한 것으로 표현하지 않도록 하기 위해서다.
- 보완 요청 / 결과: AC-03의 완료 표현을 수정하도록 요청했다. Patch 기록에서 PLAN.md의 AC-03 항목이 변경됐음을 확인했다. P1에서는 AC-03을 검증하지 않고, P2 구현 후 동일 입력으로 두 번 실행하여 summary.csv와 report.md 각각의 실행 간 SHA-256 해시를 비교하도록 보완됐다.
- 보완 단계의 실제 도구와 변경 파일: Patch 1회. PLAN.md의 AC-03 항목을 수정했다.
- 보완 후 check plan / 파일명: CHECK_PASS: plan / check-plan-20260911T112139204780Z-804634.json.
- 보완 후 PLAN 해시: bd124587cdc364a2d1fdeaa46a1b799d9fe26afa58563c03749b51767f1af414.
- 보완 세션 JSON: session-20260911_072037_30babd-revised.json.
- 현재 판단: 대화의 변경 내역에서 AC-03의 완료 표현이 바로잡혔음을 확인했고, 보완 후 자동 검사도 통과했다. P1 구현은 아직 승인하지 않았다.
```

보완 응답을 저장해 위 파일 확인 명령으로 확인했다면 다음 줄도 추가합니다.

```markdown
- 보완 응답 보관: plan_revision_response.md.
```

실제 PLAN에서 보완 내용과 P1 범위·확인 방법까지 읽고 검토를 마쳤다면 ‘현재 판단’을 다음처럼 갱신합니다.

```markdown
- 현재 판단: 실제 PLAN.md에서 AC-03 보완 내용과 P1 범위·확인 방법을 검토했고, 보완 후 자동 검사도 통과했다. 계획 검토를 마쳤으며 P1 구현 승인은 아직 하지 않았다.
```

2절까지 저장하고 닫습니다. **계획 검토를 마치고 최신 `check plan`이 통과했다면 단계 3으로 갑니다.** 단계 3의 `approve`가 그때의 PLAN을 승인 기록으로 남깁니다. 기록의 3절은 승인 후에 작성합니다.

### 단계 3. 검토한 계획 중 P1만 승인합니다

**3-1. 승인 범위를 확인합니다**

이번 승인은 **P1 입력 검사 구현만**입니다. PLAN에는 P2와 P3도 있지만 그 부분을 지금 실행하라는 뜻은 아닙니다. 2-4의 검토와, 필요한 경우 2-5의 보완·재검사를 마친 PLAN을 승인합니다. TASK에 없는 파일 변경이나 실행이 남아 있다면 2-5로 돌아가 먼저 보완합니다.

**3-2. 승인 기록을 남깁니다 — PowerShell**

```powershell
.\lesson07.ps1 approve
```

**확인할 메시지:**

```text
RECORDED: records/lesson07/check-plan-20260911T120920116665Z-fbb6ed.json
CHECK_PASS: plan
APPROVE_PASS: reviewed PLAN saved; P1 only. Send the P1 request in Hermes Chat.
```

이 명령은 먼저 계획 상태를 다시 검사하고, 검토한 계획과 승인 범위를 파일로 남깁니다. 위 RECORDED 파일명은 실제 승인 실행의 예시이며 본인 기록에는 본인의 파일명을 적습니다. 모델에게 구현 요청을 보내는 동작은 단계 4에서 수행합니다.

| 생성 파일 | 의미 |
|---|---|
| records/lesson07/approved-PLAN.md | 승인 순간의 PLAN 사본 |
| records/lesson07/approved-plan.json | P1 범위, 계획 해시, 기록 시각 |
| workspace/lesson07/approval.json | Agent가 읽을 승인 정보 사본 |

```powershell
Get-Content .\records\lesson07\approved-plan.json
```

**승인 정보 출력 예시:** 아래는 보완된 PLAN을 승인한 실제 예시입니다. 본인이 실행한 결과에서 값과 승인 범위를 확인합니다.

```json
{
  "approved_step": "P1",
  "plan_sha256": "bd124587cdc364a2d1fdeaa46a1b799d9fe26afa58563c03749b51767f1af414",
  "created_utc": "20260911T120920164982Z-57a2fa",
  "allowed_change": [
    "analyze_sales.py"
  ],
  "allowed_execution": "course P1 probe only; no implementation of P2/P3",
  "approval_scope": "Student ran approve after reviewing PLAN.md. Not a blanket tool permission."
}
```

| 항목 | 확인하고 기록할 내용 |
|---|---|
| `approved_step` | 승인한 단계가 `P1`인지 확인합니다. |
| `allowed_change` | 변경 허용 파일 목록이 `analyze_sales.py` 하나인지 확인합니다. |
| `plan_sha256` | 승인 순간의 PLAN 내용으로 계산한 해시입니다. 바로 위 `Get-Content`로 연 **본인의 approved-plan.json**에서 콜론 오른쪽 문자열 전체를 복사해 기록 3절의 ‘승인 PLAN 해시’에 붙여넣습니다. 예시 값으로 맞추지 않습니다. |

`created_utc`는 승인 기록 생성 시각과 식별자입니다. `allowed_execution`은 수업의 P1 실행 검사만 허용하고 P2·P3 구현은 제외한다는 뜻입니다. `approval_scope`는 검토한 계획을 승인했다는 기록이며, 모든 도구 작업을 포괄적으로 허용한다는 뜻이 아닙니다.

계획 검사 이후 PLAN을 보완했다면 승인 해시도 처음 계획의 해시와 달라질 수 있습니다. 최종 검토한 PLAN의 값으로 기록합니다. 2-5에서 보완했다면 최초 검사 출력의 예시 해시가 아니라 **보완 후 승인된 PLAN의 해시**를 기록합니다. **승인 후 PLAN을 직접 고치지 않습니다.** 다른 계획을 진행하려면 현재 시도를 보관하고 시작 상태에서 다시 검토합니다.

**3-3. 기록의 3절을 채웁니다**

```powershell
notepad .\records\lesson07\plan_review.md
```

**기존 3절을 아래 형식으로 작성합니다.** 각 줄은 ‘항목명: 내용’으로 적습니다. 예시는 앞의 보완된 PLAN을 승인한 결과를 사용하며, 실행 결과와 해시는 본인의 출력으로 바꿉니다. 1·2절은 유지합니다.

PowerShell의 `approve`는 승인 기록을 파일로 남기는 동작이고, Chat에 보내는 P1 구현 요청은 Agent에게 구현을 시작하도록 지시하는 동작입니다. **지금은 승인 기록을 만든 시점이므로 Chat 요청은 ‘아직 전송 전’으로 적습니다.**

```markdown
## 3. 승인 범위

- 승인한 단계: P1 입력 검사만
- 변경 허용 파일: analyze_sales.py 하나
- 아직 승인하지 않은 단계: P2 계산·출력, P3 더 넓은 검증
- approve 실행 결과: CHECK_PASS: plan / APPROVE_PASS
- 승인 PLAN 해시: bd124587cdc364a2d1fdeaa46a1b799d9fe26afa58563c03749b51767f1af414
- 계획 일치 확인: 보완 후 검사한 PLAN 해시와 일치함
- 승인 정보 확인: approved-plan.json에서 P1 승인과 변경 허용 파일을 확인함
- Chat에 보낸 P1 구현 요청: 아직 전송 전
- 최초 계획 응답 보관 파일: plan_response.md
```

1·2절은 유지합니다. 승인 범위를 적고 저장한 다음 Chat에 구현 요청을 보냅니다.

### 단계 4. 승인한 입력 검사 부분만 구현합니다

**4-1. P1 구현 요청을 보냅니다**

PowerShell에서 복사합니다.

```powershell
Get-Content -Raw -Encoding utf8 .\workspace\lesson07\implement_request.txt | Set-Clipboard
```

같은 `planning-lesson07` Chat에 붙여넣고 한 번 전송합니다.

```text
/workspace/lesson07/approval.json과 /workspace/PLAN.md, /workspace/lesson07/TASK.md를 읽으세요. 필요한 SPEC과 Context는 다시 확인하세요.
검토한 계획의 P1 입력 검사 구현만 승인합니다. P2·P3은 승인하지 않습니다.
/workspace/analyze_sales.py만 작성하세요. 표준 라이브러리를 사용하고 TASK.md의 P1 인터페이스·진단 메시지·중단 조건을 따르세요.
SPEC의 입력 검사·첫 오류 순서·원본 보호를 구현하되, P1에서는 계산·보고서 생성·기존 결과 교체를 하지 마세요.
계획·명세·Context·인수조건·승인 파일·요청·설정·Memory·Skill을 수정하지 마세요. 패키지 설치·외부 검색·명령 실행은 하지 마세요.
코드가 작성되면 구현한 범위, 변경 파일, 아직 구현하지 않은 P2·P3을 알려 주세요. 실행하지 않은 테스트를 통과했다고 하지 마세요.
검사는 제가 PowerShell에서 수행합니다. 파일 작성이 끝나면 멈추세요.
```

Agent가 파일을 작성한 뒤 멈추는지 확인합니다. 쓰기 승인 화면이 나온다면 대상이 `/workspace/analyze_sales.py`인지 확인합니다. 패키지 설치나 명령 실행 요청이면 승인 범위를 벗어나므로 진행하지 않고 기록합니다.

구현 요청을 실제로 전송했다면 기록의 3절도 갱신합니다.

```powershell
notepad .\records\lesson07\plan_review.md
```

‘Chat에 보낸 P1 구현 요청’ 한 줄을 아래 내용으로 바꾸고 저장합니다. 이 줄은 요청을 전송했다는 기록입니다. 구현과 검사 결과는 4절에 별도로 적습니다.

```markdown
- Chat에 보낸 P1 구현 요청: implement_request.txt의 내용을 planning-lesson07 Chat에 전송함
```

본인의 Chat 이름이 다르면 그 이름으로 적습니다. 승인 PLAN 해시와 나머지 승인 기록은 유지합니다.

**4-2. 실제 변경을 검사합니다**

```powershell
.\lesson07.ps1 check implemented
Get-Item .\workspace\analyze_sales.py
```

`CHECK_PASS: implemented`와 파일의 존재를 확인합니다. 이 검사는 **구현 파일의 존재와 승인된 계획·관련 파일·설정의 유지 여부**를 확인합니다. 프로그램 실행 검사는 단계 5에서 진행합니다.

**구현 단계 검사 출력 예시:**

```text
{
  "stage": "implemented",
  "workspace_matches": true,
  "workspace_differences": [],
  "settings_match": true,
  "settings_differences": [],
  "memory_and_skills_unchanged": true,
  "common_inputs_unchanged": true,
  "earlier_lesson_records_unchanged": true,
  "spec_sha256": "80813a38ca366a3a8e1e454e039a7d677cd5aebdfa1aa5edcdb836a557bc3475",
  "plan_sha256": "bd124587cdc364a2d1fdeaa46a1b799d9fe26afa58563c03749b51767f1af414",
  "p1_probe_current_and_passed": null,
  "scope": "Stage-specific file observations and saved settings; review plan quality, actual tool use and approval in the Chat."
}
RECORDED: records/lesson07/check-implemented-20260911T125042664257Z-63a617.json
CHECK_PASS: implemented
```

이 예시의 `Get-Item` 결과에서는 `analyze_sales.py`가 7,806바이트였습니다. 파일 크기는 Agent가 작성한 코드에 따라 달라질 수 있으며, 이 크기에 맞출 필요는 없습니다.

**구현 대화의 도구 예시:** Read File 2회로 `approval.json`과 `TASK.md`를 읽고 Write File 1회로 `analyze_sales.py`를 작성했습니다. 본인의 도구 목록에서 실제 사용 내용을 확인합니다. 앞선 계획 대화에서 읽은 파일과 이번 요청에서 다시 읽은 파일을 구분해서 기록합니다.

구현 응답을 복사해 저장합니다.

```powershell
notepad .\records\lesson07\implementation_response.md
```

Chat의 **“구현 완료. 변경 파일은…”부터 “파일 작성이 끝났으므로 여기서 멈춥니다.”까지** 마지막 구현 응답 전체를 붙여넣고 저장합니다. 본인의 문구가 다르면 도구 작업이 끝난 뒤의 마지막 응답 전체를 선택합니다. 도구 목록과 코드 변경 내역은 이 응답 파일에 넣지 않습니다.

**4-3. 기록의 4절 앞부분을 채웁니다**

```powershell
notepad .\records\lesson07\plan_review.md
```

실제 변경 파일, 사용한 도구, `check implemented` 결과와 파일명을 적습니다. 세 사례 표의 **실제 종료코드와 판정은 아직 ‘확인 전’**으로 둡니다. Agent가 “검증 완료”라고 써도 실제 실행 기록이 없으면 검증 완료로 옮겨 적지 않습니다.

아래는 구현 파일 검사까지 수행한 시점의 **4절 전체 예시**입니다. 실제 값으로 바꾸어 기존 4절을 채우고 저장합니다. 1·2·3절은 유지합니다.

```markdown
## 4. 구현과 첫 실행 확인

- Agent가 실제로 변경한 파일: /workspace/analyze_sales.py
- 사용한 도구: Read File 2회로 approval.json과 TASK.md를 읽고, Write File 1회로 analyze_sales.py를 작성함
- 구현 파일 확인: workspace/analyze_sales.py가 생성됐으며 파일 크기는 7,806바이트임
- check implemented 결과: CHECK_PASS: implemented
- 구현 검사 기록 파일: check-implemented-20260911T125042664257Z-63a617.json
- 승인 계획 유지: PLAN 해시가 승인 당시의 bd124587cdc364a2d1fdeaa46a1b799d9fe26afa58563c03749b51767f1af414와 일치함
- 보호 대상 확인: 설정·Memory·Skill·공통 입력·앞 교시 기록의 유지 검사 결과가 모두 true이며 차이 목록은 비어 있음
- 프로그램 실행 검사: 아직 수행 전

| 사례 | 기대 종료코드 | 실제 종료코드 | stdout 또는 stderr | 보관 파일 유지 | 나의 판단 |
|---|---|---|---|---|---|
| 정상 10행 | 0 | 확인 전 | 확인 전 | 확인 전 | 확인 전 |
| 수량 0 | 2 | 확인 전 | 확인 전 | 확인 전 | 확인 전 |
| 없는 입력 | 2 | 확인 전 | 확인 전 | 확인 전 | 확인 전 |
```

### 단계 5. 세 사례를 실행하고 결과를 해석합니다

**5-1. test가 무엇을 실행하는지 이해합니다**

지금부터는 실제 `analyze_sales.py`가 실행됩니다. `test`는 다음 순서로 동작합니다.

1. 구현 단계의 파일·설정을 먼저 검사합니다.
2. 일반 실습 컨테이너에서 `lesson07_probe.py`를 실행합니다.
3. 검사기가 `analyze_sales.py`를 정상·수량 0·없는 입력으로 각각 실행합니다.
4. 각 실행의 명령·종료코드·stdout·stderr·두 보관 파일의 유지 여부를 기록합니다.
5. 결과를 `records/lesson07/probe-runs`로 복사하고 파일·설정을 다시 확인합니다.

준비·복원 도구는 작업을 보관하기 위해 수업 폴더에 접근합니다. **작성한 프로그램은 일반 실습 컨테이너에서 실행**하며, 접근할 수 있는 폴더는 compose.yaml의 연결 설정을 따릅니다. 관련 명령은 5-4에서 설명합니다.

**5-2. 실행합니다 — PowerShell**

```powershell
.\lesson07.ps1 test
```

**세 사례가 통과한 실제 출력에서 주요 메시지를 옮긴 예시입니다.** 본인의 출력에서 각 사례의 PASS 또는 FAIL을 확인합니다.

`valid_micro`는 정상 10행, `quantity_zero`는 수량 0, `missing_input`은 없는 파일 사례의 이름입니다. `exit`는 실제 종료코드이고, `outputs_preserved=True`는 준비한 두 보존 확인용 파일이 유지됐다는 뜻입니다.

```text
PASS valid_micro: exit=0, outputs_preserved=True
PASS quantity_zero: exit=2, outputs_preserved=True
PASS missing_input: exit=2, outputs_preserved=True
PROBE_REPORT: /workspace/lesson07/checks/p1-20260911T130648897341Z-383f34/report.json
RECORDED: records/lesson07/probe-runs/p1-20260911T130648897341Z-383f34/report.json
CHECK_PASS: implemented
P1_CHECK_PASS: three cases passed. P2/P3 remain unimplemented.
```

`PROBE_REPORT`는 컨테이너 안의 실행 보고서 위치이고, `RECORDED`는 그 로그를 Windows의 기록 폴더로 복사한 위치입니다. 출력에 파일·설정 검사 JSON이 함께 나오는 것은 정상입니다. test는 실행 전과 후에 `check implemented`를 수행하므로 검사 파일이 두 개 더 생깁니다.

각 사례의 최대 실행 대기는 15초입니다. 멈춰 있는 프로그램을 무한히 기다리지 않고 timeout(제한 시간 초과)을 실패로 기록합니다. 실패하더라도 생성된 로그는 보관됩니다.

`quantity_zero`의 코드 2는 기대한 오류 동작입니다. 반면 `FAIL`, `P1_CHECK_STOPPED`, 파일·설정 차이가 나오면 다음 구현으로 넘어가지 않습니다. 아래 5-3에서 오류 원문을 확인합니다.

**5-3. 실행 로그를 직접 읽습니다**

검사 파일을 복사한 뒤에는 PowerShell에서 다음과 같이 가장 최근 실행 폴더를 찾습니다.

```powershell
Get-ChildItem .\records\lesson07\probe-runs -Directory
$lastRun = Get-ChildItem .\records\lesson07\probe-runs -Directory | Sort-Object Name | Select-Object -Last 1
Get-Content -Raw -Encoding utf8 (Join-Path $lastRun.FullName 'report.json')
Get-Content -Encoding utf8 (Join-Path $lastRun.FullName 'valid_micro.stdout.txt')
Get-Content -Encoding utf8 (Join-Path $lastRun.FullName 'quantity_zero.stderr.txt')
Get-Content -Encoding utf8 (Join-Path $lastRun.FullName 'missing_input.stderr.txt')
```

`p1-실행식별자`는 검사 때마다 생성되는 폴더 이름입니다. 실행 시각 등을 포함한 고유한 이름을 사용하므로 여러 시도의 로그를 구분할 수 있습니다.

`$lastRun`은 가장 최근 검사 폴더를 가리키는 변수이고 `Join-Path`는 그 폴더 안의 파일 경로를 만드는 명령입니다. `Get-ChildItem`에 폴더가 없다면 이 블록의 나머지를 실행하지 말고 직전 test 오류를 보관합니다.

| 로그 | 무엇을 확인하나요? |
|---|---|
| valid_micro.stdout.txt | INPUT_VALID rows=10이 있어 정상 입력 10건을 읽었는지 |
| quantity_zero.stderr.txt | 헤더를 1번으로 센 CSV 레코드 5번의 quantity(수량)가 1 이상 규칙을 위반했다고 설명하는지 |
| missing_input.stderr.txt | ‘입력 파일을 찾을 수 없음’을 뜻하는 INPUT_NOT_FOUND가 나오는지 |
| report.json | 실제 명령과 종료코드, 진단·보존·시간 초과 검사, 실행한 코드 해시 |

`report.json`에는 세 사례가 `cases` 목록으로 들어 있습니다. 다음 명령은 방금 찾은 실행 폴더에서 수량 0 사례만 꺼내 보여 줍니다. `$lastRun`을 지정한 같은 PowerShell 창에서 실행합니다.

```powershell
$p1Report = Get-Content -Raw -Encoding utf8 (Join-Path $lastRun.FullName 'report.json') | ConvertFrom-Json
$p1Report.cases | Where-Object { $_.case -eq 'quantity_zero' } | ConvertTo-Json -Depth 5
```

**수량 0 사례가 통과했을 때의 항목 예시**입니다. 실제 출력에는 실행 명령을 담은 `command` 항목도 있습니다.

```json
{
  "case": "quantity_zero",
  "expected_exit_code": 2,
  "actual_exit_code": 2,
  "checks": {
    "exit_code_matches": true,
    "diagnostic_matches": true,
    "existing_outputs_preserved": true,
    "no_timeout": true
  },
  "passed": true
}
```

| 기록 표에 적을 내용 | 값을 찾는 위치 |
|---|---|
| 사례 이름 | `cases`의 `case`: `valid_micro`, `quantity_zero`, `missing_input` |
| 기대 / 실제 종료코드 | 해당 사례의 `expected_exit_code` / `actual_exit_code` |
| stdout 또는 stderr | 위에서 연 사례별 `.stdout.txt` 또는 `.stderr.txt`의 실제 문장 |
| 보관 파일 유지 | 해당 사례의 `checks` 안에 있는 `existing_outputs_preserved` |
| 사례 검사 통과 여부 | 해당 사례의 `passed`. 네 가지 checks가 모두 true이면 true입니다. |

`diagnostic_matches`는 필요한 표식이 출력에 있는지, `no_timeout`은 제한 시간 안에 끝났는지를 뜻합니다. 보고서 맨 바깥의 `passed`는 세 사례가 모두 통과하고 실행 중 코드도 그대로였는지를 합쳐 보여 줍니다.

**사례별 실제 출력 예시:** 앞에서 연 세 파일은 각각 다음 문장을 보여 줍니다.

| 파일 | 실제 출력 |
|---|---|
| `valid_micro.stdout.txt` | `INPUT_VALID rows=10` |
| `quantity_zero.stderr.txt` | `ERROR: VALUE_NOT_POSITIVE record=5 field=quantity reason=quantity must be 1 or greater, got 0` |
| `missing_input.stderr.txt` | `ERROR: INPUT_NOT_FOUND record=0 reason=input path does not exist: /inputs/lesson07-file-does-not-exist.csv` |

수량 오류는 헤더를 1번으로 센 **CSV 레코드 5**의 quantity 값이 0이라서 1 이상 규칙에 어긋난다는 뜻입니다. 없는 파일의 `record=0`은 특정 데이터 행의 오류가 아닌 파일 전체 문제라는 이 구현의 표시입니다. 오류 문장의 철자를 예시와 같게 만들기보다 위치·필드·이유가 해당 입력과 맞는지 확인합니다.

실행 보고서의 코드·계획 연결 항목도 확인합니다. 아래는 `report.json`의 일부 항목을 옮긴 실제 예시입니다.

```json
{
  "run_id": "p1-20260911T130648897341Z-383f34",
  "source_sha256": "59afdca3fc4439dacc9224c308337aae0c218f928b8063de188197edecad34b9",
  "plan_sha256": "bd124587cdc364a2d1fdeaa46a1b799d9fe26afa58563c03749b51767f1af414",
  "source_unchanged": true,
  "passed": true
}
```

`source_sha256`은 시험한 `analyze_sales.py`의 해시이고, `plan_sha256`은 승인한 PLAN의 해시입니다. `source_unchanged: true`는 검사 도중 코드 내용이 바뀌지 않았다는 뜻입니다. 코드 해시와 계획 해시는 서로 다른 파일을 가리키므로 같은 값일 필요가 없습니다.

수량 오류 문구의 표현은 달라도 됩니다. 검사기는 코드와 기본 표식을 확인하므로 **오류 이유가 실제 규칙과 맞는지는 사람이 읽습니다.** report의 `passed: true`가 모든 입력 규칙을 빠짐없이 구현했다는 뜻은 아닙니다.

실패가 코드 문제라면 같은 Chat에 실제 사례·stderr·기대 동작을 전달해 **P1 범위에서 analyze_sales.py만 수정**하도록 요청합니다. 예를 들어 다음과 같이 씁니다.

```text
P1 검사 중 [본인의 실패 사례]가 실패했습니다.
실제 종료코드와 오류 원문: [본인의 결과]
TASK.md와 SPEC.md의 해당 규칙을 대조하여 analyze_sales.py의 원인만 수정하세요.
PLAN, 명세, 검사기, 입력, 보관 파일, 설정은 바꾸지 마세요. P2·P3은 구현하지 마세요.
명령은 실행하지 말고 수정 내용과 원인을 설명한 뒤 멈추세요. 제가 다시 test를 실행합니다.
```

대괄호 부분은 자신의 값으로 바꿉니다. 수정 후 `test`를 한 번 다시 실행하고 두 시도의 로그를 모두 남깁니다. 코드가 달라지면 이전 PASS만으로 완료 처리하지 않습니다. 같은 문제가 반복되거나 다른 파일까지 바뀌었다면 7)의 복원 절차로 시작 상태부터 진행합니다.

**5-4. Docker 명령의 역할을 연결해 봅니다**

아래 표는 `test`가 내부에서 사용하는 Docker 명령을 설명합니다. **명령을 추가로 입력하지 않고 역할을 읽어 봅니다.**

| 구성 요소 | 이 수업에서의 뜻 |
|---|---|
| docker compose run --rm --no-deps | 보조 컨테이너를 만들고 끝나면 제거하며 다른 서비스를 함께 자동 시작하지 않음. 준비·검사·복원 처리 |
| --user hermes | root 대신 hermes 사용자로 보조 작업 실행 |
| -T | 대화형 터미널을 할당하지 않고 출력 결과를 PowerShell에서 받음 |
| --entrypoint python | 이미지의 대시보드 시작 과정 대신 Python 보조 도구 실행 |
| --volume 수업폴더:/course-host | 관리 도구가 Windows 기록과 checkpoint를 보관하도록 수업 폴더 연결 |
| docker compose exec | 이미 실행 중인 일반 실습 컨테이너에서 명령 실행 |
| --workdir /workspace | 프로그램 실행 위치를 Agent 작업 폴더로 지정 |
| --env PYTHONDONTWRITEBYTECODE=1 | 시험 중 Python의 바이트코드 캐시 파일 생성을 줄이기 위한 설정 |
| python /course-tools/lesson07_probe.py | 세 사례 검사기 실행. 내부에서 analyze_sales.py를 실행하고 결과 수집 |

`planning.py`가 준비와 복원을 맡고, `probe.py`가 작성된 코드를 실행합니다. 이 역할을 나눠 두면 “준비 명령을 실행했다”와 “내 프로그램을 실행해 봤다”를 구분할 수 있습니다.

**5-5. 세 사례 표를 채웁니다**

```powershell
notepad .\records\lesson07\plan_review.md
```

**기존 4절 전체를 다음 예시처럼 갱신합니다.** 구현 직후의 ‘프로그램 실행 검사: 아직 수행 전’은 실행 결과로 바꾸고, 세 사례 표를 실제 출력으로 채웁니다. 최초 구현 검사 결과는 유지합니다. 중복된 실행 폴더 항목이나 빈 질문 줄은 합쳐 정리합니다.

다음은 앞의 세 사례 실행과 로그 내용을 반영한 전체 예시입니다. 본인의 결과·도구 횟수·파일명·해시로 바꾸세요. 실패나 재검사가 있었다면 횟수와 각 시도의 결과를 빠짐없이 적습니다.

```markdown
## 4. 구현과 첫 실행 확인

- Agent가 실제로 변경한 파일: /workspace/analyze_sales.py
- 사용한 도구: Read File 2회로 approval.json과 TASK.md를 읽고, Write File 1회로 analyze_sales.py를 작성함
- 구현 파일 확인: workspace/analyze_sales.py가 생성됐으며 파일 크기는 7,806바이트임
- check implemented 결과: CHECK_PASS: implemented
- 구현 검사 기록 파일: check-implemented-20260911T125042664257Z-63a617.json
- 승인 계획 유지: PLAN 해시가 승인 당시의 bd124587cdc364a2d1fdeaa46a1b799d9fe26afa58563c03749b51767f1af414와 일치함
- 보호 대상 확인: 설정·Memory·Skill·공통 입력·앞 교시 기록의 유지 검사 결과가 모두 true이며 차이 목록은 비어 있음
- 프로그램 실행 검사: lesson07.ps1 test로 정상 10행·수량 0·없는 입력의 세 사례를 실행함
- 실행 검사 결과: 세 사례 모두 통과하여 P1_CHECK_PASS가 출력됨

| 사례 | 기대 종료코드 | 실제 종료코드 | stdout 또는 stderr | 보관 파일 유지 | 나의 판단 |
|---|---|---|---|---|---|
| 정상 10행 | 0 | 0 | INPUT_VALID rows=10 | true | 정상 입력 10건의 입력 검사 통과를 확인했다. |
| 수량 0 | 2 | 2 | ERROR: VALUE_NOT_POSITIVE record=5 field=quantity reason=quantity must be 1 or greater, got 0 | true | 레코드 5의 수량 0을 1 이상 규칙 위반으로 보고했다. 기대한 오류 동작이다. |
| 없는 입력 | 2 | 2 | ERROR: INPUT_NOT_FOUND record=0 reason=input path does not exist: /inputs/lesson07-file-does-not-exist.csv | true | 없는 입력 파일을 오류로 보고했다. 특정 데이터 행의 오류가 아니므로 record=0으로 표시됐다. |

- 실행 로그 폴더: records/lesson07/probe-runs/p1-20260911T130648897341Z-383f34
- 실행 보고서: 위 실행 로그 폴더의 report.json
- 실행한 코드 해시: 59afdca3fc4439dacc9224c308337aae0c218f928b8063de188197edecad34b9
- 실행 중 코드 유지: source_unchanged가 true임
- 오류 설명 검토: 수량 0의 오류 위치·필드·이유와 없는 입력의 오류 코드가 기대한 동작에 부합함
- 실패 / 수정 요청 / 재검사 횟수와 결과: 이번 실행은 세 사례 모두 통과했으며, 이 실행 결과에 따른 코드 수정과 재검사는 없었음
- 확인 범위: P1의 세 사례 검사 통과. 전체 명세 검증과 P2·P3 구현 완료를 뜻하지 않음
```

4절까지 저장하고 닫습니다. 5절의 최종 검사와 보관 확인은 다음 단계에서 수행한 뒤 작성합니다.

### 단계 6. 최종 상태와 기록을 보관합니다

**6-1. 현재 코드와 검사 결과를 연결해 확인합니다**

```powershell
.\lesson07.ps1 check final
```

**최종 검사 출력 예시:**

```text
{
  "stage": "final",
  "workspace_matches": true,
  "workspace_differences": [],
  "settings_match": true,
  "settings_differences": [],
  "memory_and_skills_unchanged": true,
  "common_inputs_unchanged": true,
  "earlier_lesson_records_unchanged": true,
  "spec_sha256": "80813a38ca366a3a8e1e454e039a7d677cd5aebdfa1aa5edcdb836a557bc3475",
  "plan_sha256": "bd124587cdc364a2d1fdeaa46a1b799d9fe26afa58563c03749b51767f1af414",
  "p1_probe_current_and_passed": true,
  "scope": "Stage-specific file observations and saved settings; review plan quality, actual tool use and approval in the Chat."
}
RECORDED: records/lesson07/check-final-20260911T132352949806Z-66caf6.json
CHECK_PASS: final
```

시작 검사에서 `null`이었던 `p1_probe_current_and_passed`가 여기서는 `true`여야 합니다. 이는 마지막으로 수집한 세 사례 검사 결과가 통과했고, 그때 실행한 코드와 승인한 계획의 해시가 현재 검사 기준과 일치한다는 뜻입니다. test 이후 코드를 고쳤다면 test를 다시 실행하고 final을 확인합니다. 전체 SPEC의 모든 조건을 검사했다는 뜻은 아닙니다.

`CHECK_PASS: final`을 확인한 뒤 Baseline을 검사합니다. 첫 검사에 실패하면 오류를 먼저 확인합니다.

```powershell
.\lesson03.ps1 verify
```

`CHECK_PASS: final`, `BASELINE_INTEGRITY_PASS`를 확인합니다. test 이후 코드를 수정했다면 새 코드로 다시 검사해야 합니다. 앞 교시 기록이 달라졌다는 차이는 어떤 파일이 바뀌었는지 먼저 확인합니다. 7교시 준비 후에 `lesson06.ps1 check final`을 다시 실행하는 것은 현재 workspace가 7교시 상태이므로 적절하지 않습니다. 7교시 검사에서 앞 교시 기록 보존을 확인합니다.

**6-2. 같은 Chat을 JSON으로 내보냅니다**

Hermes 대화가 끝나면 앞 교시처럼 현재 세션을 JSON으로 내보내어 `records\lesson07`에 복사합니다. 계획과 P1 구현을 같은 Chat에서 진행했으므로 그 흐름을 한 세션에서 볼 수 있습니다. 재시도나 복원으로 여러 Chat을 썼다면 각 시도의 세션을 따로 보관합니다.

같은 Chat을 여러 시점에 내보냈다면 기존 파일을 유지하고, 마지막 내보내기에는 `-final`을 붙여 구분할 수 있습니다. 예시에서는 다음 세 파일을 보관했습니다. 파일명의 날짜와 식별자는 본인이 내보낸 이름을 사용합니다.

| 보관 파일 예시 | 담긴 내용 |
|---|---|
| `session-20260911_072037_30babd.json` | 최초 계획 작성까지 |
| `session-20260911_072037_30babd-revised.json` | AC-03 계획 보완까지 |
| `session-20260911_072037_30babd-final.json` | P1 구현까지 포함한 마지막 대화 |

`-final`은 이 교시의 마지막 대화 보관본을 구분하는 이름입니다. 전체 명세 구현 완료를 뜻하지 않습니다. 2-5에서 보았던 `(1)` 접미사도 본인의 실제 저장 이름에 따라 달라질 수 있습니다. 새 파일이 기존 파일과 이름이 같으면 덮어쓰지 말고 접미사로 구분합니다.

PowerShell의 검사 결과는 Chat 내보내기에 자동으로 포함되는 것이 아니므로, `check-*.json`과 `probe-runs`도 함께 보관합니다.

```powershell
Get-Item .\records\lesson07\plan_review.md, .\records\lesson07\plan_response.md, .\records\lesson07\implementation_response.md
Get-ChildItem .\records\lesson07 -Filter 'session*.json'
Get-ChildItem .\records\lesson07 -Filter 'check-*.json'
Get-Item .\records\lesson07\approved-PLAN.md, .\records\lesson07\approved-plan.json
Get-ChildItem .\records\lesson07\probe-runs -Directory
```

계획 보완을 했다면 보완 응답 파일도 확인합니다. 보완하지 않았다면 이 명령은 생략합니다.

```powershell
Get-Item .\records\lesson07\plan_revision_response.md
```

**기록 보관 확인 예시:** 예시 실행에서는 응답 파일 3개, 최초·보완·마지막 세션 3개, 승인 파일 2개, 검사 JSON 8개와 실행 로그 폴더 1개가 있었습니다. 본인의 파일 목록으로 확인하며 이 개수에 맞추려고 파일을 추가하거나 삭제하지 않습니다.

검사 JSON 8개는 시작 검사 1개, 계획 검사 3개(최초·보완 후·approve 내부 검사), 구현 검사 3개(구현 직후·test 전·test 후), 최종 검사 1개입니다. 보완이나 재검사 횟수에 따라 개수는 달라집니다.

**6-3. 기록의 5절과 빠진 파일명을 채웁니다**

```powershell
notepad .\records\lesson07\plan_review.md
```

1절의 실제 세션 파일명을 채우고 5절에 최종 검사·Baseline·보관 상태를 기록합니다. 승인한 PLAN을 지금 상태 보고서로 고치지 않고, **진행 결과는 plan_review.md에 적습니다.** 승인 당시 계획과 실제 결과를 대조할 수 있게 하기 위해서입니다.

| 작성 시점 | 기록이 어떻게 쌓이나요? | 아직 쓰지 않는 것 |
|---|---|---|
| 시작 | 1절 환경과 준비 결과 | 계획·승인·실행 결과 |
| 계획 후 | 2절 계획·근거·검토 의견 | 승인과 실행 결과 |
| 승인 후 | 3절 P1 범위와 계획 해시 | 실행 결과 |
| 구현 후 | 4절 코드와 변경 관찰 | 세 사례의 실제 판정 |
| test 후 | 4절 세 사례·로그·재시도 | 아직 하지 않은 최종 검사 |
| 종료 | 5절 최종 검사와 증거 목록 | 전체 SPEC 구현 완료라는 주장 |

전체 예시는 `examples/plan_review_example.md`, 단계별 변화는 `examples/plan_review_progression.md`에 있습니다. 자동 생성되는 `check-…json`, `p1-…` 폴더, `session-…json`은 본인의 실제 이름으로 적습니다. `plan_review.md`, 최초 계획 응답과 구현 응답의 이름은 수업에서 정한 이름을 사용합니다. 보완한 경우에는 `plan_revision_response.md`도 보관합니다.

**최종 기록 전체 예시 — 같은 plan_review.md를 차례로 완성합니다.**

아래 예시의 1절은 마지막 세션 파일명으로 갱신했고, 2절은 보완 이유와 결과, 3절은 승인 사실, 4절은 실제 실행 결과를 유지했습니다. 5절은 최종 검사와 파일 보관 확인 후 작성합니다. 본인의 관찰과 다르다면 해당 항목을 본인 결과로 바꾸고, 복원을 수행했다면 복원 이유와 보관 경로도 덧붙입니다.

````markdown
# 7교시 계획과 P1 실행 기록 — 실제 결과 기반 작성 예시

> 보완·구현·세 사례 실행·최종 보관까지 기록한 예시입니다. 본인의 실행 결과와 파일명을 사용하고, 수행한 범위만 완료로 기록합니다.

## 1. 시작 상태

- 작성자 / 날짜: Nuguna / 2026-09-11
- 모델 / 추론 설정: z-ai/glm-5.3-flash / low
- Chat 이름 / 세션 JSON: planning-lesson07 / session-20260911_072037_30babd-final.json
- 6교시에서 이어받은 것: 구체화된 SPEC.md와 spec_review.md 4절의 인수조건
- prepare / healthy / check start 결과: PREPARE_PASS / healthy / START_READY

## 2. 계획 검토

- P1: 입력 규칙과 첫 오류를 analyze_sales.py에 구현한다. 실행 검사는 교육생이 PowerShell에서 정상·수량 0·없는 입력의 세 사례로 수행한다.
- P2: 계산과 두 출력 파일을 구현한 뒤 AC-01·AC-02·AC-03 전체를 확인한다.
- P3: 다른 오류·동률·관계 검사를 수행한다.
- P1 변경 파일: analyze_sales.py 하나. 계산과 보고서 생성은 P1에 포함하지 않았다.
- 계획 단계의 실제 도구와 변경 파일: read_file 10회, write_file 1회. PLAN.md를 작성했다.
- 최초 check plan 결과 / 파일명: CHECK_PASS: plan / check-plan-20260911T074118366849Z-748092.json.
- 최초 검토 의견: P1·P2·P3의 구분과 실행 주체는 적절하다. 다만 AC-03의 “동일 입력 재실행 시 동일 출력을 이미 만족”은 아직 실행하지 않은 결과를 완료처럼 표현했다.
- 응답과 실제 이력의 차이: 최종 응답에는 “파일 읽기만”이라고 적혀 있으나 실제로는 PLAN 쓰기도 있었다. 원래 응답은 plan_response.md에 그대로 보관했다.
- 보완을 요청한 이유: AC-03을 앞으로 검증할 조건으로 고치고, P1에서 전체 인수조건을 완료한 것으로 표현하지 않도록 하기 위해서다.
- 보완 요청 / 결과: AC-03의 완료 표현을 수정하도록 요청했다. Patch 기록에서 PLAN.md의 AC-03 항목이 변경됐음을 확인했다. P1에서는 AC-03을 검증하지 않고, P2 구현 후 동일 입력으로 두 번 실행하여 summary.csv와 report.md 각각의 실행 간 SHA-256 해시를 비교하도록 보완됐다.
- 보완 단계의 실제 도구와 변경 파일: Patch 1회. PLAN.md의 AC-03 항목을 수정했다.
- 보완 후 check plan / 파일명: CHECK_PASS: plan / check-plan-20260911T112139204780Z-804634.json.
- 보완 후 PLAN 해시: bd124587cdc364a2d1fdeaa46a1b799d9fe26afa58563c03749b51767f1af414.
- 보완 세션 JSON: session-20260911_072037_30babd-revised.json.
- 계획 검토 시점의 판단: AC-03의 완료 표현이 바로잡혔고 보완 후 자동 검사도 통과했다. 이 시점에는 P1 구현을 아직 승인하지 않았다.
- 보완 응답 보관: plan_revision_response.md.

## 3. 승인 범위

- 승인한 단계: P1 입력 검사만
- 변경 허용 파일: analyze_sales.py 하나
- 아직 승인하지 않은 단계: P2 계산·출력, P3 더 넓은 검증
- approve 실행 결과: CHECK_PASS: plan / APPROVE_PASS
- 승인 PLAN 해시: bd124587cdc364a2d1fdeaa46a1b799d9fe26afa58563c03749b51767f1af414
- 계획 일치 확인: 보완 후 검사한 PLAN 해시와 일치함
- 승인 정보 확인: approved-plan.json에서 P1 승인과 변경 허용 파일을 확인함
- Chat에 보낸 P1 구현 요청: implement_request.txt의 내용을 planning-lesson07 Chat에 전송함
- 최초 계획 응답 보관 파일: plan_response.md

## 4. 구현과 첫 실행 확인

- Agent가 실제로 변경한 파일: /workspace/analyze_sales.py
- 사용한 도구: Read File 2회로 approval.json과 TASK.md를 읽고, Write File 1회로 analyze_sales.py를 작성함
- 구현 파일 확인: workspace/analyze_sales.py가 생성됐으며 파일 크기는 7,806바이트임
- check implemented 결과: CHECK_PASS: implemented
- 구현 검사 기록 파일: check-implemented-20260911T125042664257Z-63a617.json
- 승인 계획 유지: PLAN 해시가 승인 당시의 bd124587cdc364a2d1fdeaa46a1b799d9fe26afa58563c03749b51767f1af414와 일치함
- 보호 대상 확인: 설정·Memory·Skill·공통 입력·앞 교시 기록의 유지 검사 결과가 모두 true이며 차이 목록은 비어 있음
- 프로그램 실행 검사: lesson07.ps1 test로 정상 10행·수량 0·없는 입력의 세 사례를 실행함
- 실행 검사 결과: 세 사례 모두 통과하여 P1_CHECK_PASS가 출력됨

| 사례 | 기대 종료코드 | 실제 종료코드 | stdout 또는 stderr | 보관 파일 유지 | 나의 판단 |
|---|---|---|---|---|---|
| 정상 10행 | 0 | 0 | INPUT_VALID rows=10 | true | 정상 입력 10건의 입력 검사 통과를 확인했다. |
| 수량 0 | 2 | 2 | ERROR: VALUE_NOT_POSITIVE record=5 field=quantity reason=quantity must be 1 or greater, got 0 | true | 레코드 5의 수량 0을 1 이상 규칙 위반으로 보고했다. 기대한 오류 동작이다. |
| 없는 입력 | 2 | 2 | ERROR: INPUT_NOT_FOUND record=0 reason=input path does not exist: /inputs/lesson07-file-does-not-exist.csv | true | 없는 입력 파일을 오류로 보고했다. 특정 데이터 행의 오류가 아니므로 record=0으로 표시됐다. |

- 실행 로그 폴더: records/lesson07/probe-runs/p1-20260911T130648897341Z-383f34
- 실행 보고서: 위 실행 로그 폴더의 report.json
- 실행한 코드 해시: 59afdca3fc4439dacc9224c308337aae0c218f928b8063de188197edecad34b9
- 실행 중 코드 유지: source_unchanged가 true임
- 오류 설명 검토: 수량 0의 오류 위치·필드·이유와 없는 입력의 오류 코드가 기대한 동작에 부합함
- 실패 / 수정 요청 / 재검사 횟수와 결과: 이번 실행은 세 사례 모두 통과했으며, 이 실행 결과에 따른 코드 수정과 재검사는 없었음
- 확인 범위: P1의 세 사례 검사 통과. 전체 명세 검증과 P2·P3 구현 완료를 뜻하지 않음

## 5. 종료와 보관

- check final 결과: CHECK_PASS: final
- 최종 검사 기록 파일: check-final-20260911T132352949806Z-66caf6.json
- 현재 코드와 실행 검사 연결: p1_probe_current_and_passed가 true임
- 보호 대상 유지: 작업 폴더·설정·Memory·Skill·공통 입력·앞 교시 기록의 검사 결과가 모두 true이며 차이 목록은 비어 있음
- Baseline 검사 결과: BASELINE_INTEGRITY_PASS
- 관찰 기록 보관: plan_review.md
- 응답 파일 보관: plan_response.md, plan_revision_response.md, implementation_response.md
- 최초 계획 세션: session-20260911_072037_30babd.json
- 계획 보완 세션: session-20260911_072037_30babd-revised.json
- P1 구현까지 포함한 세션: session-20260911_072037_30babd-final.json
- 승인 기록 보관: approved-PLAN.md, approved-plan.json
- 자동 검사 기록 보관: check-start 1개, check-plan 3개, check-implemented 3개, check-final 1개
- 실행 로그 폴더: records/lesson07/probe-runs/p1-20260911T130648897341Z-383f34
- 보관 확인 방법: PowerShell에서 기록·응답·세션·승인·검사 파일과 실행 로그 폴더의 목록을 확인함
- 이번에 완료한 것: 계획 작성·검토·보완, P1 승인·구현, 세 사례 실행 검사, 최종 상태 검사와 기록 보관
- 이후에 확인할 것: P2 계산·보고서 생성, 전체 인수조건 검증, P3의 더 넓은 입력 검증
- 이번에 배운 점: 계획 승인과 구현 요청을 구분하고, 자동 검사 결과와 실제 출력 문장을 함께 확인해야 한다. 통과한 검사 범위를 넘어 전체 구현이 완료됐다고 판단하지 않는다.
````

**6-4. 저장된 결과를 확인합니다**

```powershell
Get-Item .\workspace\SPEC.md, .\workspace\PLAN.md, .\workspace\analyze_sales.py
Get-Item .\records\lesson07\plan_review.md
```

파일이 저장됐는지 확인한 뒤 관찰 기록을 다시 읽습니다. ‘확인 전’ 항목은 실행 로그와 대조해 채우고, 수행하지 않은 항목은 그 이유를 적습니다.

## 7) 완료 점검과 오류 복구

### 완료 점검

- [ ] PLAN에 P1·P2·P3, 변경 파일, 확인 방법, 중단 조건이 있다.
- [ ] 사람이 검토한 뒤 P1만 승인했고 승인 당시 계획을 보관했다.
- [ ] analyze_sales.py만 구현 대상으로 변경했다.
- [ ] 세 사례의 실제 종료코드·진단·기존 파일 유지를 확인했다.
- [ ] 실패·수정·재검사가 있었다면 모든 시도를 기록했다.
- [ ] 최종 검사와 Baseline 검사를 통과했다.
- [ ] 응답·세션·승인 계획·실행 로그·관찰 기록을 보관했다.
- [ ] P2·P3과 아직 수행하지 않은 검증을 남은 일로 적었다.

### 증상별로 먼저 확인하기

| 메시지나 증상 | 의미 | 다음 행동 |
|---|---|---|
| 스크립트가 서명되지 않음 | 내려받은 파일 실행 차단 | 해당 ps1에 Unblock-File 후 실패한 명령을 다시 실행 |
| Lesson07 already prepared / records already exist | 이미 진입점이 준비됨 | 현재 단계에서 계속. 처음부터 할 때만 restore |
| Lesson06 record needs section 4 | 인수조건 절을 찾지 못함 | 6교시 기록에 4절과 AC-01·AC-02·AC-03이 있는지 확인 |
| PLAN.md is still the blank template | 계획이 작업 파일에 저장되지 않음 | 실제 PLAN 작성 경로와 응답 확인 |
| Approve the reviewed plan | P1 승인 기록이 없음 | 계획을 검토한 뒤 approve, 이어서 P1 요청 |
| Approved plan differs / PLAN.md 차이 | 승인 후 계획 내용 변경 | 실제 변경과 이유 보관. 시작부터 재검토해야 하면 restore |
| FAIL quantity_zero: exit=0 | 오류 입력을 정상 종료로 처리 | stderr·SPEC·TASK를 대조해 P1 코드만 수정하고 test |
| 파일·설정 차이 | 허용 범위 밖의 변경 가능 | 출력과 Chat 보관, 변경 파일 확인. 필요하면 restore |
| timeout | 사례가 15초 안에 끝나지 않음 | 무한 대기·입력 요청 등의 원인을 P1 코드에서 확인 |
| No P1 probe report / 폴더 없음 | 검사기 시작·기록에 실패 | test의 원문, healthy, 코드와 승인 파일 존재 확인 |
| 최종 검사에서 이전 결과가 현재 코드와 다름 | 검사 후 코드를 변경함 | 현재 코드로 test를 다시 실행 |
| 공통 입력 해시가 다름 | 입력 파일이 변경되었거나 다른 자료임 | 공통 입력 원본 확인. restore는 inputs를 교체하지 않음 |
| Pending operation exists | 준비·복원이 중간에 멈춤 | pending 파일과 보관 폴더를 유지하고 강사에게 원문 전달 |

### 시작 상태로 돌아가야 할 때만 복원합니다

정상 진행에서는 이 절을 실행하지 않습니다. 파일을 잘못 바꾸거나 승인 범위를 넘겨 구현하여 다시 시작해야 할 때 사용합니다.

복원 시점은 **prepare 직후, 첫 계획 요청 전**입니다. 구체화된 SPEC와 인수조건은 유지된 진입점으로 돌아오고 PLAN은 빈 양식이 됩니다. P1 승인·구현·실행 로그는 현재 작업에서 빠지고 실패 시도 보관 폴더에 남습니다. 관련 설정과 Memory·Skill 파일도 진입점으로 복원합니다. 입력·앞 교시 기록·인증·세션 이력을 모두 되감는 기능은 아닙니다.

1. Hermes의 응답 생성을 멈추고, 현재 세션을 JSON으로 내보내 `records\lesson07`에 보관합니다. 오류 원문과 관찰 기록을 저장하고 메모장을 닫습니다.
2. PowerShell에서 실행합니다.

```powershell
Set-Location 'C:\AI-Native\harness-engineering'
Unblock-File -LiteralPath .\lesson03.ps1
Unblock-File -LiteralPath .\lesson07.ps1
.\lesson07.ps1 restore
```

**확인할 메시지:**

```text
RESTORE_PASS: Lesson07 entry restored; blank plan, no implementation or P1 approval.
BACKUP: records/lesson07-attempt-본인실행식별자
```

`BACKUP`은 복원 전 시도를 보관한 위치입니다. `lesson07-attempt-…`의 `attempt`는 한 번의 실습 시도를 뜻합니다. BACKUP 뒤의 실제 보관 경로를 기록합니다. 그 폴더의 `lesson07-records`에는 이번 기록과 승인 사본·실행 증거가 있고, `workspace-after-attempt`에는 복원 전 작업 내용이 있습니다. 3교시 Baseline은 복원 전후 검사합니다.

3. **prepare를 다시 실행하지 않고** Hermes를 시작합니다.

```powershell
docker compose up -d --force-recreate hermes
docker compose ps
```

복원한 Windows 작업 폴더를 다시 연결한 컨테이너가 `healthy`인지 확인합니다.

4. Web Dashboard에서 **New chat**을 열고 다음처럼 새 시도를 구분합니다.

```text
/title planning-lesson07-retry1
/model z-ai/glm-5.3-flash
/reasoning low
/status
```

5. PowerShell에서 시작 검사를 합니다.

```powershell
.\lesson07.ps1 check start
```

`START_READY`이면 새 `plan_review.md`의 1절에 시작 결과와 복원 경로를 기록한 뒤 **단계 2의 계획 요청부터** 진행합니다. 앞 시도의 승인이나 PASS를 새 시도의 결과로 옮기지 않습니다.

## 8) 핵심 내용과 다음 교시 준비

이번에는 완성 명세를 계획으로 나누고, P1만 승인해 입력 검사를 구현한 뒤 실제 동작을 확인했습니다. 계획에 적힌 일, 사람이 승인한 일, 실제 바뀐 파일, 검사에서 확인한 결과를 각각 연결했습니다.

8교시에서는 이 계획과 구현 초안을 바탕으로 **Agent가 어떤 도구를 어떤 범위에서 사용할지** 정리합니다. 도구 사용의 필요성과 범위를 판단할 실제 사례가 생겼습니다. 계산·보고서 생성과 전체 인수조건 검증은 PLAN에 남아 있으므로 이후 승인·구현·검증 대상으로 이어갑니다.
