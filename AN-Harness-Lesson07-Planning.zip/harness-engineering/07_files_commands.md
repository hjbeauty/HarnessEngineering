# 7교시 폴더·파일·명령 안내

**AI Native 소프트웨어 개발: Harness Engineering — 학습 가이드북**

가이드북 3절의 설명을 따로 찾아보기 위한 참고표입니다. 실습은 가이드북의 단계 순서로 진행합니다.

### 3.3 폴더별로 맡은 일을 알아둡니다

폴더 설명에 나오는 **prepare**는 실습 자료를 준비하는 동작, **checkpoint**는 검사와 복원에 쓸 시작 상태의 사본입니다. **해시(SHA-256)**는 파일 내용으로 계산하는 식별값으로, 전후 값이 같은지 비교해 내용이 유지됐는지 확인합니다.

**Memory**는 Agent가 다음 대화에도 참고할 기억, **Skill**은 재사용할 작업 방법과 지침입니다. 이번에는 이 파일들을 변경하지 않으며, 준비 당시와 같은지 검사합니다.

로그에 나오는 **stdout(표준 출력)**과 **stderr(표준 오류)**는 프로그램이 메시지를 내보내는 두 통로입니다. 이 실습 프로그램은 정상 안내를 stdout에, 오류 안내를 stderr에 씁니다. **JSON**은 항목 이름과 값을 짝지어 저장하는 텍스트 형식으로, 검사 결과와 세션 내보내기에 사용합니다.

| Windows 작업 폴더 아래 위치 | 쉬운 설명 | 내용과 사용하는 때 |
|---|---|---|
| inputs/ | 읽을 원본 | 200행 판매 데이터, 10행 확인용 데이터와 오류·관계 검사 파일. 관계 검사는 행 순서를 바꿔도 합계가 같은지처럼 입력 변화와 결과의 관계를 확인하는 시험. 이번에는 sales_micro.csv와 quantity_zero.csv 사용 |
| workspace/ | Agent의 작업 책상 | 읽을 명세·Context, 작성할 PLAN과 analyze_sales.py |
| workspace/context/ | 배경과 경계 | 업무상 의미·작성 관례·실행 환경·이번 변경 범위 |
| workspace/lesson07/ | 이번 작업 안내 | TASK, 두 요청 파일, 6교시 인수조건 사본, 승인 사본 |
| workspace/lesson07/checks/ | 검사 도중 생기는 로그 | 세 사례의 stdout·stderr·report.json. 검사 때 자동 생성 |
| workspace/outputs/lesson07-p1/ | 보존 확인용 폴더 | summary.csv와 report.md에 시험용 문장이 들어 있음. P1이 건드리지 않는지 확인 |
| records/lesson07/ | 내 관찰과 실행 증거 | plan_review.md, 응답·세션, 검사 JSON, 승인 기록과 실행 로그 사본 |
| records/lesson07/checkpoint/ | 시작 상태 보관함 | prepare 직후 파일·일부 설정·Memory·Skill 사본과 해시. 검사·복원에 사용 |
| records/lesson07/prior-workspace/ | 6교시 작업의 사본 | 7교시 준비 전 작업 내용 확인용 |
| starter/lesson07/ | 배포한 시작 문서 | prepare가 workspace에 옮기는 바탕 파일. 실습 중 수정하는 곳은 workspace |
| templates/ | 빈 기록 양식 | prepare가 plan_review.md를 만들 때 사용 |
| examples/ | 작성 방법 참고 | 단계별 관찰 기록과 전체 작성 예시. 본인의 증거로 바꿔 작성 |
| course-tools/ | 수업용 보조 프로그램 | 준비·검사·복원을 일정한 방식으로 수행. Agent의 구현 대상은 아님 |

`records/lesson07/workspace-before-prepare`에는 준비 전에 옮겨 둔 작업 폴더도 있습니다. 직접 편집할 관찰 기록과 보관 사본을 구분하세요. **checkpoint와 보관 사본은 그대로 두고, 관찰은 plan_review.md에 적습니다.**

### 3.4 주요 파일은 언제 읽고 쓰나요?

`.ps1`은 PowerShell 명령을 모아 둔 스크립트이고, `.py`는 Python 프로그램 파일입니다. `lesson07.ps1` 뒤에 동작 이름을 붙이면 **prepare는 준비, check는 상태 검사, approve는 승인 기록, test는 프로그램 실행 검사, restore는 복원**을 수행합니다.

**보조 컨테이너**는 준비·검사·복원 도구를 실행하는 동안 잠시 사용하는 컨테이너입니다. **일반 실습 컨테이너**는 Hermes Web Dashboard가 실행 중인 컨테이너이며, 작성한 프로그램도 이곳에서 검사합니다.

| 파일 | 역할과 주요 내용 | 누가 어떻게 다루나요? |
|---|---|---|
| compose.yaml | 사용할 이미지, 연결 폴더, 포트 등 실행 설정 | Docker Compose가 읽음. 이번에 수정하지 않음 |
| lesson07.ps1 | PowerShell 명령과 Docker 안의 보조 도구를 연결 | 교육생이 prepare·check·approve·test·restore를 지정해 실행 |
| course-tools/lesson07_planning.py | 시작점 보관, 파일·설정 비교, 승인 기록, 실행 증거 복사, 복원 | ps1이 보조 컨테이너에서 실행 |
| course-tools/lesson07_probe.py | 작성된 프로그램을 세 입력으로 실행하고 관찰 | ps1의 test가 일반 실습 컨테이너에서 실행 |
| workspace/SPEC.md | 완성 프로그램이 지킬 계약 | 사람이 읽고 Agent가 계획·구현의 근거로 사용 |
| workspace/lesson07/ACCEPTANCE.md | 6교시 기록의 4절 사본 | 준비 도구가 추출. Agent가 계획과 연결할 때 읽음 |
| workspace/lesson07/TASK.md | 이번에 승인할 P1의 범위와 중간 확인 방법 | 계획·구현 전에 읽음 |
| workspace/PLAN.md | P1·P2·P3의 변경·검증·중단 계획 | Agent가 계획 단계에 작성, 사람이 읽고 승인 |
| workspace/lesson07/approval.json | P1만 승인했다는 정보와 PLAN 해시 | approve가 생성. Agent가 구현 전에 읽음 |
| workspace/analyze_sales.py | 앞으로 완성할 판매 분석 프로그램 | 이번에는 Agent가 P1 입력 검사 부분만 작성 |
| records/lesson07/plan_review.md | 실제로 무엇을 보고 판단했는지 | 교육생이 단계마다 이어서 작성 |

`SPEC.md`는 **완성품의 계약**, `TASK.md`는 **지금 구현할 부분**, `PLAN.md`는 **구현과 확인의 순서**입니다. 예를 들어 완성품은 정상 입력에서 보고서를 만들지만, 지금 P1은 입력을 검사한 뒤 `INPUT_VALID rows=10`을 보여 주고 끝납니다. `INPUT_VALID`는 입력 검사를 통과했다는 뜻이고, `rows=10`은 확인한 데이터가 10행이라는 뜻입니다. 보고서 생성은 계획의 P2에 남깁니다.

### 3.5 ps1과 Python 프로그램의 관계

```mermaid
flowchart TD
  A["PowerShell · lesson07.ps1"] --> B["보조 컨테이너 · planning.py"]
  B --> C["진입점·승인·관찰 기록"]
  A --> D["일반 실습 컨테이너 · probe.py"]
  D --> E["analyze_sales.py 실행"]
  E --> F["종료코드·stdout·stderr"]
  F --> D
  D -->|검사 파일 수집| B
```

`lesson07.ps1`은 Windows에서 순서를 조정합니다. 현재 수업 폴더로 이동하고, 필요한 파일을 확인하고, 상황에 맞는 Docker 명령으로 Python 보조 도구를 실행합니다. 따라서 Windows에 별도로 Python을 설치해 이 보조 도구를 실행할 필요가 없습니다.

`lesson07_planning.py`는 준비·검사·복원에 필요한 파일 작업을 합니다. 예를 들어 `check plan`에서는 PLAN만 달라졌는지 비교하고, `approve`에서는 검토한 계획의 사본과 해시를 남깁니다. **계획 내용의 적절성은 사람이 읽어 판단합니다.** 도구가 PLAN의 P1·P2·P3 표기를 찾았다고 좋은 계획이 되는 것은 아닙니다.

`lesson07_probe.py`는 Agent가 만든 `analyze_sales.py`를 실제로 실행하는 검사기입니다. 프로그램의 종료코드와 출력 문장을 받아 기록하고, 준비한 두 파일의 해시가 유지되는지 확인합니다. 분석 프로그램을 대신 작성하거나 고쳐 주지는 않습니다.

| 입력하는 명령 | 왜 실행하나요? | 일어나는 일과 남는 결과 |
|---|---|---|
| .\lesson07.ps1 prepare | 이전 결과를 이어받아 같은 진입점에서 시작 | 6교시 최종 상태·Baseline 확인, 앞 작업 보관, 시작 파일·checkpoint·관찰 양식 준비, Hermes 시작 |
| .\lesson07.ps1 check start | 첫 요청 전에 출발 상태 확인 | 준비된 파일과 현재 파일·설정 비교, START_READY |
| .\lesson07.ps1 check plan | 계획 단계에서 구현을 시작하지 않았는지 확인 | PLAN 외의 예상하지 않은 변경 검사, check-plan JSON |
| .\lesson07.ps1 approve | 사람이 검토한 계획과 승인 범위를 고정 | PLAN 사본, 해시, P1 승인 JSON |
| .\lesson07.ps1 check implemented | 승인 범위 안에서 파일을 만들었는지 확인 | 승인 PLAN과 보호 대상 유지, analyze_sales.py 존재, check-implemented JSON |
| .\lesson07.ps1 test | 만든 프로그램의 실제 행동 확인 | 정상·수량 0·없는 입력 실행, 로그와 보존 여부 기록, P1_CHECK_PASS 또는 실패 |
| .\lesson07.ps1 check final | 현재 코드와 검사 결과가 연결되는지 확인 | 실행한 코드 해시와 현재 코드, 승인 PLAN·설정·파일·앞 기록 확인 |
| .\lesson03.ps1 verify | 최초 비교 기준 보존 확인 | 3교시 Baseline 무결성 검사 |
| .\lesson07.ps1 restore | 실수로 시작 상태로 돌아가야 할 때 | 현재 시도 보관, prepare 직후 상태 복원, Hermes는 중지 상태 |

이 명령들 자체는 모델에게 질문하지 않습니다. 모델을 사용하는 곳은 Hermes Chat에 계획·구현 요청을 보내는 단계입니다.


## Python 보조 도구 안에서는 어떤 일을 하나요?

코드를 전부 읽거나 수정해야 하는 실습은 아닙니다. 파일 이름과 명령이 어떤 동작으로 이어지는지 이해하기 위한 설명입니다.

| 프로그램의 주요 함수 | 하는 일 | 학생이 이 기능을 쓰는 때 |
|---|---|---|
| planning.py의 prepare | 6교시 작업을 보관하고 SPEC·인수조건을 이어받아 진입점과 관찰 양식 생성 | 첫 요청 전 prepare |
| planning.py의 compare | 단계에 맞는 파일 변경, 저장된 설정, Memory·Skill·입력·앞 기록 비교 | check start/plan/implemented/final |
| planning.py의 approve | 검토한 PLAN을 사본으로 보관하고 P1·계획 해시 기록 | 계획을 읽은 뒤 approve |
| planning.py의 collect | probe가 만든 실행 로그를 records에 복사하고 현재 코드와 연결 | test 후 ps1이 자동 실행 |
| planning.py의 restore | 시도와 관련 상태를 보관하고 checkpoint로 복원 | 문제가 있어 처음부터 시작할 때 |
| probe.py의 run | 세 입력을 각각 새 프로세스로 실행하고 종료코드·stdout·stderr·보존 여부 수집 | test가 자동 실행 |

관리 보조 도구는 실제 파일명 `lesson07_planning.py`, 검사기는 `lesson07_probe.py`입니다. 이 프로그램들은 OpenRouter에 모델 요청을 보내지 않습니다. 모델의 판단과 코드 작성은 Hermes Chat에서 일어납니다.

## 실행 로그 한 묶음

`records/lesson07/probe-runs/p1-실행식별자/` 안에는 report.json과 세 사례의 stdout·stderr 파일, 총 7개 파일이 생깁니다. report.json은 각 사례의 명령·기대/실제 종료코드·기본 진단 확인·보관 파일 유지·시간 초과·실행한 코드 해시를 포함합니다.

`check-…json`은 전체 실행 내역을 대신하지 않습니다. 계획·파일·저장된 설정의 검사는 check 파일, 실제 프로그램 행동은 probe 로그, Agent가 어떤 도구를 썼는지는 세션 JSON, 사람의 판단은 plan_review.md에서 확인합니다.


## 검사값과 기록 파일명을 구분하기

| 표시 | 대상과 읽는 방법 |
|---|---|
| `RECORDED: records/lesson07/check-plan-…json` | 검사 결과가 저장된 위치입니다. 파일명 뒤의 시각·식별자로 여러 검사 기록을 구분합니다. |
| 검사 JSON의 `spec_sha256` / `plan_sha256` | 각각 `workspace/SPEC.md` / `workspace/PLAN.md`의 내용으로 계산한 SHA-256 해시입니다. 파일의 내용이 같은지 비교하는 데 사용합니다. |
| `records/lesson07/approved-plan.json`의 `plan_sha256` | 승인 순간의 PLAN 해시입니다. `Get-Content .\records\lesson07\approved-plan.json`으로 열어 기록 3절에 복사합니다. |
| 실행 `report.json`의 `source_sha256` / `plan_sha256` | 실행한 `analyze_sales.py`와 승인한 PLAN의 해시입니다. 어떤 코드와 계획을 기준으로 시험했는지 연결합니다. |
| 실행 `report.json`의 `cases` | 세 사례의 결과 목록입니다. 각 사례에서 `actual_exit_code`, `checks.existing_outputs_preserved`, `passed`를 읽고, 실제 메시지는 사례별 stdout·stderr 파일에서 읽습니다. |
| 최종 검사 JSON의 `p1_probe_current_and_passed` | 마지막 실행 검사의 통과 여부와 현재 코드·승인 계획의 일치를 확인합니다. `check final`에서 판정하며, 시작·계획·구현 검사에서는 `null`입니다. |

해시의 긴 문자열을 외우거나 예시와 같게 만들 필요는 없습니다. 파일명은 기록을 찾아가는 이름이고, 해시는 검사 대상 파일의 내용을 비교하는 값입니다. 자세한 출력 예시와 기록 순서는 가이드북 단계 1·2·3·5·6에서 확인합니다.
