# Course coordinator. Agent-generated code is tested only in the normal container.
[CmdletBinding()]
param(
 [Parameter(Mandatory=$true)][ValidateSet('prepare','check','approve','test','restore')][string]$Action,
 [ValidateSet('start','plan','approved','implemented','final')][string]$Stage='start'
)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
Set-Location -LiteralPath $PSScriptRoot
foreach ($name in @('compose.yaml','.env','lesson03.ps1','lesson06.ps1','course-tools/lesson07_planning.py','course-tools/lesson07_probe.py','starter/lesson07/PLAN.md','templates/plan_review.md')) {
 if (-not (Test-Path -LiteralPath $name -PathType Leaf)) { throw "Required file missing: $name" }
}
if (Test-Path -LiteralPath '.\records\lesson07-pending.json') { throw 'Interrupted operation. Preserve lesson07-pending.json and backups; do not repeat.' }
function Invoke-CourseHelper([string]$Verb,[string]$Phase='start') {
 & docker compose run --rm --no-deps -T --user hermes --workdir /tmp --entrypoint python --volume "${PSScriptRoot}:/course-host" hermes /course-tools/lesson07_planning.py $Verb $Phase
 if ($LASTEXITCODE -ne 0) { throw "Lesson07 $Verb stopped. Preserve output; see the guide." }
}
if ($Action -eq 'prepare') {
 if (Test-Path -LiteralPath '.\records\lesson07') { throw 'Lesson07 already prepared. Continue from your stage, or use restore.' }
 & .\lesson06.ps1 check final
 if (-not $?) { throw 'Complete Lesson06 before preparing Lesson07.' }
}
if ($Action -in @('prepare','restore')) {
 & .\lesson03.ps1 verify
 if (-not $?) { throw 'Baseline integrity failed.' }
 & docker compose stop hermes
 if ($LASTEXITCODE -ne 0) { throw 'Could not stop Hermes. No lesson files changed.' }
}
if ($Action -eq 'test') {
 Invoke-CourseHelper 'check' 'implemented'
 # No /course-host mount is added here. Never run generated code in the management helper.
 & docker compose exec -T --user hermes --workdir /workspace --env PYTHONDONTWRITEBYTECODE=1 hermes python /course-tools/lesson07_probe.py
 $probeExit=$LASTEXITCODE
 Invoke-CourseHelper 'collect'
 if ($probeExit -ne 0) { throw 'Probe process failed. Preserve its output and report.' }
} else { Invoke-CourseHelper $Action $Stage }
if ($Action -in @('prepare','restore')) {
 & .\lesson03.ps1 verify
 if (-not $?) { throw 'Baseline verification failed after operation. Preserve records.' }
}
if ($Action -eq 'prepare') {
 & docker compose up -d --force-recreate hermes
 if ($LASTEXITCODE -ne 0) { throw 'Files prepared; startup failed. Check logs; do not repeat prepare.' }
 Write-Host 'Next: check healthy, open a NEW Hermes Chat, then .\lesson07.ps1 check start'
}
if ($Action -eq 'restore') {
 Write-Host 'Hermes is stopped. Next: docker compose up -d --force-recreate hermes'
 Write-Host 'Then healthy, NEW Chat, .\lesson07.ps1 check start. Do not repeat prepare.'
}
