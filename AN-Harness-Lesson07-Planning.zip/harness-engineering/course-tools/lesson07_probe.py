"""P1 smoke checks. Runs only in normal Dashboard container, without /course-host.
Does not grade the whole SPEC or the quality of the implementation/plan.
"""
import hashlib,json,os,re,signal,subprocess,sys,uuid
from pathlib import Path
from datetime import datetime,timezone
TIMEOUT=15

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(ws=Path('/workspace'),inputs=Path('/inputs')):
    if Path('/course-host').exists():raise RuntimeError('Do not run Agent-generated code in the management container.')
    src=ws/'analyze_sales.py';approval=ws/'lesson07/approval.json'
    for p in (ws,src,approval,ws/'outputs',ws/'outputs/lesson07-p1',ws/'lesson07',ws/'lesson07/checks'):
        if p.is_symlink():raise RuntimeError('Probe paths must not be symbolic links.')
    a=json.loads(approval.read_text())
    if a['approved_step']!='P1' or sha(ws/'PLAN.md')!=a['plan_sha256']:raise RuntimeError('Plan differs from approved P1.')
    output=ws/'outputs/lesson07-p1'
    targets=[output/'summary.csv',output/'report.md']
    if any(p.is_symlink() or not p.is_file() for p in targets):raise RuntimeError('Preservation files are missing or linked.')
    before={p.name:sha(p) for p in targets}
    missing=inputs/'lesson07-file-does-not-exist.csv'
    if missing.exists():raise RuntimeError('Missing-input fixture unexpectedly exists.')
    runid='p1-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')+'-'+uuid.uuid4().hex[:6]
    folder=ws/'lesson07/checks'/runid;folder.mkdir()
    source_hash=sha(src)
    cases=[('valid_micro',inputs/'sales/sales_micro.csv',0),('quantity_zero',inputs/'sales/errors/quantity_zero.csv',2),('missing_input',missing,2)]
    results=[]
    for name,path,expected in cases:
        cmd=[sys.executable,str(src),'--input',str(path),'--output-dir',str(output)]
        env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1'
        proc=subprocess.Popen(cmd,cwd=ws,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,encoding='utf-8',errors='replace',start_new_session=True)
        timeout=False
        try:stdout,stderr=proc.communicate(timeout=TIMEOUT)
        except subprocess.TimeoutExpired:
            timeout=True;os.killpg(proc.pid,signal.SIGKILL);stdout,stderr=proc.communicate()
        (folder/(name+'.stdout.txt')).write_text(stdout,encoding='utf-8')
        (folder/(name+'.stderr.txt')).write_text(stderr,encoding='utf-8')
        preserved=all(p.is_file() and not p.is_symlink() and sha(p)==before[p.name] for p in targets)
        diagnostics=('INPUT_VALID rows=10' in stdout) if name=='valid_micro' else (bool(re.search(r'(?<!\d)5(?!\d)',stderr)) and 'quantity' in stderr) if name=='quantity_zero' else ('INPUT_NOT_FOUND' in stderr)
        checks={'exit_code_matches':proc.returncode==expected,'diagnostic_matches':diagnostics,'existing_outputs_preserved':preserved,'no_timeout':not timeout}
        result={'case':name,'command':cmd,'expected_exit_code':expected,'actual_exit_code':proc.returncode,'checks':checks,'passed':all(checks.values())}
        results.append(result);print(('PASS ' if result['passed'] else 'FAIL ')+name+': exit='+str(proc.returncode)+', outputs_preserved='+str(preserved))
    report={'scope':'P1 three-case smoke checks only; not whole-SPEC acceptance. Diagnostics need human review.','run_id':runid,'source_sha256':source_hash,'plan_sha256':a['plan_sha256'],'cases':results,'source_unchanged':src.is_file() and sha(src)==source_hash,'passed':all(x['passed'] for x in results) and src.is_file() and sha(src)==source_hash}
    (folder/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print('PROBE_REPORT: '+str(folder/'report.json'));return report

if __name__=='__main__':
    try:
        if os.getuid()==0:raise RuntimeError('Run as hermes, not root.')
        sys.exit(0 if run()['passed'] else 1)
    except Exception as e:print('PROBE_STOP: '+str(e),file=sys.stderr);sys.exit(1)
