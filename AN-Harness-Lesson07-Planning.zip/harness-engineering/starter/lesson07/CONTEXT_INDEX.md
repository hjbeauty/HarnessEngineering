# Context를 읽는 순서

적용 범위: 7교시 계획과 P1 입력 검사 구현.

1. context/constraints.md: 현재 단계의 변경 범위
2. context/environment.md: 6교시에서 확인하고 이어받은 실행 환경
3. context/sales_business_context.md: 판매 데이터의 의미
4. context/conventions.md: 작성 관례
5. SPEC.md: 6교시에서 구체화한 공통 판매 명세
6. lesson07/ACCEPTANCE.md: 교육생이 6교시에서 작성한 인수조건
7. lesson07/TASK.md: 7교시의 P1 범위와 확인 방법
8. PLAN.md: 작성할 계획 또는 승인 후 따를 계획

이번에는 요청이 지정한 단계만 수행합니다. 계획에서는 PLAN.md만 작성합니다. P1 승인 후에는 analyze_sales.py만 작성합니다. 명세·Context·요청·설정·Memory·Skill은 수정하지 않습니다. 근거 없는 사실은 추측하지 말고 질문으로 남깁니다.
