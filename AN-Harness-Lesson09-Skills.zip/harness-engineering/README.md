# 9교시 Skill 작성과 재사용
09_skills_standardization_preview.html 또는 Markdown 가이드를 읽습니다.
ZIP의 harness-engineering 폴더 내용을 기존 C:\AI-Native\harness-engineering에 합칩니다. 기존 작업과 기록은 보존합니다.
8교시 P2 통과 기록·코드·출력·tool_audit.md가 필요합니다. 2·3교시 환경과 모델 연결이 준비되어 있어야 합니다.

진행 순서: prepare → healthy·작성 Chat·check start → 8교시 자료에서 절차 정리 → Skill 작성·check skill → freeze → 새 Chat·check frozen → 재사용·check reused → 적용 기록·check final·Baseline 확인.

프로젝트 Skill을 명시적으로 읽습니다. 분석 코드는 새로 실행하지 않으며 Memory·런타임 Skill은 유지합니다. 10교시의 넓은 독립 검증으로 이어갑니다.
빈 양식은 templates/skill_review.md, 가상 누적 예시는 examples/skill_progression.md에 있습니다.
restore는 필요할 때만 사용합니다. 복원 후 prepare를 반복하지 않고 컨테이너 시작·새 Chat·check start 후 절차 정리부터 진행합니다.
