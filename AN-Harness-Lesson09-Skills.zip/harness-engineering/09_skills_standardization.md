# 9교시. Skills — 검토 절차를 작성하고 새 Chat에서 재사용하기

**AI Native 소프트웨어 개발: Harness Engineering — 학습 가이드북**

## 1) 이번 교시에서 해결할 문제

8교시에서는 판매 분석 결과를 읽으며 정상 집계, 반복 실행, 오류 처리와 기존 결과 보존을 확인했습니다. 새 Chat에서 같은 검토를 맡길 때 그 순서와 확인 기준을 매번 설명해야 할까요?

이번에는 이 절차를 **Skill**, 즉 다음 작업에서도 읽고 사용할 수 있는 작업 절차 파일로 정리합니다. 사람이 내용을 검토한 뒤 새 Chat에서 실제로 읽어 적용하는지 확인합니다.

**8교시의 실행 결과를 재료로, 9교시에서는 검토 방법을 재사용 가능한 문서로 만듭니다.** 코드를 다시 구현하거나 실행하는 교시는 아닙니다.

## 2) 학습목표와 완료 상태

- Context의 사실, SPEC의 요구, Skill의 절차를 구분합니다.
- 8교시 관찰에서 반복할 검토 방법을 정리합니다.
- 프로젝트 SKILL.md를 작성·검토하고 새 Chat에서 명시적으로 읽게 합니다.
- 실제 읽기와 적용 근거, 남은 검증 항목을 기록합니다.

완료하면 **Skill 정본, 사람이 검토한 기록, 새 Chat의 재사용 결과와 도구 이력**이 남습니다. Skill을 저장했다는 응답만으로 완료하지 않고, 파일과 실제 읽기·적용 내용을 확인합니다.

## 3) 시작 전 준비와 파일의 역할

### 8교시에서 이어받는 것

2·3교시의 환경과 모델 연결을 마치고, 8교시의 `P2_CHECK_PASS`, `CHECK_PASS: final`, `BASELINE_INTEGRITY_PASS`와 관찰 기록을 갖춘 상태에서 진행합니다. Baseline은 최초 실행을 비교 기준으로 보존한 기록입니다.

준비 도구는 현재 P2 코드·PLAN·정책·두 결과 파일이 8교시 통과 기록과 같은지 확인합니다. `tool_audit.md`도 준비되어야 합니다. 파일이 존재한다고 기록 내용까지 완성됐다는 뜻은 아니므로 8교시의 판단과 남은 항목이 적혀 있는지 읽습니다.

### Windows와 두 종류의 컨테이너

| 공간 | 역할과 경로 |
|---|---|
| Windows 프로젝트 | 교육생이 명령을 입력하고 records에 기록을 보관 |
| 일반 Hermes 컨테이너 | Windows workspace가 /workspace로 연결됨. Agent가 문서를 읽고 작성 |
| 관리용 보조 컨테이너 | 프로젝트 전체를 /course-host로 연결해 준비·백업·검사·복원 수행 |

`/course-host`는 관리 컨테이너에서 Windows 프로젝트를 바라보는 경로입니다. `/course-host/records`는 Windows 프로젝트의 records와 같은 위치입니다. 별도의 파일 복사본이 아니라 연결된 경로이며, 스크립트가 필요한 컨테이너를 띄우므로 교육생이 직접 이동하지 않습니다.

### 폴더와 파일을 읽는 순서

| 경로 | 주요 내용·목적 | 생성 주체와 교육생의 행동 |
|---|---|---|
| starter/lesson09/entry | Context·TASK·CASE·요청문 | prepare가 workspace에 배치 |
| starter/lesson09/candidate/SKILL.md | 이름·설명이 있는 빈 초안 | prepare가 프로젝트 Skill 위치에 복사 |
| workspace/SPEC.md·PLAN.md·TOOL_POLICY.md | 명세·계획·도구 사용 범위 | 앞 교시 자료를 읽기 |
| workspace/analyze_sales.py | 8교시 P2 코드 | 그대로 유지 |
| workspace/lesson09/TASK.md | 이번 작성·재사용 범위와 결과 항목 | 작성 전 읽기 |
| workspace/lesson09/CASE.md | 검토할 증거 위치 | 지정한 자료를 찾는 안내 |
| workspace/lesson09/evidence/p2-report.json | 8교시 검사 프로그램의 실행 기록 | prepare가 복사. 종료코드·검사 결과·해시 읽기 |
| workspace/lesson09/evidence/summary.csv | 집계 수치와 순서 | prepare가 복사. SPEC과 대조 |
| workspace/lesson09/evidence/report.md | 사람이 읽는 판매 보고서 | prepare가 복사. 필수 내용·한국어·원 단위·해석 검토 |
| workspace/lesson09/evidence/tool_audit.md | 8교시 교육생의 관찰과 판단 | prepare가 복사. 실제 증거와 함께 참고 |
| workspace/lesson09/skill_request.txt | Skill 작성 요청 | 첫 Chat에 원문 전송 |
| workspace/lesson09/reuse_request.txt | Skill 적용 요청 | 새 Chat에 원문 전송 |
| workspace/skills/csv-report/SKILL.md | 재사용할 검토 절차 정본 | Agent 작성, 교육생 검토 후 동결 |
| workspace/lesson09/REVIEW.md | 새 Chat의 검토 결과 | Agent 작성, 교육생이 적용 여부 확인 |
| records/lesson09/skill_review.md | 교육생의 관찰 기록 | 같은 파일의 1~5절을 순서대로 채움 |
| records/lesson09/frozen-SKILL.md·frozen-skill.json | 검토한 Skill 사본과 내용 해시 | freeze가 생성. 재사용에 쓴 버전 확인 |
| records/lesson09/reuse/REVIEW.md·result.json | 재사용 결과와 연결 정보 | check reused가 보관 |
| records/lesson09/check-*.json | 파일·저장 설정의 단계별 검사 | check가 생성. 차이와 유지 여부 확인 |
| records/lesson09/checkpoint | 첫 Skill 작성 전 복원 지점 | 관리 도구가 보관. 직접 수정하지 않음 |
| templates/skill_review.md | 빈 기록 양식 | prepare가 records에 복사 |
| examples | 가상 누적 기록과 참고 Skill | 작성 방법 참고. 자신의 결과로 대체 |

`p2-report.json`은 **검사 기록**, `report.md`는 **판매 보고서**입니다. 비슷한 이름이지만 확인하는 내용이 다릅니다. tool_audit.md의 의견도 실행 기록 자체를 대신하지 않습니다.

### 명령은 무엇을 위해 쓰는가

`lesson09.ps1`은 Windows에서 사용하는 명령 창구입니다. 작업 위치를 맞추고 앞 교시·Baseline을 확인하며 관리 도구를 호출합니다. prepare·freeze는 작업 중인 Agent가 멈춘 상태에서 수행하고, 처리 후 일반 Hermes 컨테이너를 다시 시작합니다.

`course-tools/lesson09_learning.py`는 파일 준비·사본 보관·해시 비교·복원을 수행하는 Python 프로그램입니다. 생성된 분석 코드를 실행하거나 Agent를 호출하지 않습니다. 해시는 파일 내용으로 계산한 표식이며 의미의 정확성 점수가 아닙니다.

| 명령 | 목적 | 파일 변화 |
|---|---|---|
| prepare | 8교시 확인·보존, 작성 진입점 준비 | 빈 Skill·증거 사본·기록 양식 배치 |
| check start | 작성 전 상태 확인 | 검사 기록 생성 |
| check skill | Skill 작성 범위 확인 | 검사 기록 생성 |
| freeze | 검토한 Skill 사본과 해시 고정 | 동결 기록 생성, 코드·출력 유지 |
| check frozen | 재사용 전 동결 상태 확인 | 검사 기록 생성 |
| check reused | 재사용 결과와 변경 범위 확인 | 결과 사본·연결 정보·검사 기록 생성 |
| check final | 동결 Skill·보관 결과·보호 대상 유지 확인 | 검사 기록 생성 |
| restore | 현재 시도 보관 후 첫 작성 직전으로 복원 | 빈 Skill과 시작 설정으로 복원 |

이번 교시의 검사 명령은 파일·설정 유지와 보관을 확인합니다. 분석 프로그램을 실행하는 test 명령은 사용하지 않습니다. 명령표는 역할 안내이며 실제 입력은 아래 단계 순서대로 합니다.

## 4) 실습에 필요한 핵심 개념

| 구분 | 질문 | 이번 예 |
|---|---|---|
| Context | 무엇을 알아야 하나? | 실제 단가에는 할인이 이미 반영됨 |
| SPEC | 무엇을 만족해야 하나? | 오류 입력에서 기존 출력의 바이트를 유지 |
| Skill | 어떤 순서로 확인할까? | 오류 코드와 파일별 전후 해시를 함께 대조 |
| 실행 증거 | 실제로 무엇이 일어났나? | 저장된 actual_exit_code와 checks |
| 사람의 관찰 | 무엇을 읽고 판단했나? | tool_audit.md의 보고서 내용 검토 |

Skill에는 특정 매출 정답이나 현재 실행 ID 대신 **현재 명세와 증거를 읽는 절차**를 넣습니다. 단, 현재 작업의 쓰기 경계와 중단 조건은 분명하게 적습니다.

프로젝트 Skill은 workspace 아래의 정본 파일입니다. 이번에는 경로를 지정해 읽으며, Hermes에 설치된 Skill이나 Memory를 변경하지 않습니다. 이 방식을 이해한 뒤 10교시에서는 더 넓은 검증으로 이어갑니다.

### 자동 검사와 의미 검토

종료코드 0은 정상 처리, 2는 입력 오류입니다. 오류 입력을 기대대로 거부했다면 검사 자체는 통과할 수 있습니다. `report_utf8_nonempty`는 report.md가 비어 있지 않고 UTF-8로 읽힌다는 뜻이며 문장 내용의 정확성은 별도 검토합니다.

**8교시 실행 보고서 구조 발췌 예시:** 전체 파일에는 정상 첫 실행·명령·전후 해시 등도 있습니다.

```json
{
  "cases": [
    {
      "case": "repeat_micro",
      "actual_exit_code": 0,
      "checks": {
        "summary_matches": true,
        "report_utf8_nonempty": true,
        "repeat_bytes_equal": true
      }
    },
    {
      "case": "quantity_zero",
      "actual_exit_code": 2,
      "checks": {
        "diagnostic_matches": true,
        "existing_outputs_preserved": true
      },
      "before_output_hashes": {
        "summary.csv": "<CSV 해시>",
        "report.md": "<보고서 해시>"
      },
      "after_output_hashes": {
        "summary.csv": "<같은 CSV 해시>",
        "report.md": "<같은 보고서 해시>"
      }
    }
  ],
  "passed": true
}
```
`summary_matches`는 CSV 값·순서의 기준 일치, `repeat_bytes_equal`은 반복 실행의 파일별 바이트 동일, `existing_outputs_preserved`는 오류 전후의 기존 파일 유지 여부입니다. 같은 이름의 파일을 전후로 비교하며 summary.csv와 report.md끼리 같아야 하는 것은 아닙니다.

### 읽기·적용·완료 구분

“Skill을 읽었다”는 도구 호출로 확인합니다. “절차를 적용했다”는 REVIEW.md의 판단과 해당 절차를 대조해 확인합니다. 특정 항목의 증거가 없으면 미확인과 필요한 자료를 남깁니다. 네 실행 통과를 전체 명세 검증으로 확대하지 않습니다.

## 5) 전체 작업 흐름

```mermaid
flowchart TD
  E["8교시 출력·실행 기록·관찰"] --> S["반복할 절차를 Skill로 작성"]
  S --> H{"내용 검토"}
  H -->|보완 필요| S
  H -->|적절함| F["동결 후 새 Chat에서 재사용"]
  F --> R["실제 읽기·적용 확인과 기록"]
```

작성 Chat은 절차를 만들고, 새 Chat은 그 파일을 읽어 검토를 수행합니다. 동결은 사람이 검토한 파일을 사본과 해시로 고정하는 과정입니다.

## 6) 단계별 실습

아래 출력은 예상 형식이며 기록은 가상 작성 예시입니다. `<…>`에는 자신의 파일명·해시가 들어갑니다. 통과 여부와 적용 판단은 직접 확인하고 기록합니다.

### 단계 1. 준비하고 시작 상태 기록하기

#### 1-1. ZIP과 파일 확인

ZIP 안 harness-engineering 폴더의 내용을 기존 프로젝트에 합칩니다. PowerShell에서 입력합니다.

```powershell
Set-Location 'C:\AI-Native\harness-engineering'
Get-Location
Test-Path .\compose.yaml
Test-Path .\lesson09.ps1
Test-Path .\course-tools\lesson09_learning.py
Test-Path .\starter\lesson09\candidate\SKILL.md
Test-Path .\templates\skill_review.md
Test-Path .\records\lesson08\latest-probe.json
Test-Path .\records\lesson08\tool_audit.md
Test-Path .\workspace\outputs\lesson08-p2\summary.csv
Test-Path .\workspace\outputs\lesson08-p2\report.md
```
각 Test-Path가 True인지 확인합니다. False이면 해당 자료를 먼저 갖춥니다.

#### 1-2. 준비와 healthy 확인

```powershell
Unblock-File -LiteralPath .\lesson03.ps1
Unblock-File -LiteralPath .\lesson08.ps1
Unblock-File -LiteralPath .\lesson09.ps1
.\lesson09.ps1 prepare
docker compose ps
```
Unblock-File은 내려받은 스크립트의 차단 표시를 해제합니다. prepare 주요 출력 예시는 다음과 같습니다. 컨테이너 메시지와 검사 JSON은 생략했습니다.

```text
PREFLIGHT_PASS: Lesson08 P2 code, contracts and outputs match its saved result.
CHECK_PASS: final
BASELINE_INTEGRITY_PASS
PREPARE_PASS: Lesson08 preserved; Skill writing entry and evidence copies ready.
BASELINE_INTEGRITY_PASS
Next: check healthy and open a NEW Hermes Chat.
```
STATUS가 healthy인지 확인합니다. health: starting이면 잠시 후 docker compose ps로 다시 조회합니다.

```text
NAME                         STATUS
an-harness-course-hermes-1    Up 20 seconds (healthy)
```
#### 1-3. 작성 Chat과 시작 검사

새 Hermes Chat에 다음을 한 줄씩 입력합니다.

```text
/title skills-lesson09-author
/model z-ai/glm-5.3-flash
/reasoning low
/status
```
모델과 low 설정을 화면에서 확인하고 PowerShell에서 시작 검사를 합니다.

```powershell
.\lesson09.ps1 check start
notepad .\records\lesson09\skill_review.md
```

```json
{
  "stage": "start",
  "workspace_matches": true,
  "workspace_differences": [],
  "settings_match": true,
  "settings_differences": [],
  "runtime_memory_and_skills_unchanged": true,
  "common_inputs_unchanged": true,
  "earlier_lesson_records_unchanged": true,
  "saved_review_unchanged": null,
  "p2_source_sha256": "<현재 analyze_sales.py 해시>",
  "reuse_request_sha256": "<재사용 요청문 해시>",
  "skill_sha256": "<빈 Skill 초안 해시>",
  "scope": "File and saved-setting observations only. Confirm actual Skill reading, application and review quality in the Chat."
}
```

```text
RECORDED: records/lesson09/check-start-<시각과 식별자>.json
START_READY
```
`p2_source_sha256`은 P2 코드, `reuse_request_sha256`은 재사용 요청문, `skill_sha256`은 프로젝트 Skill의 내용 해시입니다. Skill을 작성하면 마지막 값이 바뀝니다. 기록 파일명의 시각·식별자와 구분합니다. `saved_review_unchanged`는 보관한 재사용 결과의 유지 여부이며 아직 결과가 없어 null입니다. `runtime_memory_and_skills_unchanged`는 설치된 Memory·Skill을 뜻하고 작성할 프로젝트 파일과 구분합니다.

메모장에서 **1절만** 채워 저장합니다.

```markdown
## 1. 시작 상태
- 작성자 / 날짜: 본인 이름 / 실습 날짜
- 모델 / 추론 설정: z-ai/glm-5.3-flash / low
- 이어받은 자료: 8교시 SPEC·PLAN·정책·P2 코드·두 출력·실행 보고서·tool_audit.md
- prepare / healthy / check start 결과: PREPARE_PASS / healthy / START_READY
- 시작 검사 파일 / 코드 해시: 자신의 실제 값
- 작성 Chat / 세션 JSON: skills-lesson09-author / 내보내기 전
```
### 단계 2. 8교시에서 반복할 검토 절차 찾기

PowerShell에서 다음 파일을 엽니다. 이 단계는 교육생이 자료를 읽고 작성 방향을 정하는 시간입니다.

```powershell
notepad .\workspace\lesson09\TASK.md
notepad .\workspace\lesson09\CASE.md
notepad .\workspace\lesson09\evidence\tool_audit.md
Get-Content -Raw -Encoding utf8 .\workspace\lesson09\evidence\p2-report.json
notepad .\records\lesson09\skill_review.md
```
실제 확인한 행동을 절차로 바꿔 봅니다. 없는 실패를 만들어 적지 않습니다.

| 8교시에서 한 확인 | Skill에 남길 절차 |
|---|---|
| summary.csv의 수치와 순서 읽기 | 현재 SPEC·CSV의 값과 순서를 대조 |
| 반복 실행에서 같은 파일 해시 비교 | 파일별 실행 전후 해시를 비교 |
| 수량 0·없는 입력의 오류와 보존 확인 | 오류 진단과 기존 결과 보존을 구분 |
| report.md 의미를 직접 읽기 | 자동 UTF-8 판정과 사람이 읽는 내용을 구분 |
| P3는 남아 있다고 기록 | 확인 범위와 남은 검사를 따로 쓰기 |

**2절의 관찰·근거·절차·넣지 않을 정보 네 항목부터** 작성합니다. 도구·검사·보완 항목은 다음 단계에서 채웁니다. 금액·실행 ID·답변 완성 문장을 Skill에 복사하지 않습니다.

### 단계 3. Skill 작성과 내용 검토

#### 3-1. 작성 요청 전송

```powershell
Get-Content -Raw -Encoding utf8 .\workspace\lesson09\skill_request.txt | Set-Clipboard
```
작성 Chat에 원문 전체를 전송합니다.

```text
/workspace/CONTEXT_INDEX.md를 읽고 지정 문서를 순서대로 읽으세요.
CASE에 지정된 8교시 실행 보고서·결과 CSV·판매 보고서·관찰 기록을 읽으세요.
이 자료를 검토할 때 반복해서 사용할 절차를 /workspace/skills/csv-report/SKILL.md에 작성하세요.
name은 csv-report로 하고 description에는 저장된 CSV 보고서와 실행 기록의 검토에 쓰는 절차임을 적으세요.
사용 조건, 필요한 근거, 검토 순서, 결과에 남길 증거, 정보 부족·범위 밖 요청의 중단 조건을 담으세요.
고정 매출 숫자·실행 ID·완성 답변은 넣지 말고 현재 명세와 증거를 읽도록 하세요.
8교시 관찰 기록의 의견은 실제 명세·실행 증거와 대조하고, 근거가 없는 판단은 그대로 절차로 옮기지 마세요.
이 SKILL.md만 수정하세요. 코드 실행·구현·외부 접속·설정·Memory·런타임 Skill 변경은 하지 마세요.
읽은 파일·사용한 도구·변경 파일과 어떤 근거에서 어떤 절차를 정리했는지 요약하고 멈추세요.
```
Skill 맨 앞 `---` 사이 name·description은 이름과 사용 조건을 알려주는 머리말입니다. 본문에 사용 조건·근거·절차·완료 증거·중단 조건을 담습니다. 파일을 작성한 뒤 요약 응답에서 멈추면 다음 검사로 갑니다.

#### 3-2. 작성 범위와 내용 확인

```powershell
.\lesson09.ps1 check skill
notepad .\workspace\skills\csv-report\SKILL.md
notepad .\records\lesson09\skill_response.md
```
**검사 출력 발췌 예시:**

```json
{
  "stage": "skill",
  "workspace_matches": true,
  "workspace_differences": [],
  "skill_sha256": "<작성한 Skill 해시>"
}
```

```text
RECORDED: records/lesson09/check-skill-<시각과 식별자>.json
CHECK_PASS: skill
```
CHECK_PASS는 허용한 파일 변경과 보호 대상 유지 확인입니다. 다음 내용은 사람이 읽고 판단합니다.

| 검토 항목 | 적절한 내용 |
|---|---|
| 사용 조건 | 저장된 CSV 결과와 실행 증거 검토 |
| 근거 | 현재 명세·결과·실행 기록을 읽음 |
| 절차 | 정상·반복·오류·보존·의미·남은 검사 구분 |
| 정보 부족 | 미확인과 필요한 자료를 보고 |
| 변경 범위 | 이번 요청의 검토 파일만 작성 |

`skill_response.md`에는 파일 작성 뒤 Agent의 **마지막 요약 응답 전체**를 그대로 저장합니다. 요청문·상태줄·긴 diff는 넣지 않습니다. 실제 도구 호출과 전체 대화는 작성 Chat을 JSON으로 내보내 records/lesson09에 보관합니다. 교육생마다 다운로드 파일명이 다르므로 실제 이름을 기록합니다.

보완이 필요할 때만 같은 Chat에 해당 내용의 수정을 요청합니다. 예를 들면:

```text
SKILL.md의 완료 조건을 보완하세요.
확인한 사례와 아직 검증하지 않은 범위를 구분하고, 근거가 없으면 미확인과 필요한 자료를 적도록 하세요.
SKILL.md만 수정하고 변경 내용을 요약한 뒤 멈추세요.
```
보완 응답은 skill_revision_response.md에 따로 보관하고 check skill을 다시 실행합니다. 결과와 내용이 맞으면 **2절 전체를 갱신**합니다. 아래는 보완이 필요 없었던 가상 예시입니다.

```markdown
## 2. 반복 절차 정리와 Skill 검토
- 관찰 / 근거: 8교시에서 오류 종료코드 2와 기존 결과 보존을 함께 확인했다. 근거는 p2-report.json의 오류 사례와 파일별 전후 해시다.
- 재사용할 절차: 정상 결과, 반복 실행, 오류와 보존, 보고서 의미, 남은 검사를 구분해 읽는다.
- 넣지 않은 정보: 고정 매출 정답·실행 ID·완성 답변
- 실제 도구 / 변경 파일: 자신의 실제 도구와 횟수 / skills/csv-report/SKILL.md
- 작성 응답 보관: skill_response.md
- 검토 의견: 현재 명세와 증거를 읽고 근거 없는 판단은 미확인으로 남기는 절차가 포함됐다.
- 보완 요청 / 결과: 이 가상 예시에서는 보완 불필요. 실제 보완했다면 요청과 결과·새 검사 파일명을 적는다.
- check skill: CHECK_PASS: skill / 자신의 실제 검사 파일명
- 현재 판단: 내용을 검토했으며 동결할 준비가 됐다. 새 Chat의 재사용은 아직 수행 전이다.
```
### 단계 4. 검토한 Skill 동결과 새 Chat 준비

작성 Chat의 작업이 끝났고 내용이 적절하면 PowerShell에서 입력합니다. 동결은 검토한 정본을 사본·해시로 보관하는 작업입니다.

```powershell
.\lesson09.ps1 freeze
docker compose ps
Get-Content -Raw -Encoding utf8 .\records\lesson09\frozen-skill.json
```

```text
RECORDED: records/lesson09/check-skill-<시각과 식별자>.json
RECORDED: records/lesson09/check-frozen-<시각과 식별자>.json
FROZEN_READY: reviewed project Skill saved. Open a NEW Chat for reuse.
```

```json
{
  "skill_sha256": "<검토한 Skill 해시>",
  "created_utc": "<동결 시각과 식별자>",
  "scope": "Reviewed project procedure for reuse. No runtime installation or code execution permission."
}
```
`created_utc`는 시점, `skill_sha256`은 정본 내용의 값입니다. 이후 정본이 바뀌면 검사에서 차이를 보고합니다. freeze는 파일 보관이며 런타임 Skill 설치나 코드 실행 승인이 아닙니다.

healthy를 확인한 뒤 **새 Chat**을 만들고 다음을 입력합니다.

```text
/title skills-lesson09-reuse
/model z-ai/glm-5.3-flash
/reasoning low
/status
```

```powershell
.\lesson09.ps1 check frozen
```
CHECK_PASS: frozen을 확인합니다. **3절을 시작**하고 동결 해시·새 Chat·검사 파일명을 적습니다. 재사용 요청은 다음 단계에서 보낸 뒤 전송 상태를 갱신합니다.

```markdown
## 3. 동결과 재사용 준비
- freeze 결과: FROZEN_READY
- 동결 기록 / Skill 해시: frozen-skill.json / 자신의 실제 skill_sha256
- 재사용 Chat / 모델 / 추론 설정: skills-lesson09-reuse / z-ai/glm-5.3-flash / low
- check frozen: CHECK_PASS: frozen / 자신의 실제 검사 파일명
- 보낸 요청: lesson09/reuse_request.txt 원문 — 다음 단계에서 전송 후 확인
- 현재 상태: 동결한 정본과 새 Chat을 준비했다. 요청은 아직 전송 전이다.
```
### 단계 5. 새 Chat에서 적용하고 근거 확인

#### 5-1. 재사용 요청 전송

```powershell
Get-Content -Raw -Encoding utf8 .\workspace\lesson09\reuse_request.txt | Set-Clipboard
```
새 Chat에 원문 전체를 전송합니다. 절차를 다시 설명하기보다 정본을 읽어 적용하도록 요청합니다.

```text
/workspace/CONTEXT_INDEX.md를 읽고 지정 문서를 순서대로 읽으세요.
/workspace/skills/csv-report/SKILL.md를 읽고 이번 검토에 적용하세요. 없거나 읽을 수 없으면 필요한 파일을 보고하고 멈추세요.
CASE에 지정된 실행 보고서·결과 CSV·판매 보고서·관찰 기록을 검토하세요.
Skill의 절차에 따라 확인한 결과와 미확인을 근거와 함께 /workspace/lesson09/REVIEW.md에 작성하세요.
각 주요 판단이 Skill의 어떤 절차를 적용한 것인지 연결하세요.
REVIEW.md 외 파일 변경, 코드·명령 실행, 외부 접속, 설정·Memory·런타임 Skill 변경은 하지 마세요.
마지막에 읽은 파일·사용한 도구·변경 파일과 남은 확인을 요약하고 멈추세요.
```
요청을 보낸 뒤 3절의 상태를 “요청 전송, 응답 확인 중”으로 바꿉니다. Agent가 멈추면 다음을 입력합니다.

```powershell
.\lesson09.ps1 check reused
notepad .\records\lesson09\reuse\REVIEW.md
Get-Content -Raw -Encoding utf8 .\records\lesson09\reuse\result.json
notepad .\records\lesson09\reuse_response.md
```
**보관 출력 예시:**

```text
RECORDED: records/lesson09/check-reused-<시각과 식별자>.json
REUSE_RECORDED: records/lesson09/reuse/REVIEW.md
CHECK_PASS: reused
```
처음 검사에서는 REVIEW 사본을 보관합니다. 같은 내용으로 다시 검사하면 기존 사본을 유지하고 새 check 기록만 생성합니다. 보관 후 정본 Skill이나 REVIEW가 달라졌으면 차이를 보고하며 덮어쓰지 않습니다.

```json
{
  "review_sha256": "<보관한 REVIEW.md 해시>",
  "p2_source_sha256": "<P2 코드 해시>",
  "reuse_request_sha256": "<재사용 요청 해시>",
  "skill_sha256": "<동결한 Skill 해시>",
  "scope": "Saved review only. Actual Skill reading and application require human review."
}
```
`review_sha256`은 재사용 검토 파일의 내용 값입니다. 다른 해시는 어느 코드·요청·Skill을 바탕으로 검토했는지 연결합니다. 검사에서 새로운 분석 실행을 증명하는 것은 아닙니다.

#### 5-2. 실제 읽기와 적용 대조

도구 이력에서 SKILL.md를 읽은 호출을 확인하고, REVIEW.md의 각 판단을 정본의 절차와 대조합니다. “Skill을 썼다”는 요약만으로 판정하지 않습니다. `reuse_response.md`에는 마지막 요약 응답 전체를 원문으로 저장합니다. 새 Chat도 JSON으로 내보내 보관합니다.

**4절을 추가**하고 2·3절의 “아직 수행 전” 상태를 갱신합니다.

```markdown
## 4. 새 Chat의 적용 결과
- 응답 보관: reuse_response.md
- 실제 Skill 읽기: 도구 이력에 /workspace/skills/csv-report/SKILL.md를 읽은 호출이 있었다.
- 실제 도구 / 변경 파일: 자신의 실제 도구와 횟수 / lesson09/REVIEW.md
- check reused: CHECK_PASS: reused / 자신의 실제 검사 파일명
- 보관 결과: reuse/REVIEW.md, reuse/result.json

| Skill의 절차 | 적용 내용의 가상 예시 | 나의 판단 |
|---|---|---|
| 정상 결과 | CSV의 집계와 순서를 SPEC에 연결했다. | 근거 연결 확인 |
| 반복 실행 | 같은 파일의 전후 해시를 각각 대조했다. | 파일별 비교 확인 |
| 오류와 보존 | 종료코드와 기존 두 결과 보존을 나누어 설명했다. | 기대한 오류 동작 구분 |
| 보고서 의미 | report.md를 읽고 자동 UTF-8 확인과 내용 검토를 구분했다. | 의미 검토 내용 확인 |
| 남은 검사 | 일부 사례 통과와 전체 명세 검증을 구분했다. | 미확인 범위 유지 |

- 읽기와 적용의 구분: 읽기 호출뿐 아니라 REVIEW.md의 판단과 해당 절차를 대조했다.
- 누락·추가 확인: 실제 누락이 있으면 그 항목과 필요한 근거를 기록한다.
- 확인 범위: 저장된 실행 결과에 Skill을 적용한 검토다. 프로그램을 새로 실행하지 않았다.
- 재사용 세션 JSON: 내보낸 실제 파일명
```
Skill이 읽히지 않았거나 절차 적용이 빠졌다면 현재 응답·세션을 먼저 보존하고 원인을 기록합니다. 근거가 없는 것을 완료로 채우지 않습니다. 누락이 단순 재사용 요청 문제라면 해당 범위만 보완해 한 번 재요청할 수 있습니다. 이미 보관한 REVIEW를 바꿔야 한다면 아래 조건부 복원으로 시도를 보존한 뒤 다시 진행합니다. 동결 Skill의 변경이 필요할 때도 같은 복원 경로를 사용합니다.

### 단계 6. 최종 확인과 다음 교시 준비

```powershell
.\lesson09.ps1 check final
.\lesson03.ps1 verify
```
**최종 출력 예시:**

```json
{
  "stage": "final",
  "workspace_matches": true,
  "workspace_differences": [],
  "settings_match": true,
  "settings_differences": [],
  "runtime_memory_and_skills_unchanged": true,
  "common_inputs_unchanged": true,
  "earlier_lesson_records_unchanged": true,
  "saved_review_unchanged": true,
  "p2_source_sha256": "<현재 analyze_sales.py 해시>",
  "reuse_request_sha256": "<재사용 요청문 해시>",
  "skill_sha256": "<동결한 Skill 해시>",
  "scope": "File and saved-setting observations only. Confirm actual Skill reading, application and review quality in the Chat."
}
```

```text
RECORDED: records/lesson09/check-final-<시각과 식별자>.json
CHECK_PASS: final
BASELINE_INTEGRITY_PASS
```
차이 목록이 비어 있고 유지 항목이 true인지 확인합니다. `saved_review_unchanged`는 보관한 재사용 결과와 현재 결과가 같은지 확인하는 항목입니다. 새 Chat의 실제 읽기·적용과 의미의 타당성은 4절에 사람이 기록합니다.

**5절을 추가**하고 작성·재사용 세션 파일명을 확정합니다.

```markdown
## 5. 최종 보관과 다음 단계
- check final / Baseline: CHECK_PASS: final / BASELINE_INTEGRITY_PASS
- 검사 파일 / 작성·재사용 세션: 자신의 실제 파일명
- 보존 확인: P2 코드·출력·앞 교시 기록·설정·런타임 Memory/Skills 유지 검사 통과
- 완료 판단: 이 가상 예시에서는 Skill 정본과 검토 기록을 보관하고 새 Chat의 읽기·적용을 확인했다. 실제 근거가 부족하면 미확인 항목을 남긴다.
- 10교시에 넘길 것: P2 코드·명세·출력, 검토한 Skill, 재사용 결과와 아직 수행하지 않은 다양한 오류·동률·관계 검사 항목
```

```powershell
Get-Item .\records\lesson09\skill_review.md, .\records\lesson09\skill_response.md, .\records\lesson09\reuse_response.md
Get-Item .\records\lesson09\frozen-SKILL.md, .\records\lesson09\reuse\REVIEW.md
Get-ChildItem .\records\lesson09 -Filter 'session*.json'
Get-ChildItem .\records\lesson09 -Filter 'check-*.json'
```
파일 존재와 크기를 확인하고 열어 실제 내용도 살펴봅니다. 작성·재사용 Chat의 원문을 보관하며 같은 세션을 다시 내보낸 경우 기존 파일을 덮지 않게 구분합니다. [누적 기록 예시](examples/skill_progression.md)와 [최종 예시](examples/skill_review_example.md)를 참고할 수 있습니다.

## 7) 완료 점검과 조건부 복원

- [ ] 8교시 관찰과 실행 증거에서 반복 절차를 정리했다.
- [ ] Skill의 사용 조건·근거·절차·중단 조건을 사람이 검토했다.
- [ ] 정본을 동결하고 새 Chat에서 실제로 읽고 적용하는지 확인했다.
- [ ] 자동 검사와 내용 판단, 저장된 결과와 새 실행을 구분했다.
- [ ] P2 파일·앞 교시 기록·설정 보존과 최종 보관을 확인했다.

| 증상 | 확인과 다음 행동 |
|---|---|
| prepare가 stale이라고 중단 | 8교시 코드·출력과 저장된 통과 기록이 다른지 확인 |
| tool_audit.md 없음 | 8교시 관찰 기록을 작성·보관한 뒤 준비 |
| 이미 준비됐다고 중단 | 현재 단계에서 계속하거나 필요한 경우만 restore |
| Skill이 빈 초안 | 작성 요청·실제 쓰기 도구·파일 내용 확인 |
| 동결 후 Skill 또는 REVIEW 차이 | 이전 결과 보존. 원인 확인 후 필요하면 시도 복원 |
| 실제 Skill 읽기 없음 | 세션 이력과 명시적 경로 확인. 활용 완료로 적지 않음 |
| pending 또는 진입 형식 불일치 | 기록·백업을 유지하고 중단 지점 확인. 생성한 스크립트와 맞는 복원 경로 확인 |

### 다시 시작해야 할 때만 restore

진행 중인 Agent를 멈추고 세션을 내보냅니다. 현재 시도의 작업·기록·Harness 상태는 고유 attempt 폴더에 보관한 뒤, **첫 Skill 작성 요청 전**으로 되돌립니다. P2 코드·출력·앞 교시 기록을 유지하고 빈 Skill 초안과 시작 당시 설정·런타임 Memory/Skills를 복원합니다. 로그인·API Key·대화 데이터베이스는 복원 대상이 아닙니다.

```powershell
.\lesson09.ps1 restore
```

```text
RESTORE_PASS: Skill writing entry restored; P2 retained; blank candidate and no reuse result.
BACKUP: records/lesson09-attempt-<시각과 식별자>
Start Hermes, NEW Chat, check start. Do not repeat prepare.
```
BACKUP 경로를 기록합니다. 실패하면 pending과 백업을 지우지 않습니다. 성공 뒤 **prepare를 반복하지 않고** 다음을 입력합니다.

```powershell
docker compose up -d --force-recreate hermes
docker compose ps
```
healthy를 확인하고 작성용 새 Chat에 단계 1-3의 모델·low 설정을 적용한 뒤 시작 검사합니다.

```powershell
.\lesson09.ps1 check start
```
START_READY 뒤 새 관찰 기록에 복원 이유와 보관 경로를 적고 단계 2부터 이어갑니다.

## 8) 핵심 내용과 다음 교시 준비

8교시의 결과 확인 방법을 정본 Skill로 작성하고, 새 Chat에서 읽어 적용하는지 확인했습니다. 10교시에는 P2 코드·명세·출력과 Skill 정본, 재사용 결과, 남은 검증 항목을 넘깁니다. 다양한 오류·동률·관계 검사 등 더 넓은 독립 검증으로 이어갑니다.
