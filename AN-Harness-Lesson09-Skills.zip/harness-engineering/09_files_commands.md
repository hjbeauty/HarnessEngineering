# 9교시 폴더·파일·명령 안내


### 8교시에서 이어받는 것

2·3교시의 환경과 모델 연결을 마치고, 8교시의 `P2_CHECK_PASS`, `CHECK_PASS: final`, `BASELINE_INTEGRITY_PASS`와 관찰 기록을 갖춘 상태에서 진행합니다. Baseline은 최초 실행을 비교 기준으로 보존한 기록입니다.

준비 도구는 현재 P2 코드·PLAN·정책·두 결과 파일이 8교시 통과 기록과 같은지 확인합니다. `tool_audit.md`도 준비되어야 합니다. 파일이 존재한다고 기록 내용까지 완성됐다는 뜻은 아니므로 8교시의 판단과 남은 항목이 적혀 있는지 읽습니다.

### Windows와 두 종류의 컨테이너

| 공간 | 역할과 경로 |
|---|---|
| Windows 프로젝트 | 교육생이 명령을 입력하고 records에 기록을 보관 |
| 일반 Hermes 컨테이너 | Windows workspace가 /workspace로 연결됨. Agent가 문서를 읽고 작성 |
| 관리용 보조 컨테이너 | 프로젝트 전체를 /course-host로 연결해 준비·백업·검사·복원 수행 |

`/course-host`는 관리 컨테이너에서 Windows 프로젝트를 바라보는 경로입니다. `/course-host/records`는 Windows 프로젝트의 records와 같은 위치입니다. 별도의 파일 복사본이 아니라 연결된 경로이며, 스크립트가 필요한 컨테이너를 띄우므로 교육생이 직접 이동하지 않습니다.

### 폴더와 파일을 읽는 순서

| 경로 | 주요 내용·목적 | 생성 주체와 교육생의 행동 |
|---|---|---|
| starter/lesson09/entry | Context·TASK·CASE·요청문 | prepare가 workspace에 배치 |
| starter/lesson09/candidate/SKILL.md | 이름·설명이 있는 빈 초안 | prepare가 프로젝트 Skill 위치에 복사 |
| workspace/SPEC.md·PLAN.md·TOOL_POLICY.md | 명세·계획·도구 사용 범위 | 앞 교시 자료를 읽기 |
| workspace/analyze_sales.py | 8교시 P2 코드 | 그대로 유지 |
| workspace/lesson09/TASK.md | 이번 작성·재사용 범위와 결과 항목 | 작성 전 읽기 |
| workspace/lesson09/CASE.md | 검토할 증거 위치 | 지정한 자료를 찾는 안내 |
| workspace/lesson09/evidence/p2-report.json | 8교시 검사 프로그램의 실행 기록 | prepare가 복사. 종료코드·검사 결과·해시 읽기 |
| workspace/lesson09/evidence/summary.csv | 집계 수치와 순서 | prepare가 복사. SPEC과 대조 |
| workspace/lesson09/evidence/report.md | 사람이 읽는 판매 보고서 | prepare가 복사. 필수 내용·한국어·원 단위·해석 검토 |
| workspace/lesson09/evidence/tool_audit.md | 8교시 교육생의 관찰과 판단 | prepare가 복사. 실제 증거와 함께 참고 |
| workspace/lesson09/skill_request.txt | Skill 작성 요청 | 첫 Chat에 원문 전송 |
| workspace/lesson09/reuse_request.txt | Skill 적용 요청 | 새 Chat에 원문 전송 |
| workspace/skills/csv-report/SKILL.md | 재사용할 검토 절차 정본 | Agent 작성, 교육생 검토 후 동결 |
| workspace/lesson09/REVIEW.md | 새 Chat의 검토 결과 | Agent 작성, 교육생이 적용 여부 확인 |
| records/lesson09/skill_review.md | 교육생의 관찰 기록 | 같은 파일의 1~5절을 순서대로 채움 |
| records/lesson09/frozen-SKILL.md·frozen-skill.json | 검토한 Skill 사본과 내용 해시 | freeze가 생성. 재사용에 쓴 버전 확인 |
| records/lesson09/reuse/REVIEW.md·result.json | 재사용 결과와 연결 정보 | check reused가 보관 |
| records/lesson09/check-*.json | 파일·저장 설정의 단계별 검사 | check가 생성. 차이와 유지 여부 확인 |
| records/lesson09/checkpoint | 첫 Skill 작성 전 복원 지점 | 관리 도구가 보관. 직접 수정하지 않음 |
| templates/skill_review.md | 빈 기록 양식 | prepare가 records에 복사 |
| examples | 가상 누적 기록과 참고 Skill | 작성 방법 참고. 자신의 결과로 대체 |

`p2-report.json`은 **검사 기록**, `report.md`는 **판매 보고서**입니다. 비슷한 이름이지만 확인하는 내용이 다릅니다. tool_audit.md의 의견도 실행 기록 자체를 대신하지 않습니다.

### 명령은 무엇을 위해 쓰는가

`lesson09.ps1`은 Windows에서 사용하는 명령 창구입니다. 작업 위치를 맞추고 앞 교시·Baseline을 확인하며 관리 도구를 호출합니다. prepare·freeze는 작업 중인 Agent가 멈춘 상태에서 수행하고, 처리 후 일반 Hermes 컨테이너를 다시 시작합니다.

`course-tools/lesson09_learning.py`는 파일 준비·사본 보관·해시 비교·복원을 수행하는 Python 프로그램입니다. 생성된 분석 코드를 실행하거나 Agent를 호출하지 않습니다. 해시는 파일 내용으로 계산한 표식이며 의미의 정확성 점수가 아닙니다.

| 명령 | 목적 | 파일 변화 |
|---|---|---|
| prepare | 8교시 확인·보존, 작성 진입점 준비 | 빈 Skill·증거 사본·기록 양식 배치 |
| check start | 작성 전 상태 확인 | 검사 기록 생성 |
| check skill | Skill 작성 범위 확인 | 검사 기록 생성 |
| freeze | 검토한 Skill 사본과 해시 고정 | 동결 기록 생성, 코드·출력 유지 |
| check frozen | 재사용 전 동결 상태 확인 | 검사 기록 생성 |
| check reused | 재사용 결과와 변경 범위 확인 | 결과 사본·연결 정보·검사 기록 생성 |
| check final | 동결 Skill·보관 결과·보호 대상 유지 확인 | 검사 기록 생성 |
| restore | 현재 시도 보관 후 첫 작성 직전으로 복원 | 빈 Skill과 시작 설정으로 복원 |

이번 교시의 검사 명령은 파일·설정 유지와 보관을 확인합니다. 분석 프로그램을 실행하는 test 명령은 사용하지 않습니다. 명령표는 역할 안내이며 실제 입력은 아래 단계 순서대로 합니다.


실제 순서는 [가이드](09_skills_standardization.md)를 따릅니다.
