[CmdletBinding()]
param(
 [Parameter(Mandatory=$true)][ValidateSet('prepare','check','freeze','restore')][string]$Action,
 [ValidateSet('start','skill','frozen','reused','final')][string]$Stage='start'
)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
Set-Location -LiteralPath $PSScriptRoot
foreach ($name in @('compose.yaml','.env','lesson03.ps1','lesson08.ps1','course-tools/lesson09_learning.py','starter/lesson09/entry/CONTEXT_INDEX.md','starter/lesson09/candidate/SKILL.md','templates/skill_review.md')) {
 if (-not (Test-Path -LiteralPath $name -PathType Leaf)) { throw "Required file missing: $name" }
}
if (Test-Path -LiteralPath '.\records\lesson09-pending.json') { throw 'Interrupted operation. Preserve journal and backups.' }
function Invoke-CourseHelper([string]$Verb,[string]$Phase='start') {
 & docker compose run --rm --no-deps -T --user hermes --workdir /tmp --entrypoint python --volume "${PSScriptRoot}:/course-host" hermes /course-tools/lesson09_learning.py $Verb $Phase
 if ($LASTEXITCODE -ne 0) { throw "Lesson09 $Verb stopped. Preserve output; see the guide." }
}
if ($Action -eq 'prepare') {
 Invoke-CourseHelper 'preflight'
 & .\lesson08.ps1 check final
 if (-not $?) { throw 'Complete Lesson08 first.' }
}
if ($Action -in @('prepare','freeze','restore')) {
 & .\lesson03.ps1 verify
 if (-not $?) { throw 'Baseline integrity failed.' }
 & docker compose stop hermes
 if ($LASTEXITCODE -ne 0) { throw 'Could not stop Hermes.' }
}
Invoke-CourseHelper $Action $Stage
if ($Action -in @('prepare','freeze','restore')) {
 & .\lesson03.ps1 verify
 if (-not $?) { throw 'Baseline integrity failed after operation.' }
}
if ($Action -in @('prepare','freeze')) {
 & docker compose up -d --force-recreate hermes
 if ($LASTEXITCODE -ne 0) { throw 'Files ready; startup failed. Inspect logs; do not repeat action.' }
 Write-Host 'Next: check healthy and open a NEW Hermes Chat.'
}
if ($Action -eq 'restore') {
 Write-Host 'Next: docker compose up -d --force-recreate hermes; healthy; NEW Chat; .\lesson09.ps1 check start.'
 Write-Host 'Do not repeat prepare.'
}
