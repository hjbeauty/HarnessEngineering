# 9교시 기록 작성 예시

**가상 작성 예시이며 실제 실행 결과가 아닙니다.** 본인의 결과·도구 횟수·파일명으로 바꿉니다.

## 1. 시작 상태
- 작성자 / 날짜: 본인 이름 / 실습 날짜
- 모델 / 추론 설정: z-ai/glm-5.3-flash / low
- 이어받은 자료: 8교시 SPEC·PLAN·정책·P2 코드·두 출력·실행 보고서·tool_audit.md
- prepare / healthy / check start 결과: PREPARE_PASS / healthy / START_READY
- 시작 검사 파일 / 코드 해시: 자신의 실제 값
- 작성 Chat / 세션 JSON: skills-lesson09-author / 작성 Chat의 실제 세션 파일명

## 2. 반복 절차 정리와 Skill 검토
- 관찰 / 근거: 8교시에서 오류 종료코드 2와 기존 결과 보존을 함께 확인했다. 근거는 p2-report.json의 오류 사례와 파일별 전후 해시다.
- 재사용할 절차: 정상 결과, 반복 실행, 오류와 보존, 보고서 의미, 남은 검사를 구분해 읽는다.
- 넣지 않은 정보: 고정 매출 정답·실행 ID·완성 답변
- 실제 도구 / 변경 파일: 자신의 실제 도구와 횟수 / skills/csv-report/SKILL.md
- 작성 응답 보관: skill_response.md
- 검토 의견: 현재 명세와 증거를 읽고 근거 없는 판단은 미확인으로 남기는 절차가 포함됐다.
- 보완 요청 / 결과: 이 가상 예시에서는 보완 불필요. 실제 보완했다면 요청과 결과·새 검사 파일명을 적는다.
- check skill: CHECK_PASS: skill / 자신의 실제 검사 파일명
- 현재 판단: 내용을 검토했으며 동결을 마쳤다. 적용 결과는 뒤 절에 기록한다.

## 3. 동결과 재사용 준비
- freeze 결과: FROZEN_READY
- 동결 기록 / Skill 해시: frozen-skill.json / 자신의 실제 skill_sha256
- 재사용 Chat / 모델 / 추론 설정: skills-lesson09-reuse / z-ai/glm-5.3-flash / low
- check frozen: CHECK_PASS: frozen / 자신의 실제 검사 파일명
- 보낸 요청: lesson09/reuse_request.txt 원문
- 현재 상태: 새 Chat의 결과를 보관했고 4절에 읽기·적용 여부를 기록했다.

## 4. 새 Chat의 적용 결과
- 응답 보관: reuse_response.md
- 실제 Skill 읽기: 도구 이력에 /workspace/skills/csv-report/SKILL.md를 읽은 호출이 있었다.
- 실제 도구 / 변경 파일: 자신의 실제 도구와 횟수 / lesson09/REVIEW.md
- check reused: CHECK_PASS: reused / 자신의 실제 검사 파일명
- 보관 결과: reuse/REVIEW.md, reuse/result.json

| Skill의 절차 | 적용 내용의 가상 예시 | 나의 판단 |
|---|---|---|
| 정상 결과 | CSV의 집계와 순서를 SPEC에 연결했다. | 근거 연결 확인 |
| 반복 실행 | 같은 파일의 전후 해시를 각각 대조했다. | 파일별 비교 확인 |
| 오류와 보존 | 종료코드와 기존 두 결과 보존을 나누어 설명했다. | 기대한 오류 동작 구분 |
| 보고서 의미 | report.md를 읽고 자동 UTF-8 확인과 내용 검토를 구분했다. | 의미 검토 내용 확인 |
| 남은 검사 | 일부 사례 통과와 전체 명세 검증을 구분했다. | 미확인 범위 유지 |

- 읽기와 적용의 구분: 읽기 호출뿐 아니라 REVIEW.md의 판단과 해당 절차를 대조했다.
- 누락·추가 확인: 실제 누락이 있으면 그 항목과 필요한 근거를 기록한다.
- 확인 범위: 저장된 실행 결과에 Skill을 적용한 검토다. 프로그램을 새로 실행하지 않았다.
- 재사용 세션 JSON: 내보낸 실제 파일명

## 5. 최종 보관과 다음 단계
- check final / Baseline: CHECK_PASS: final / BASELINE_INTEGRITY_PASS
- 검사 파일 / 작성·재사용 세션: 자신의 실제 파일명
- 보존 확인: P2 코드·출력·앞 교시 기록·설정·런타임 Memory/Skills 유지 검사 통과
- 완료 판단: 이 가상 예시에서는 Skill 정본과 검토 기록을 보관하고 새 Chat의 읽기·적용을 확인했다. 실제 근거가 부족하면 미확인 항목을 남긴다.
- 10교시에 넘길 것: P2 코드·명세·출력, 검토한 Skill, 재사용 결과와 아직 수행하지 않은 다양한 오류·동률·관계 검사 항목
