# 같은 기록을 단계별로 채우기
가상 작성 예시다. 같은 records/lesson09/skill_review.md를 단계별로 채운다.

| 시점 | 작성할 내용 | 누적 예시 |
|---|---|---|
| 시작 검사 | 1절 | [시작](skill_stages/01_start.md) |
| Skill 작성·검토 | 2절 추가 | [검토](skill_stages/02_skill.md) |
| 동결·새 Chat 준비 | 3절 추가, 2절 상태 갱신 | [동결](skill_stages/03_frozen.md) |
| 재사용 확인 | 4절 추가, 3절 상태 갱신 | [적용](skill_stages/04_reuse.md) |
| 최종 검사·보관 | 5절 추가, 실제 세션 파일명 확정 | [최종](skill_stages/05_final.md) |
