"""Trusted Python-only course helper. Does not invoke an Agent or export credentials.
The temporary helper alone receives /course-host; Dashboard mounts stay unchanged.
"""
import argparse, csv, copy, hashlib, json, os, platform, shutil, sys, uuid
from datetime import datetime, timezone
from pathlib import Path
import yaml

CSV_SHA='60f14a8cbe5fd6eba994ef2f6c43fbc714b232a3d7a37e60cb02ee6cdad9f0d8'
INPUT_HASHES={'inputs/lesson03/sales.csv': '60f14a8cbe5fd6eba994ef2f6c43fbc714b232a3d7a37e60cb02ee6cdad9f0d8', 'inputs/sales/sales_micro.csv': '38f24772be20f9ac7ee4118e232b23c48809492c24b7aaaee812f7cb8ded47f8', 'inputs/sales/errors/quantity_zero.csv': '5b204667cc3ed55f864c75a3a9a89fca2e4f6a0d200031fe2d766fa7de42140d'}
EXPECTED={'terminal.backend':'local','terminal.cwd':'/workspace','model.provider':'openrouter','model.default':'z-ai/glm-5.3-flash','agent.reasoning_effort':'low','agent.reasoning_overrides':None,'approvals.mode':'manual','memory.memory_enabled':False,'memory.user_profile_enabled':False,'skills.write_approval':True,'auxiliary.background_review.enabled':False,'auxiliary.title_generation.enabled':False}
EXTRA=['agent.disabled_toolsets','command_allowlist']

def stamp(): return datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')+'-'+uuid.uuid4().hex[:6]
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def require(ok,msg):
    if not ok: raise RuntimeError(msg)
def write_json(p,obj):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x',encoding='utf-8') as f: json.dump(obj,f,ensure_ascii=False,indent=2)
def tree(p):
    require(p.is_dir() and not p.is_symlink(),f'Not a regular directory: {p.name}')
    out={}
    for root,dirs,files in os.walk(p,followlinks=False):
        for n in dirs+files:
            q=Path(root)/n
            require(not q.is_symlink(),f'Links are not followed: {q.name}')
            require(q.is_file() or q.is_dir(),f'Unsupported file type: {q.name}')
            out[q.relative_to(p).as_posix()]='DIR' if q.is_dir() else sha(q)
    return out

def get(c,key):
    cur=c
    for part in key.split('.'):
        if not isinstance(cur,dict) or part not in cur: return {'present':False,'value':None}
        cur=cur[part]
    return {'present':True,'value':cur}
def put(c,key,item):
    parts=key.split('.'); cur=c
    for part in parts[:-1]:
        if part not in cur:
            if not item['present']: return
            cur[part]={}
        require(isinstance(cur[part],dict),'Config section is not a mapping')
        cur=cur[part]
    if item['present']: cur[parts[-1]]=item['value']
    else: cur.pop(parts[-1],None)
def settings(c): return {k:get(c,k) for k in list(EXPECTED)+EXTRA}
def acceptable(c):
    bad=[]
    for k,expected in EXPECTED.items():
        v=get(c,k)['value']
        if k=='agent.reasoning_overrides' and v in (None,{}): continue
        if type(v)!=type(expected) or v!=expected: bad.append(k)
    disabled=get(c,'agent.disabled_toolsets')['value']
    if not isinstance(disabled,list) or not {'memory','session_search'}.issubset(disabled): bad.append('agent.disabled_toolsets')
    return bad

def state_tree(home):
    return {n:tree(home/n) if (home/n).exists() else None for n in ('memories','skills')}
def capture(home,dest):
    dest.mkdir()
    meta={'settings':settings(yaml.safe_load((home/'config.yaml').read_text()) or {}),'trees':state_tree(home)}
    for n,t in meta['trees'].items():
        if t is not None: shutil.copytree(home/n,dest/n)
    require({n:tree(dest/n) if t is not None else None for n,t in meta['trees'].items()}==meta['trees'],'Harness backup differs.')
    write_json(dest/'state.json',meta)
    return meta

def verify_saved(cp):
    saved=json.loads((cp/'manifest.json').read_text())
    actual=tree(cp); actual.pop('manifest.json',None)
    require(actual==saved,'Checkpoint integrity failed. Preserve files; do not restore.')

SPEC_SHA='80813a38ca366a3a8e1e454e039a7d677cd5aebdfa1aa5edcdb836a557bc3475'


SKILL='skills/csv-report/SKILL.md'
REVIEW='lesson09/REVIEW.md'
class Course:
    def __init__(self,host=Path('/course-host'),home=Path('/opt/data')):
        self.host=host;self.home=home;self.ws=host/'workspace';self.records=host/'records'
        self.rec=self.records/'lesson09';self.pending=self.records/'lesson09-pending.json';self.starter=host/'starter/lesson09/entry'
    def config(self):
        p=self.home/'config.yaml';require(p.is_file() and not p.is_symlink(),'Config must be a regular file.')
        return yaml.safe_load(p.read_text()) or {}
    def guard(self):
        require(not self.pending.exists(),'Pending operation exists. Preserve journal and backups.')
        for p in (self.host,self.home,self.records,self.ws):require(p.is_dir() and not p.is_symlink(),'Expected regular directory: '+p.name)
        for n,h in INPUT_HASHES.items():require(sha(self.host/n)==h,'Common input differs: '+n)
        tree(self.ws);state_tree(self.home)
    def prior_records(self):
        return {n:tree(self.records/n) for n in ('lesson03','lesson04','lesson05','lesson06','lesson07','lesson08') if (self.records/n).exists()}
    def journal(self,action,backup):write_json(self.pending,{'action':action,'backup':str(backup),'started_utc':stamp()})
    def preflight(self):
        self.guard();require(not self.rec.exists(),'Lesson09 already prepared. Continue or use restore.')
        require(not acceptable(self.config()),'Course settings differ: '+', '.join(acceptable(self.config())))
        require(sha(self.ws/'SPEC.md')==SPEC_SHA,'Common SPEC differs.')
        report=json.loads((self.records/'lesson08/latest-probe.json').read_text())
        require(report.get('passed') is True,'Complete Lesson08 P2 test and final first.')
        for key,n in [('source_sha256','analyze_sales.py'),('plan_sha256','PLAN.md'),('policy_sha256','TOOL_POLICY.md')]:require(report.get(key)==sha(self.ws/n),'Lesson08 result is stale: '+n)
        require(report.get('output_hashes')=={n:sha(self.ws/'outputs/lesson08-p2'/n) for n in ('summary.csv','report.md')},'Lesson08 outputs differ from passed result.')
        require(not (self.ws/'lesson09').exists() and not (self.ws/'skills/csv-report').exists(),'Lesson09 paths already exist. Preserve and inspect.')
        require((self.records/'lesson08/tool_audit.md').is_file(),'Lesson08 tool_audit.md is missing. Complete the observation record first.')
        tree(self.starter);tree(self.host/'inputs')
        print('PREFLIGHT_PASS: Lesson08 P2 code, contracts and outputs match its saved result.')
    def prepare(self):
        self.preflight();self.journal('prepare',self.rec);self.rec.mkdir();cp=self.rec/'checkpoint';cp.mkdir()
        shutil.copytree(self.ws,self.rec/'prior-workspace');require(tree(self.ws)==tree(self.rec/'prior-workspace'),'Prior workspace backup differs.')
        capture(self.home,cp/'harness');write_json(cp/'inputs.json',tree(self.host/'inputs'));write_json(cp/'earlier-records.json',self.prior_records())
        entry=cp/'entry-workspace';shutil.copytree(self.ws,entry);shutil.copytree(self.starter,entry,dirs_exist_ok=True)
        (entry/'skills/csv-report').mkdir(parents=True)
        shutil.copy2(self.host/'starter/lesson09/candidate/SKILL.md',entry/SKILL)
        evidence=entry/'lesson09/evidence';evidence.mkdir()
        shutil.copy2(self.records/'lesson08/latest-probe.json',evidence/'p2-report.json')
        for n in ('summary.csv','report.md'):shutil.copy2(entry/'outputs/lesson08-p2'/n,evidence/n)
        shutil.copy2(self.records/'lesson08/tool_audit.md',evidence/'tool_audit.md')
        write_json(cp/'manifest.json',tree(cp));verify_saved(cp)
        self.ws.rename(self.rec/'workspace-before-prepare');shutil.copytree(entry,self.ws)
        shutil.copy2(self.host/'templates/skill_review.md',self.rec/'skill_review.md')
        write_json(self.rec/'prepared.json',{'format_version':2,'entry_sha256':self.fingerprint(tree(entry)),'request_sha256':sha(entry/'lesson09/reuse_request.txt'),'p2_source_sha256':sha(entry/'analyze_sales.py')})
        self.pending.rename(self.rec/'prepare-result.json')
        print('PREPARE_PASS: Lesson08 preserved; Skill writing entry and evidence copies ready.')
    @staticmethod
    def fingerprint(value):return hashlib.sha256(json.dumps(value,sort_keys=True).encode()).hexdigest()
    def entry(self):
        cp=self.rec/'checkpoint';verify_saved(cp)
        require(json.loads((self.rec/'prepared.json').read_text()).get('format_version')==2,'Entry format differs. Preserve records and use the script that created this checkpoint for recovery.')
        return cp
    def phase(self):
        if (self.rec/'reuse/result.json').exists():return 'reused'
        if (self.rec/'frozen-skill.json').exists():return 'frozen'
        return 'writing'
    def observe(self,stage,record=True):
        self.guard();cp=self.entry();phase=self.phase()
        require((stage in ('start','skill') and phase=='writing') or (stage=='frozen' and phase=='frozen') or (stage=='reused' and phase in ('frozen','reused')) or (stage=='final' and phase=='reused'),'Stage does not match saved progress: '+phase)
        expected=tree(cp/'entry-workspace');actual=tree(self.ws)
        if stage=='skill':
            require(SKILL in actual and actual[SKILL]!='DIR' and actual[SKILL]!=expected[SKILL],'Write the Skill before checking this stage.')
            expected[SKILL]=actual[SKILL]
        if stage in ('frozen','reused','final'):
            frozen=json.loads((self.rec/'frozen-skill.json').read_text())
            require(sha(self.rec/'frozen-SKILL.md')==frozen['skill_sha256'],'Frozen Skill copy differs.')
            expected[SKILL]=frozen['skill_sha256']
            if stage in ('reused','final') and REVIEW in actual:expected[REVIEW]=actual[REVIEW]
            if phase=='reused':expected[REVIEW]=json.loads((self.rec/'reuse/result.json').read_text())['review_sha256']
        diffs=[k for k in sorted(set(expected)|set(actual)) if expected.get(k)!=actual.get(k)]
        saved=json.loads((cp/'harness/state.json').read_text());current=settings(self.config());sd=[]
        for k,v in saved['settings'].items():
            if k=='agent.reasoning_overrides' and v['value'] in (None,{}) and current[k]['value'] in (None,{}):continue
            if current[k]!=v:sd.append(k)
        state_ok=state_tree(self.home)==saved['trees'];inputs_ok=tree(self.host/'inputs')==json.loads((cp/'inputs.json').read_text());prior_ok=self.prior_records()==json.loads((cp/'earlier-records.json').read_text())
        saved_ok=None
        if phase=='reused':saved_ok=sha(self.rec/'reuse/REVIEW.md')==json.loads((self.rec/'reuse/result.json').read_text())['review_sha256']
        out={'stage':stage,'workspace_matches':not diffs,'workspace_differences':diffs,'settings_match':not sd,'settings_differences':sd,'runtime_memory_and_skills_unchanged':state_ok,'common_inputs_unchanged':inputs_ok,'earlier_lesson_records_unchanged':prior_ok,'saved_review_unchanged':saved_ok,'p2_source_sha256':sha(self.ws/'analyze_sales.py'),'reuse_request_sha256':sha(self.ws/'lesson09/reuse_request.txt'),'skill_sha256':sha(self.ws/SKILL) if (self.ws/SKILL).is_file() else None,'scope':'File and saved-setting observations only. Confirm actual Skill reading, application and review quality in the Chat.'}
        if record:
            p=self.rec/('check-'+stage+'-'+stamp()+'.json');write_json(p,out);print(json.dumps(out,ensure_ascii=False,indent=2));print('RECORDED: records/lesson09/'+p.name)
        require(not diffs and not sd and state_ok and inputs_ok and prior_ok and saved_ok is not False,'CHECK_STOPPED: preserve evidence and inspect differences.')
        return out
    def compare(self,stage):
        self.observe(stage)
        if stage=='reused' and not (self.rec/'reuse/result.json').exists():
            p=self.ws/REVIEW;require(p.is_file() and bool(p.read_text(encoding='utf-8-sig').strip()),'REVIEW.md missing or empty. Preserve the response and inspect the request and tool history.')
            dest=self.rec/'reuse';require(not dest.exists(),'Reuse capture incomplete. Preserve files before recovery.')
            self.journal('capture',dest);dest.mkdir();shutil.copy2(p,dest/'REVIEW.md');require(sha(p)==sha(dest/'REVIEW.md'),'Review backup differs.')
            value={'review_sha256':sha(p),'p2_source_sha256':sha(self.ws/'analyze_sales.py'),'reuse_request_sha256':sha(self.ws/'lesson09/reuse_request.txt'),'skill_sha256':sha(self.ws/SKILL),'scope':'Saved review only. Actual Skill reading and application require human review.'}
            write_json(dest/'result.json',value);self.pending.rename(dest/'capture-result.json');print('REUSE_RECORDED: records/lesson09/reuse/REVIEW.md')
        print('START_READY' if stage=='start' else 'CHECK_PASS: '+stage)
    def freeze(self):
        require(self.phase()=='writing','Skill already frozen. Continue with reuse or preserve this attempt before restore.')
        self.observe('skill')
        p=self.ws/SKILL;text=p.read_text(encoding='utf-8-sig')
        require(text.startswith('---') and text.count('---')>=2,'Skill YAML frontmatter is missing.')
        front=yaml.safe_load(text.split('---',2)[1]);require(isinstance(front,dict) and front.get('name')=='csv-report' and isinstance(front.get('description'),str) and front['description'].strip() and '작성 전' not in text,'Complete the Skill name, description and procedure first.')
        self.journal('freeze',self.rec/'frozen-SKILL.md');shutil.copy2(p,self.rec/'frozen-SKILL.md')
        require(sha(p)==sha(self.rec/'frozen-SKILL.md'),'Frozen copy differs.')
        write_json(self.rec/'frozen-skill.json',{'skill_sha256':sha(p),'created_utc':stamp(),'scope':'Reviewed project procedure for reuse. No runtime installation or code execution permission.'})
        self.pending.rename(self.rec/'freeze-result.json');self.observe('frozen')
        print('FROZEN_READY: reviewed project Skill saved. Open a NEW Chat for reuse.')
    def restore(self):
        self.guard();cp=self.entry()
        attempt=self.records/('lesson09-attempt-'+stamp());self.journal('restore',attempt);attempt.mkdir()
        shutil.copytree(self.ws,attempt/'workspace-after-attempt');require(tree(self.ws)==tree(attempt/'workspace-after-attempt'),'Attempt backup differs.')
        capture(self.home,attempt/'harness-after-attempt');shutil.copytree(cp,attempt/'checkpoint');verify_saved(attempt/'checkpoint')
        saved=json.loads((cp/'harness/state.json').read_text());c=self.config()
        for k,v in saved['settings'].items():put(c,k,v)
        target=self.home/'config.yaml';tmp=self.home/('lesson09-'+uuid.uuid4().hex+'.tmp');tmp.write_text(yaml.safe_dump(c,allow_unicode=True,sort_keys=False));tmp.chmod(target.stat().st_mode & 0o777);os.replace(tmp,target)
        for n,t in saved['trees'].items():
            q=self.home/n
            if q.exists():shutil.rmtree(q)
            if t is not None:shutil.copytree(cp/'harness'/n,q)
        self.ws.rename(attempt/'workspace-moved');shutil.copytree(cp/'entry-workspace',self.ws)
        self.rec.rename(attempt/'lesson09-records');self.rec.mkdir();shutil.copytree(attempt/'checkpoint',self.rec/'checkpoint');shutil.copy2(attempt/'lesson09-records/prepared.json',self.rec/'prepared.json');shutil.copy2(self.host/'templates/skill_review.md',self.rec/'skill_review.md')
        require(tree(self.ws)==tree(self.rec/'checkpoint/entry-workspace') and state_tree(self.home)==saved['trees'] and settings(self.config())==saved['settings'],'Restore differs.')
        self.pending.rename(attempt/'restore-result.json');print('RESTORE_PASS: Skill writing entry restored; P2 retained; blank candidate and no reuse result.');print('BACKUP: records/'+attempt.name);print('Start Hermes, NEW Chat, check start. Do not repeat prepare.')
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('action',choices=['preflight','prepare','check','freeze','restore']);ap.add_argument('stage',nargs='?',default='start',choices=['start','skill','frozen','reused','final']);a=ap.parse_args()
    try:
        require(os.getuid()!=0,'Run as hermes, not root.');c=Course()
        if a.action=='check':c.compare(a.stage)
        else:getattr(c,a.action)()
    except Exception as e:print('STOP: '+str(e),file=sys.stderr);sys.exit(1)
