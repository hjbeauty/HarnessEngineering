# 9교시 작업 경계
Agent는 Docker 컨테이너 안의 /workspace에서 파일 도구를 사용한다.
Skill 작성 요청에서는 skills/csv-report/SKILL.md 하나만 수정한다.
재사용 요청에서는 동결한 Skill을 읽고 lesson09/REVIEW.md 하나만 작성한다.
SPEC·PLAN·TOOL_POLICY·P2 코드·입력·출력·승인·실행 로그와 8교시 관찰 기록 사본은 읽기 근거다.
명령·프로그램 실행·패키지 설치·네트워크·설정·Memory·런타임 Skill 변경은 이번 범위에 없다.
이 지시는 작업 범위이며 운영체제의 강제 접근 제한을 대신하지 않는다.
