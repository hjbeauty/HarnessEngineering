# 이번 검토 자료
- 업무 계약: /workspace/SPEC.md
- 도구 범위: /workspace/TOOL_POLICY.md와 현재 context/constraints.md·lesson09/TASK.md
- 실행 보고서: /workspace/lesson09/evidence/p2-report.json
- 결과 CSV: /workspace/lesson09/evidence/summary.csv
- 판매 보고서: /workspace/lesson09/evidence/report.md
- 8교시 사람의 관찰: /workspace/lesson09/evidence/tool_audit.md
네 증거 파일은 prepare가 교육생의 8교시 기록에서 복사한다.
p2-report.json은 검사 프로그램의 실행 기록이고 report.md는 판매 분석 보고서다.
Skill은 이 자료를 어떤 순서로 읽고 확인할지 정리한다. 실제 실행 증거와 사람이 작성한 의견을 구분한다.
