# 9교시 Context 읽기 순서
1. context/constraints.md
2. context/environment.md
3. context/sales_business_context.md
4. context/conventions.md
5. SPEC.md
6. PLAN.md
7. TOOL_POLICY.md
8. lesson09/TASK.md
9. lesson09/CASE.md
이번 작업은 저장된 실행 결과의 검토다. 과거 교시의 구현 승인을 새 구현 권한으로 해석하지 않는다.
