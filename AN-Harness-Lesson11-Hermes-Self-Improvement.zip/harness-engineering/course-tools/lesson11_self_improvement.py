"""Lesson11 orchestration: independent workspace, native-skill observations and scoped restore.
Does not create/approve native skills, run model calls or read credentials/session databases.
"""
import argparse
import hashlib
import json
import os
import re
import shutil
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path
import yaml
from lesson11_check import evaluate

NAME='course11-inquiry-triage'
META={'.usage.json','.usage.json.lock','.curator_ledger.jsonl'}
CONFIG_KEYS=('terminal.backend','terminal.cwd','model.provider','model.default','agent.reasoning_effort',
             'agent.reasoning_overrides','agent.disabled_toolsets','approvals.mode','memory.memory_enabled',
             'memory.user_profile_enabled','skills.write_approval','skills.create_dir','skills.external_dirs',
             'auxiliary.background_review.enabled','auxiliary.title_generation.enabled','command_allowlist')

def require(value,message):
    if not value: raise RuntimeError(message)
def stamp(): return datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')+'-'+uuid.uuid4().hex[:6]
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p): return json.loads(p.read_text(encoding='utf-8'))
def write(p,obj):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x',encoding='utf-8') as f: json.dump(obj,f,ensure_ascii=False,indent=2)
def manifest(p):
    if not p.exists(): return None
    require(p.is_dir() and not p.is_symlink(),'Expected regular directory: '+str(p))
    result={}
    for root,dirs,files in os.walk(p,followlinks=False):
        for name in dirs+files:
            q=Path(root)/name
            require(not q.is_symlink() and (q.is_file() or q.is_dir()),'Unsupported link/file: '+str(q))
            result[q.relative_to(p).as_posix()]='DIR' if q.is_dir() else sha(q)
    return result

def get(c,key):
    for part in key.split('.'):
        if not isinstance(c,dict) or part not in c:return None
        c=c[part]
    return c

def copy_checked(src,dst):
    require(src.is_dir() and not dst.exists(),'Copy source/destination invalid: '+str(dst))
    before=manifest(src);shutil.copytree(src,dst)
    require(before==manifest(src)==manifest(dst),'Copy changed while reading: '+str(src))

def operations(record):
    payload=record.get('payload',{})
    if not isinstance(payload,dict):return []
    ops=payload.get('operations')
    if ops is None:return [payload]
    return ops if isinstance(ops,list) and all(isinstance(op,dict) for op in ops) else []

def create_payload(record):
    ops=operations(record)
    if len(ops)!=1:return {}
    op=ops[0]
    return op if op.get('name')==NAME and op.get('action')=='create' and not op.get('category') else {}

def subset(tree,prefix): return {k:v for k,v in (tree or {}).items() if k!=prefix and not k.startswith(prefix+'/')}

class Course:
    def __init__(self,host=Path('/course-host'),home=Path('/opt/data'),native=Path('/opt/hermes')):
        self.host=host;self.home=home;self.native=native
        self.ws=host/'workspace';self.work=self.ws/'lesson11';self.records=host/'records';self.rec=self.records/'lesson11'
        self.cp=self.rec/'checkpoint';self.journal=self.records/'lesson11-pending.json'
        self.skills=home/'skills';self.target=self.skills/NAME;self.pending=home/'pending/skills'
    def config(self):
        p=self.home/'config.yaml';require(p.is_file() and not p.is_symlink(),'Hermes config missing.')
        c=yaml.safe_load(p.read_text()) or {};return {k:get(c,k) for k in CONFIG_KEYS}
    def skill_contents(self): return {k:v for k,v in (manifest(self.skills) or {}).items() if k not in META}
    def outside_skills(self): return subset(self.skill_contents(),NAME)
    def prior_records(self):
        data=subset(subset(manifest(self.records),'lesson11'),'lesson11-attempts')
        data.pop('lesson11-pending.json',None)
        return data
    def pending_records(self):
        manifest(self.pending)
        if not self.pending.exists():return {}
        out={}
        for p in self.pending.iterdir():
            require(p.is_file() and p.suffix=='.json','Unfinished/unknown pending file: '+p.name)
            value=read(p);require(value.get('id')==p.stem,'Pending id/file mismatch.')
            out[p.name]=value
        return out
    def owned(self): return {k:v for k,v in self.pending_records().items() if operations(v) and all(op.get('name')==NAME for op in operations(v))}
    def native_capabilities(self):
        expected=read(self.host/'starter/lesson11/native_sources.json')
        rows={n:(self.native/n).is_file() and sha(self.native/n)==h for n,h in expected['sha256'].items()}
        result={'source_tag':expected['tag'],'source_commit':expected['commit'],'files':rows,'native_source_matches':all(rows.values())}
        require(result['native_source_matches'],'Pinned Hermes native files differ. Keep output and check the class image; do not update Hermes mid-lesson.')
        return result
    def base_guard(self):
        require(not self.journal.exists(),'Interrupted operation: preserve records/lesson11-pending.json and its archive.')
        for p in (self.host,self.ws,self.home):require(p.is_dir() and not p.is_symlink(),'Directory missing: '+str(p))
        manifest(self.ws);manifest(self.skills)
    def preflight(self):
        self.base_guard();require(not self.rec.exists() and not self.work.exists(),'Lesson11 paths exist. Continue this attempt or use restore; do not prepare again.')
        require(not self.target.exists(),'The dedicated Skill name already exists. Preserve it; choose a clean course profile.')
        require(not self.owned(),'An earlier candidate uses the Lesson11 Skill name. Resolve that candidate before prepare.')
        c=self.config()
        for key,value in {'terminal.backend':'local','terminal.cwd':'/workspace','model.provider':'openrouter',
                          'model.default':'z-ai/glm-5.3-flash','agent.reasoning_effort':'low','approvals.mode':'manual',
                          'memory.memory_enabled':False,'memory.user_profile_enabled':False,'skills.write_approval':True,
                          'auxiliary.background_review.enabled':False}.items():
            require(type(c[key])==type(value) and c[key]==value,'Course environment setting differs: '+key+'. Use the Lesson03 environment setup, not earlier lesson result files.')
        require('skills' not in (c['agent.disabled_toolsets'] or []),'The skills toolset is disabled in this profile.')
        require(c['agent.reasoning_overrides'] in (None,{}),'Reasoning overrides are set; use the course profile.')
        require(not c['skills.create_dir'],'Custom skills.create_dir is configured; use the course profile.')
        require(not c['skills.external_dirs'],'External skill directories are configured; use the course profile.')
        for p in self.skills.rglob('SKILL.md'):
            require(p.parent.name!=NAME,'The dedicated Skill name already exists in a native category.')
            text=p.read_text(encoding='utf-8-sig')
            require(not re.search(r'^name:\s*[\"\']?'+re.escape(NAME)+r'[\"\']?\s*$',text,re.M),'The dedicated Skill name is already in use.')
        for p in self.ws.rglob('SKILL.md'):
            require(p.parent.name!=NAME,'The dedicated Skill name already exists in the workspace.')
        caps=self.native_capabilities()
        print('PREFLIGHT_PASS: independent Lesson11 environment and native features checked.')
        return caps
    def seal(self):
        write(self.cp/'manifest.json',manifest(self.cp))
    def saved(self):
        require(self.cp.is_dir(),'Run prepare first.')
        current=manifest(self.cp);stored=current.pop('manifest.json',None)
        require(stored and current==read(self.cp/'manifest.json'),'Checkpoint integrity failed; preserve the checkpoint.')
        return read(self.cp/'state.json')
    def prepare(self):
        caps=self.preflight();self.records.mkdir(exist_ok=True)
        # Capture guards before the journal/lesson record is introduced.
        state={'config':self.config(),'outside_workspace':manifest(self.ws),'outside_skills':self.outside_skills(),
               'memories':manifest(self.home/'memories'),'pending':{k:sha(self.pending/k) for k in self.pending_records()},
               'inputs':manifest(self.host/'inputs'),'prior_records':self.prior_records()}
        write(self.journal,{'operation':'prepare','archive':str(self.rec)})
        self.cp.mkdir(parents=True)
        copy_checked(self.host/'starter/lesson11',self.cp/'entry')
        write(self.cp/'state.json',state);write(self.cp/'capabilities.json',caps)
        copy_checked(self.host/'starter/lesson11',self.work)
        shutil.copyfile(self.host/'templates/self_improvement_review.md',self.rec/'self_improvement_review.md')
        copy_checked(self.work,self.cp/'workspace-entry');self.seal();self.journal.unlink()
        print('PREPARE_PASS: Lesson11 entry saved; previous work, native Skills and settings preserved.')
    def guard(self):
        self.base_guard();s=self.saved()
        checks={'settings_unchanged':self.config()==s['config'],
                'earlier_workspace_unchanged':subset(manifest(self.ws),'lesson11')==s['outside_workspace'],
                'earlier_records_unchanged':self.prior_records()==(s['prior_records'] or {}),
                'existing_skill_contents_unchanged':self.outside_skills()==s['outside_skills'],
                'memory_unchanged':manifest(self.home/'memories')==s['memories'],
                'inputs_unchanged':manifest(self.host/'inputs')==s['inputs']}
        pending=self.pending_records()
        checks['other_pending_unchanged']={k:sha(self.pending/k) for k in pending if k not in self.owned()}==s['pending']
        # Task sources, copied requests and capability pins remain fixed.
        entry=manifest(self.cp/'workspace-entry')
        checks['task_sources_unchanged']=all((self.work/n).is_file() and sha(self.work/n)==h for n,h in entry.items() if h!='DIR')
        allowed=set(entry)|{'practice_result.json','reuse_result.json','practice_check.json','reuse_check.json'}
        checks['workspace_scope_matches']=set(manifest(self.work) or {}).issubset(allowed)
        return checks
    def enforce(self):
        checks=self.guard();require(all(checks.values()),'Protected state differs: '+', '.join(k for k,v in checks.items() if not v));return checks
    def check(self,phase):
        checks=self.guard();extra={}
        if phase=='start':
            extra={'entry_matches':manifest(self.work)==manifest(self.cp/'workspace-entry'),'lesson_skill_absent':not self.target.exists(),'lesson_pending_empty':not self.owned()}
        elif phase=='pending':
            own=self.owned();extra={'one_candidate':len(own)==1,'not_installed_yet':not self.target.exists()}
            if len(own)==1:
                record=next(iter(own.values()));payload=create_payload(record)
                extra['create_only']=bool(payload)
                content=payload.get('content');extra['content_present']=isinstance(content,str) and bool(content.strip())
                extra['candidate_id']=record['id']
                if all(checks.values()) and all(v for k,v in extra.items() if k!='candidate_id'):
                    dest=self.rec/'candidates'/record['id'];dest.mkdir(parents=True,exist_ok=True)
                    if (dest/'pending.json').exists():require(read(dest/'pending.json')==record,'Candidate record changed under same id.')
                    else:
                        write(dest/'pending.json',record);(dest/'candidate.md').write_text(content,encoding='utf-8')
                    extra['candidate_file']='records/lesson11/candidates/'+record['id']+'/candidate.md'
        elif phase=='final':
            cap=self.rec/'approved-skill.json'
            extra={'approved_skill_current':cap.exists() and self.installed_current(),
                   'reuse_result_current_and_passed':self.current_test('reuse'),
                   'practice_result_recorded':self.current_test('practice',need_pass=False),
                   'lesson_pending_empty':not self.owned()}
        else:raise RuntimeError('Unknown check stage.')
        passed=all(checks.values()) and all(v for k,v in extra.items() if k not in ('candidate_id','candidate_file'))
        obj={'stage':phase,**checks,**extra,'passed':passed,
             'scope':'File observations only. Review native calls, human approval and application in both Chat exports.'}
        self.rec.mkdir(exist_ok=True);p=self.rec/f'check-{phase}-{stamp()}.json';write(p,obj)
        print(json.dumps(obj,ensure_ascii=False,indent=2));print('RECORDED: records/lesson11/'+p.name)
        require(passed,'Stage check failed; inspect false fields.')
        print('START_READY' if phase=='start' else 'CHECK_PASS: '+phase)
    def capture(self):
        self.enforce();require(not self.owned(),'Resolve Lesson11 pending candidates before capture.')
        require(not (self.rec/'approved-skill.json').exists(),'Skill already captured. Continue with the new Chat.')
        require(manifest(self.target)=={'SKILL.md':sha(self.target/'SKILL.md')} if (self.target/'SKILL.md').is_file() else False,'Expected the dedicated Skill with only SKILL.md.')
        actual=(self.target/'SKILL.md').read_text(encoding='utf-8')
        matching=[]
        for p in (self.rec/'candidates').glob('*/pending.json') if (self.rec/'candidates').exists() else []:
            candidate=read(p)
            if create_payload(candidate).get('content')==actual:matching.append(candidate['id'])
        require(matching,'Installed content has no captured pending candidate. Do not substitute a direct file write for native approval.')
        dest=self.rec/'approved-skill';copy_checked(self.target,dest)
        obj={'name':NAME,'skill_sha256':sha(dest/'SKILL.md'),'matching_candidate_ids':matching,
             'scope':'Matches captured candidate content. Native approval command/tool history requires human review.'}
        write(self.rec/'approved-skill.json',obj)
        print(json.dumps(obj,ensure_ascii=False,indent=2));print('CAPTURE_PASS: native Skill content copied for review and later comparison.')
    def installed_current(self):
        info=read(self.rec/'approved-skill.json');p=self.target/'SKILL.md'
        return p.is_file() and sha(p)==info['skill_sha256'] and manifest(self.target)=={'SKILL.md':info['skill_sha256']} and sha(self.rec/'approved-skill/SKILL.md')==info['skill_sha256']
    def test(self,phase):
        self.enforce()
        if phase=='practice':require(not self.target.exists() and not self.owned(),'Practice must precede native Skill creation.')
        else:require((self.rec/'approved-skill.json').exists() and self.installed_current(),'Capture an approved current Skill first.')
        p=self.work/f'{phase}_result.json'
        require(p.is_file() and not p.is_symlink(),'Agent result missing: '+p.name)
        runs=self.rec/'checks';runs.mkdir(exist_ok=True)
        previous=list(runs.glob(phase+'-*.json'));require(len(previous)<2,'Two checks already recorded for this phase. Preserve failure; do not loop until passing.')
        result=evaluate(p,phase)
        if phase=='reuse':result['skill_sha256']=sha(self.target/'SKILL.md')
        out=runs/(phase+'-'+stamp()+'.json');write(out,result)
        # Latest convenience copy; immutable per-run record above is authoritative.
        dest=self.work/f'{phase}_check.json';dest.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
        (self.rec/f'latest-{phase}.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
        self.enforce();print(json.dumps(result,ensure_ascii=False,indent=2));print('RECORDED: records/lesson11/checks/'+out.name)
        print(('TASK_PASS: ' if result['passed'] else 'TASK_REVIEW: ')+phase)
        # A failed task is an observation for learning, not an orchestration crash.
    def current_test(self,phase,need_pass=True):
        p=self.rec/f'latest-{phase}.json';source=self.work/f'{phase}_result.json'
        if not p.is_file() or not source.is_file():return False
        r=read(p)
        if r.get('result_sha256')!=sha(source) or (need_pass and r.get('passed') is not True):return False
        if phase!='reuse':return True
        skill=self.target/'SKILL.md'
        return skill.is_file() and r.get('skill_sha256')==sha(skill)
    def restore(self):
        # Never roll back unrelated work. Only the Lesson11 paths and its pending candidates.
        self.base_guard();s=self.saved();checks=self.guard()
        unrelated=[k for k,v in checks.items() if not v and k not in ('task_sources_unchanged','workspace_scope_matches')]
        require(not unrelated,'Unrelated state differs; scoped restore stopped: '+', '.join(unrelated))
        archive=self.records/'lesson11-attempts'/stamp();archive.mkdir(parents=True)
        copy_checked(self.work,archive/'workspace');copy_checked(self.rec,archive/'records')
        if self.target.exists():copy_checked(self.target,archive/'native-skill')
        write(archive/'native-pending.json',self.owned())
        write(archive/'manifest.json',manifest(archive))
        write(self.journal,{'operation':'restore','archive':str(archive)})
        shutil.rmtree(self.work);copy_checked(self.cp/'workspace-entry',self.work)
        if self.target.exists():shutil.rmtree(self.target)
        for name in self.owned():(self.pending/name).unlink()
        # Keep Hermes audit history. It describes actions that really occurred.
        for p in list(self.rec.iterdir()):
            if p.name=='checkpoint':continue
            if p.is_dir():shutil.rmtree(p)
            else:p.unlink()
        shutil.copyfile(self.host/'templates/self_improvement_review.md',self.rec/'self_improvement_review.md')
        # Attempt archives are new course evidence, not prior-lesson changes.
        self.journal.unlink()
        print('RESTORE_PASS: Lesson11 entry restored; attempt retained at '+str(archive))
        self.check('start')

def main():
    p=argparse.ArgumentParser();p.add_argument('action',choices=['preflight','prepare','check','capture','test','restore'])
    p.add_argument('stage',nargs='?',default='start');args=p.parse_args()
    course=Course()
    try:
        if args.action in ('check','test'):getattr(course,args.action)(args.stage)
        else:getattr(course,args.action)()
    except (RuntimeError,OSError,ValueError,KeyError) as exc:
        print('STOP: '+str(exc),file=sys.stderr);return 1
    return 0
if __name__=='__main__':sys.exit(main())
