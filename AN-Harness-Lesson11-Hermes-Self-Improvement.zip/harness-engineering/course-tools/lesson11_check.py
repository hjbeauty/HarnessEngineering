"""Trusted exact-answer checker for the dedicated Lesson11 JSON task. No Agent code execution."""
import hashlib
import json
from pathlib import Path

EXPECTED = {
    'practice': [('T01','access','normal','ACCESS'), ('T02','billing','normal','BILLING'),
                 ('T03','incident','urgent','SERVICE_DOWN'), ('T04','review','normal','REVIEW')],
    'reuse': [('N01','access','normal','ACCESS'), ('N02','billing','normal','BILLING'),
              ('N03','incident','urgent','SERVICE_DOWN'), ('N04','review','normal','REVIEW')],
}
KEYS = ('id','route','priority','rule')

def digest(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result: raise ValueError('Duplicate JSON key: '+key)
        result[key] = value
    return result

def evaluate(path, phase):
    expected = [dict(zip(KEYS, row)) for row in EXPECTED[phase]]
    report = {'phase':phase,'scope':'Exact schema, ids, values and order for four supplied cases only.',
              'result_sha256':digest(path) if path.is_file() else None,
              'matched':0,'total':len(expected),'passed':False,'differences':[]}
    try:
        actual = json.loads(path.read_text(encoding='utf-8-sig'), object_pairs_hook=unique_object)
        if not isinstance(actual,list): raise ValueError('Top level must be an array')
        if len(actual)!=len(expected): report['differences'].append({'reason':'record_count','actual':len(actual),'expected':len(expected)})
        for i, exp in enumerate(expected):
            got = actual[i] if i < len(actual) else None
            if got==exp: report['matched']+=1
            else: report['differences'].append({'position':i+1,'expected':exp,'actual':got})
        report['passed'] = not report['differences']
    except (OSError,ValueError,UnicodeError) as exc:
        report['differences'].append({'reason':str(exc)})
    return report
