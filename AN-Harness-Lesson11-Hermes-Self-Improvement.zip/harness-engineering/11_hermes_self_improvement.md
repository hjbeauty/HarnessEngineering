# 11교시. Hermes 자기 개선 — 작업 경험을 Skill로 남기고 다시 사용하기

**AI Native 소프트웨어 개발: Harness Engineering — 학습 가이드북**

## 1) 이번 교시에서 해결할 문제

Agent에게 작업 순서를 알려 주고 결과도 확인했습니다. 그런데 새 Chat을 열면 같은 설명을 다시 해야 합니다. **이번에 익힌 절차를 다음 작업에서도 사용하게 하려면 어떻게 해야 할까요?**

이번에는 Hermes가 제공하는 기능으로 작업 경험을 **Skill**, 즉 필요할 때 불러 읽는 재사용 절차로 남깁니다. 교육용 문의를 분류해 보고, 결과에서 배운 점을 `/learn`으로 정리합니다. 사람이 내용을 승인한 뒤 새 Chat에서 불러와 다른 문의에 적용합니다.

여기서 자기 개선은 작업 경험을 절차로 정리하고 다음 작업에 활용하는 과정입니다. 모델 자체를 다시 학습시키는 과정과는 다릅니다. **좋은 절차가 저장됐는지와 실제 결과가 맞는지를 각각 확인합니다.**

## 2) 학습목표와 완료 상태

- `/learn`으로 이번 작업의 경험을 Skill 후보로 정리합니다.
- `skill_manage`의 후보 저장, 사람의 승인, `skill_view`의 조회를 구분합니다.
- 새 Chat에서 승인된 Skill을 실제로 읽고 적용하는지 확인합니다.
- 결과 검사와 도구 이력을 근거로 재사용의 범위와 한계를 기록합니다.

완료하면 **승인된 Skill의 보관본, 첫 과제와 재사용 과제의 검사 기록, 두 Chat의 세션, 자기 개선 관찰 기록**이 남습니다. Skill 이름은 이 수업 전용인 `course11-inquiry-triage`를 사용합니다. inquiry는 문의, triage는 담당 분야를 나누는 분류를 뜻합니다.

## 3) 시작 전 준비와 파일의 역할

### 독립적으로 시작하는 교시

2·3교시에서 준비한 Docker Desktop, Hermes 웹 대시보드와 모델 연결을 사용합니다. 이 교시는 판매 분석의 코드·SPEC·PLAN이나 앞 교시의 완료 기록을 요구하지 않습니다. 환경과 모델 연결이 준비되어 있으면 다른 실습의 진행 순서와 관계없이 시작할 수 있습니다.

수업 환경은 `z-ai/glm-5.3-flash`, 추론 설정 `low`, 수동 승인, Skill 쓰기 승인 켜짐, Memory와 백그라운드 자동 검토 꺼짐입니다. Memory는 대화 사이에 남기는 기억, 백그라운드 자동 검토는 별도로 실행되는 경험 검토 기능입니다. 이번에는 교육생이 `/learn`을 요청하는 시점에만 절차를 정리하므로 이 두 기능은 켜지 않습니다.

준비 도구는 수업 환경과 고정 Hermes 버전의 기능 파일을 확인합니다. 이전 교시의 성공 여부를 대신 검사하는 것은 아닙니다. 환경 설정이 다르다는 오류가 나오면 3교시의 환경 설정 안내를 확인합니다. 첫 실행이나 Baseline을 다시 만들 필요는 없습니다.

### Windows와 컨테이너의 경로

PowerShell은 Windows의 `C:\AI-Native\harness-engineering`에서 사용합니다. Agent는 컨테이너 안의 `/workspace/lesson11`에서 이번 과제를 읽습니다.

| 위치 | 역할과 이번에 들어갈 내용 |
|---|---|
| Windows의 workspace/lesson11 | Agent가 읽을 과제와 작성할 분류 결과. 컨테이너에서는 /workspace/lesson11 |
| Windows의 records/lesson11 | 교육생 관찰, 자동 검사, 응답 원문, 승인 Skill 보관본 |
| 컨테이너의 /opt/data/skills | Hermes가 관리하는 실제 Skill 저장소. 새 Chat도 여기의 Skill을 조회 |
| 컨테이너의 /opt/data/pending/skills | 사람의 승인을 기다리는 Skill 변경 후보 |
| 관리용 보조 컨테이너의 /course-host | Windows 프로젝트 전체를 바라보는 연결 경로. 준비·복사·검사·복원에 사용 |

`/opt/data`는 Hermes의 설정과 학습 상태를 보관하는 공간입니다. 컨테이너를 다시 시작해도 내용이 유지되도록 Docker 볼륨에 연결되어 있습니다. Windows의 workspace 폴더와는 다른 저장소입니다. Skill은 Hermes 기능으로 저장하고, 보관용 복사본은 스크립트가 records로 가져옵니다.

`/course-host/records/lesson11`과 Windows의 `records\lesson11`은 같은 파일을 가리킵니다. 스크립트가 관리용 컨테이너를 열어 이 경로로 파일을 정리하므로 교육생이 컨테이너 터미널로 들어갈 필요는 없습니다. 이번 검사에서는 교육용 Python이 JSON 결과를 읽어 비교할 뿐, Agent가 만든 프로그램을 실행하지 않습니다.

### 폴더와 파일의 역할

| 경로 | 주요 내용 | 누가 무엇을 하는가 |
|---|---|---|
| starter/lesson11/TASK.md | 이번 실습의 순서와 작업 범위 | prepare가 workspace/lesson11로 복사. Agent와 교육생이 읽음 |
| starter/lesson11/RULES.md | 문의 분류 순서와 JSON 출력 규칙 | 과제의 판단 근거로 사용 |
| starter/lesson11/practice.json | 첫 과제의 교육용 문의 4건 | Agent가 읽고 practice_result.json 작성 |
| starter/lesson11/reuse.json | 새 Chat에 줄 다른 문의 4건 | Skill 조회 후 reuse_result.json 작성 |
| starter/lesson11/*_request.txt | 첫 과제·Skill 작성·재사용 요청문 | 교육생이 해당 단계에서 Chat에 붙여넣음 |
| starter/lesson11/native_sources.json | 고정 Hermes 기능 파일의 내용 식별값 | 준비 도구가 설치된 기능과 대조 |
| templates/self_improvement_review.md | 1~5절 관찰 기록 양식 | prepare가 records/lesson11로 복사. 이후 같은 파일을 채움 |
| records/lesson11/checkpoint | 진입 시점의 과제·설정 관찰값·보호 대상 식별값 | 도구가 보존. 조건부 복원의 기준 |
| records/lesson11/candidates/후보ID | 승인 전 후보 JSON과 읽기용 candidate.md | check pending이 복사. 사람이 검토 |
| records/lesson11/approved-skill | 승인 후 실제 SKILL.md의 보관본 | capture가 복사. 새 Chat에서 사용하는 원본은 /opt/data/skills에 있음 |
| records/lesson11/checks | 실행할 때마다 별도로 남기는 결과 비교 보고서 | 교육생이 읽고 관찰 기록에 판단 |
| examples/lesson11-stages | 시작부터 최종 기록까지의 가상 작성 예시 | 기록할 위치와 변화를 참고 |

`starter`는 시작 재료이고 `templates`는 기록의 빈 양식입니다. 교육생은 준비 명령이 복사한 `workspace`와 `records`의 파일을 사용합니다.

### 스크립트는 무엇을 하는가?

| 파일 | 역할 |
|---|---|
| lesson11.ps1 | Windows에서 입력하는 실행 창구. 필요한 컨테이너와 Python 도구를 호출 |
| course-tools/lesson11_self_improvement.py | 독립 과제 준비, 보호 대상 비교, 승인 후보·Skill 보관, 검사 기록과 조건부 복원 |
| course-tools/lesson11_check.py | Agent의 JSON을 교육용 기준값과 비교. 키·ID·값·순서 검사 |

다음 표는 명령의 역할을 미리 보는 표입니다. 실제 입력은 6절의 단계 순서대로 합니다.

| 명령 | 목적과 파일 변화 |
|---|---|
| prepare | 시작 자료와 빈 기록을 복사하고 진입점 보존. 기존 Skill과 설정은 유지 |
| check start | 과제 시작 상태와 보호 대상을 비교하고 기록 |
| test practice | 첫 분류 결과를 비교하고 검사 JSON 생성 |
| check pending | 설치 전 후보가 이 수업의 create 작업 하나인지 확인하고 후보 보관 |
| capture | 사람이 승인한 실제 Skill이 보관 후보와 같은지 비교하고 복사 |
| test reuse | 새 입력의 분류 결과를 비교하고 검사 JSON 생성 |
| check final | 현재 결과·Skill과 통과 기록의 일치, 보호 대상 유지 확인 |
| restore | 현재 시도를 보관한 뒤 11교시 과제 시작점으로 복원 |

**Skill 생성과 승인은 이 스크립트가 대신하지 않습니다.** 생성은 Agent의 `skill_manage`, 승인은 교육생의 Hermes 명령, 조회는 Agent의 `skill_view`가 맡습니다.

## 4) 실습에 필요한 핵심 개념

### 경험에서 후보, 승인, 재사용으로

`/learn`은 교육생이 Hermes Chat에 입력하는 요청입니다. 이 대화에서 익힌 절차를 정리하도록 Agent에게 맡깁니다. `skill_manage`는 Agent가 Skill을 만들거나 고칠 때 사용하는 Hermes 도구입니다. 쓰기 승인이 켜져 있으면 후보로 남고, 아직 설치된 Skill은 바뀌지 않습니다.

`/skills pending`은 승인 대기 목록, `/skills diff 후보ID`는 그 후보의 변경 표시입니다. 여러 작업을 담을 수 있는 `operations` 형식은 이 버전에서 요약만 표시될 수 있어, 승인 전에는 아래 절차로 보관한 후보 본문도 읽습니다. ID는 후보를 구별하는 짧은 문자열입니다. 검토한 ID 하나를 `/skills approve 후보ID`로 승인하면 Hermes가 그 변경을 적용합니다. 부적절한 후보는 `/skills reject 후보ID`로 거절합니다.

`skill_view`는 저장된 Skill의 본문을 읽는 도구입니다. 새 Chat에서 이 호출이 실제로 있었는지 확인해야 이전 대화의 기억에 의존한 답변과 구분할 수 있습니다.

### 좋은 Skill에 남길 것

첫 과제는 문의 네 건을 **계정(access), 결제(billing), 전체 장애(incident), 사람의 검토(review)**로 분류합니다. 장애 조건을 먼저 확인하고, 나머지는 계정과 결제 분야가 각각 해당하는지 살핍니다. 두 분야 모두 해당하거나 둘 다 해당하지 않으면 사람이 검토하도록 분류합니다.

Skill에는 이 판단 순서, 애매한 입력의 처리, 출력 규칙, 결과 확인 방법을 남깁니다. `T01의 정답은 access`처럼 특정 문의의 정답만 담으면 새로운 문의를 처리할 절차가 되지 못합니다.

첫 결과가 모두 맞아도 재사용할 확인 절차는 남길 수 있습니다. 실제 오류가 있었다면 검사 결과에서 무엇이 틀렸는지 확인해 올바른 규칙과 함께 정리합니다. 오류가 없었는데 실패 경험을 만들어 기록하지 않습니다.

### 네 가지 증거를 구분하기

| 증거 | 확인하는 것 |
|---|---|
| 후보와 실제 Skill 파일 | 절차가 어떤 내용으로 저장됐는가 |
| 승인 명령과 응답 | 사람이 어떤 후보를 승인했는가 |
| 새 Chat의 skill_view 도구 이력 | 저장된 절차를 실제로 읽었는가 |
| 결과 비교 보고서 | 이번 입력에서 요구한 분류 결과가 나왔는가 |

새 Chat에서 맞는 답을 얻었다고 Skill 덕분에 성능이 향상됐다고 바로 단정할 수는 없습니다. 이번에는 **저장한 절차를 다시 읽고 적용한 과정**과 **정해진 입력의 결과**까지 확인합니다.

## 5) 전체 작업 흐름

```mermaid
flowchart TD
    A["첫 과제 수행·결과 확인"] --> B["/learn으로 Skill 후보 작성"]
    B --> C{"사람의 내용 검토"}
    C -->|보완 필요| D["후보 거절·내용 보완 요청"]
    D --> B
    C -->|적절함| E["후보 ID 승인·실제 Skill 보관"]
    E --> F["새 Chat: skill_view·다른 입력 적용"]
    F --> G["결과 검사·관찰 기록"]
```

**준비 10분 → 첫 과제 10분 → Skill 후보 검토·승인 15분 → 새 Chat 재사용 15분 → 기록과 마무리 10분**을 기준으로 진행합니다.

## 6) 단계별 실습

아래 출력과 기록은 **가상 예시**입니다. 파일명·후보 ID·해시·도구 횟수·통과 여부는 직접 확인한 본인의 값으로 기록합니다. 해시는 파일 내용을 구별하는 SHA-256 값이며 파일명에 붙은 시각·식별자와는 다릅니다.

### 단계 1. 전용 과제 준비하기

#### 1-1. 파일 확인

ZIP의 `harness-engineering` 안쪽 내용을 기존 프로젝트 폴더에 합칩니다. PowerShell에서 다음을 실행합니다.

```powershell
Set-Location 'C:\AI-Native\harness-engineering'
Get-Location
Test-Path .\compose.yaml
Test-Path .\lesson11.ps1
Test-Path .\course-tools\lesson11_self_improvement.py
Test-Path .\course-tools\lesson11_check.py
Test-Path .\starter\lesson11\TASK.md
Test-Path .\templates\self_improvement_review.md
```

현재 위치가 프로젝트 폴더이고 `Test-Path` 결과가 모두 `True`인지 확인합니다. `False`가 있으면 압축을 푼 위치를 확인합니다. 앞 교시의 판매 분석 파일은 확인 목록에 없습니다.

#### 1-2. 준비와 상태 확인

진행 중인 다른 Chat 작업이 있으면 먼저 멈춘 뒤 실행합니다. `prepare`는 처음 한 번만 실행합니다.

```powershell
Unblock-File -LiteralPath .\lesson11.ps1
.\lesson11.ps1 prepare
docker compose ps
```

**주요 출력 예시:**

```text
PREFLIGHT_PASS: independent Lesson11 environment and native features checked.
PREPARE_PASS: Lesson11 entry saved; previous work, native Skills and settings preserved.
Next: healthy; NEW Chat; .\lesson11.ps1 check start.
```

`docker compose ps`의 STATUS가 `healthy`가 되면 진행합니다. `health: starting`이면 잠시 뒤 같은 상태 조회 명령을 다시 실행합니다. 준비 자료를 다시 복사할 필요는 없습니다.

Hermes 고정 기능 파일이 다르다는 `STOP`이 나오면 설치된 수업 이미지와 패키지를 확인합니다. 이때 Hermes 업데이트나 승인 우회로 진행하지 않습니다. 후보 ID가 아닌 Skill 이름이 이미 존재한다는 오류라면 기존 수업 시도를 이어갈지 확인합니다.

#### 1-3. 첫 Chat 열기

Hermes 웹 대시보드에서 **새 Chat**을 열고 다음을 한 줄씩 입력합니다.

```text
/title self-improvement-lesson11-learn
/model z-ai/glm-5.3-flash
/reasoning low
/status
```

PowerShell로 돌아와 시작 상태를 검사합니다.

```powershell
.\lesson11.ps1 check start
Get-Content -Raw -Encoding utf8 .\records\lesson11\checkpoint\capabilities.json
notepad .\records\lesson11\self_improvement_review.md
```

**출력 예시(각 JSON의 주요 항목 발췌):**

```json
{
  "stage": "start",
  "settings_unchanged": true,
  "earlier_workspace_unchanged": true,
  "earlier_records_unchanged": true,
  "existing_skill_contents_unchanged": true,
  "entry_matches": true,
  "lesson_skill_absent": true,
  "lesson_pending_empty": true,
  "passed": true
}
```

```text
RECORDED: records/lesson11/check-start-예시식별자.json
START_READY
```

```json
{
  "source_tag": "v2026.9.7",
  "source_commit": "2237be355906fbe6065ce1815711eee52b2d646e",
  "native_source_matches": true
}
```

`native_source_matches`는 설치된 Hermes의 수업 관련 기능 파일이 고정 버전과 같은지를 나타냅니다. 모델이 실제로 그 도구를 사용했는지는 이후 Chat에서 따로 확인합니다. `entry_matches`는 시작 과제 파일이 준비 자료와 같다는 뜻입니다.

관찰 기록의 **1절**을 채웁니다. 세션 파일은 나중에 내보낼 때 실제 파일명을 적습니다.

```markdown
## 1. 시작 상태
- 작성자 / 날짜: 본인 이름 / 실습 날짜
- 모델 / 추론 설정: z-ai/glm-5.3-flash / low
- 첫 Chat 이름: self-improvement-lesson11-learn
- prepare / healthy / check start 결과: 직접 확인한 결과
- capabilities 파일 / native_source_matches: checkpoint/capabilities.json / 직접 확인한 값
- 앞 교시와의 관계: 환경과 모델 연결을 사용하며 앞 교시 완료 파일은 요구하지 않음
```

Ctrl+S로 저장합니다. 이후에도 같은 관찰 기록을 계속 채웁니다.

### 단계 2. 첫 과제를 수행하고 배운 점 찾기

#### 2-1. 과제와 규칙 읽기

```powershell
notepad .\workspace\lesson11\TASK.md
notepad .\workspace\lesson11\RULES.md
notepad .\workspace\lesson11\practice.json
Get-Content -Raw -Encoding utf8 .\workspace\lesson11\practice_request.txt | Set-Clipboard
```

과제와 규칙을 읽은 뒤 복사된 요청을 첫 Chat에 붙여넣고 실행합니다. Agent가 `practice_result.json`을 작성하고 멈추면 다음을 실행합니다.

```powershell
.\lesson11.ps1 test practice
Get-Content -Raw -Encoding utf8 .\workspace\lesson11\practice_result.json
Get-Content -Raw -Encoding utf8 .\workspace\lesson11\practice_check.json
```

**Chat에 전달하는 요청문:**

```text
/workspace/lesson11/TASK.md, RULES.md, practice.json을 순서대로 읽으세요.
RULES.md의 순서와 출력 계약에 따라 문의를 분류하고 /workspace/lesson11/practice_result.json만 작성하세요.
기존 판매 분석 파일이나 이전 교시 문서는 읽을 필요가 없습니다.
명령 실행·검색·설치·Memory·설정·Skill 변경은 하지 마세요.
마지막에 읽은 파일, 사용한 도구, 변경 파일, 아직 실행하지 않은 검사를 요약하고 멈추세요.
```

`test practice`는 JSON 파일을 읽어 정해진 답과 비교합니다. Agent에게 명령을 실행시키거나 분류 프로그램을 새로 만드는 과정은 없습니다.

**검사 결과 예시(발췌):**

```json
{
  "phase": "practice",
  "matched": 4,
  "total": 4,
  "passed": true,
  "differences": []
}
```

```text
RECORDED: records/lesson11/checks/practice-예시식별자.json
TASK_PASS: practice
```

`matched`는 키·ID·값·순서가 모두 맞는 문의 수이고 `total`은 검사 대상 수입니다. 추가 행이 있으면 맞는 문의가 네 건이어도 전체 통과는 아닙니다. 항상 `passed`와 `differences`를 함께 읽습니다.

틀린 결과에는 `TASK_REVIEW: practice`가 표시됩니다. 프로그램 고장이 아니라 학습할 관찰 결과입니다. 예를 들어 장애 문장에 결제 단어가 함께 있다는 이유로 billing을 선택했다면, 먼저 장애 조건을 검사해야 한다는 규칙을 배울 수 있습니다. 결과를 보존한 뒤 규칙과 오류를 다음 Skill 작성의 근거로 사용합니다.

#### 2-2. 응답 원문과 사람의 판단 구분하기

```powershell
notepad .\records\lesson11\practice_response.md
notepad .\records\lesson11\self_improvement_review.md
```

`practice_response.md`에는 Agent의 마지막 요약 응답을 그대로 붙여넣습니다. 요청문, 화면 상태줄, 파일 diff는 붙이지 않습니다. 전체 도구 이력은 나중에 내보내는 세션 JSON에 보관합니다. `/copy`를 사용했다면 메모장에 붙여넣은 내용이 해당 응답인지 확인합니다.

관찰 기록 **2절**에는 실제 검사와 사람의 판단을 적습니다.

```markdown
## 2. 첫 과제와 배운 절차
- 첫 결과 / 검사 파일: workspace/lesson11/practice_result.json / checks/본인의 practice 검사 파일명
- matched / total / passed: 본인의 검사 값
- 실제 도구 / 변경 파일: Chat 도구 이력의 실제 호출 / practice_result.json
- 사람이 확인한 규칙과 오류: 본인이 확인한 내용
- 재사용할 절차: 장애 우선 확인 → 두 분야의 해당 여부 확인 → review 조건 확인 → 출력 키·순서 검사
- 수정 요청 / 재검사 횟수와 결과: 없으면 없음. 있으면 실제 내용과 횟수
```

첫 결과가 맞으면 바로 다음 단계로 진행합니다. 틀렸다면 오류를 기록한 상태에서도 Skill 작성으로 진행할 수 있습니다. 결과 형식 등을 한 번 고쳐 확인하려면 첫 응답과 실패 기록을 보존하고 같은 Chat에 수정할 지점 하나만 요청한 뒤 `test practice`를 한 번 더 실행합니다. 검사 도구는 각 과제에서 최대 두 번의 기록을 허용합니다.

### 단계 3. Hermes 기능으로 Skill 후보 만들고 승인하기

#### 3-1. /learn 요청 보내기

PowerShell에서 요청문을 복사한 뒤 **같은 첫 Chat**에 보냅니다.

```powershell
Get-Content -Raw -Encoding utf8 .\workspace\lesson11\learn_request.txt | Set-Clipboard
```

**Chat에 전달하는 요청문:**

```text
/learn 이 대화에서 수행한 교육용 문의 분류 절차를 재사용할 Skill로 정리하세요. 근거는 /workspace/lesson11/RULES.md, practice.json, practice_result.json, practice_check.json과 이 대화의 관찰 결과입니다. 필요하면 이 파일들만 읽으세요.
Skill 이름은 course11-inquiry-triage로 고정하고 category는 지정하지 마세요. 이 수업 전용이므로 다른 Skill을 변경하거나 합치지 마세요. skills_list로 이름을 확인할 수 있습니다.
장애 우선 판단, 두 분야 동시 해당·둘 다 미해당, 출력 계약, 검증 방법을 포함하세요. 특정 id의 정답을 암기하는 대신 새 입력에도 적용할 절차로 작성하세요. 규칙을 본문에 담아 이 Chat 없이도 이해할 수 있게 하세요.
Hermes의 skill_manage의 operations 목록에 action="create" 작업 하나를 넣는 호출로 SKILL.md 하나만 제안하세요. write_file/patch/명령으로 런타임 Skill 파일을 직접 쓰지 마세요. 승인 대기 ID를 알려 주세요. 승인과 설정 변경은 교육생이 합니다.
명령 실행·추가 검색·패키지 설치·Memory 변경은 하지 마세요. 검사 실패가 있었다면 실패 내용과 올바른 규칙을 구분하고, 실행하지 않은 개선 효과는 주장하지 마세요. 후보를 제안한 뒤 멈추세요.
```

요청은 `/learn`으로 시작합니다. Agent가 이번 규칙과 실제 검사 결과에서 재사용할 절차를 정리하도록 합니다. 후보 저장에는 Hermes의 `skill_manage`를 사용하며, 이 버전에서는 `operations` 목록 안에 `create` 작업 하나를 넣는 호출을 사용합니다. 도구 이름은 교육생이 PowerShell에 입력하는 명령이 아닙니다.

**후보 저장의 도구 반환 예시(발췌):**

```json
{
  "success": true,
  "staged": true,
  "pending_id": "a1b2c3d4"
}
```

`staged: true`는 승인 대기로 저장됐다는 뜻입니다. `pending_id`는 승인할 후보를 구별하는 ID이며 위 값은 가상 예시입니다. 이 상태를 Skill 설치 완료로 기록하지 않습니다.

#### 3-2. 승인 전 내용 읽기

Hermes Chat에 먼저 다음을 입력합니다.

```text
/skills pending
```

목록에서 `course11-inquiry-triage` 후보의 실제 ID를 확인합니다. 아래 명령의 `본인후보ID`를 그 값으로 바꾸어 입력합니다.

```text
/skills diff 본인후보ID
```

이 버전에서 `operations` 후보의 diff는 `(batch on '')` 같은 요약만 보여 줄 수 있습니다. 이를 빈 Skill이라고 단정하지 않습니다. PowerShell에서 후보와 보호 상태를 검사하고, 실제 후보의 `content`를 읽기용 복사본으로 남깁니다. **승인 여부는 다음 candidate.md의 전체 본문을 읽고 판단합니다.**

```powershell
.\lesson11.ps1 check pending
```

**주요 출력 예시(발췌):**

```json
{
  "stage": "pending",
  "one_candidate": true,
  "not_installed_yet": true,
  "create_only": true,
  "content_present": true,
  "candidate_id": "a1b2c3d4",
  "candidate_file": "records/lesson11/candidates/a1b2c3d4/candidate.md",
  "passed": true
}
```

```text
CHECK_PASS: pending
```

`candidate_file`은 승인 전 본문을 메모장에서 읽을 위치입니다. 화면에 나온 본인 ID를 넣어 실행합니다.

```powershell
$candidateId = '본인후보ID'
notepad (Join-Path '.\records\lesson11\candidates' "$candidateId\candidate.md")
```

**다음 항목을 읽고 판단합니다.** 자동 검사는 후보의 대상과 저장 상태를 확인하며, 절차의 품질까지 승인하지 않습니다.

| 검토 항목 | 적절한 내용 | 보완할 내용의 예 |
|---|---|---|
| 적용 범위 | 이 수업의 교육용 문의 분류 | 모든 고객지원 업무에 무조건 적용 |
| 판단 순서 | 전체 장애 조건을 먼저 확인 | 결제 단어를 보면 바로 billing |
| review 처리 | 두 분야 모두 해당·모두 미해당 처리 | 애매한 문의를 추측해서 배정 |
| 재사용성 | 어떤 id에도 적용할 순서 | 첫 네 문의의 정답만 나열 |
| 출력과 검증 | 네 키, 입력 순서, 교육생의 결과 검사 | 검사를 하지 않고 이미 통과했다고 설명 |
| 사용 도구 | 파일 읽기와 결과 작성에 필요한 도구 | 설치·네트워크·다른 Skill 변경을 추가 |

보완이 필요하면 **후보를 먼저 보관한 뒤** Hermes에서 그 ID만 거절합니다.

```text
/skills reject 본인후보ID
```

같은 Chat에 “거절한 후보에서 장애 우선 규칙을 보완해 주세요. 같은 이름으로 create 작업 하나를 다시 제안하고 승인 대기에서 멈추세요.”처럼 수정할 지점을 적습니다. 새 후보 ID에 대해 diff와 `check pending`을 다시 확인합니다. 이 수업에서는 보완 후 한 번 더 검토하고, 다시 문제가 있으면 기록을 남기고 멈춥니다. 다른 사람의 후보까지 포함하는 `all` 승인은 사용하지 않습니다.

#### 3-3. 검토한 ID 승인하고 실제 Skill 보관하기

내용이 적절하면 Hermes Chat에서 본인 ID 하나를 승인합니다.

```text
/skills approve 본인후보ID
```

**성공 응답 예시:**

```text
Approved 1 skills write(s).
```

응답에 `Failed:`가 있으면 설치 실패 이유를 읽고 기록합니다. 실패한 후보를 승인 완료로 적지 않습니다.

PowerShell에서 실제 저장된 Skill을 확인하고 보관합니다.

```powershell
.\lesson11.ps1 capture
Get-Content -Raw -Encoding utf8 .\records\lesson11\approved-skill.json
notepad .\records\lesson11\approved-skill\SKILL.md
```

**보관 결과 예시(발췌):**

```json
{
  "name": "course11-inquiry-triage",
  "skill_sha256": "실제 출력의 64자리 SHA-256 값",
  "matching_candidate_ids": ["a1b2c3d4"]
}
```

```text
CAPTURE_PASS: native Skill content copied for review and later comparison.
```

`skill_sha256`은 `/opt/data/skills/course11-inquiry-triage/SKILL.md` 내용의 식별값입니다. `matching_candidate_ids`는 설치된 본문과 내용이 같은 보관 후보 ID입니다. 파일 내용의 일치와 실제 승인 행동을 연결하려면 Hermes의 승인 응답도 보관해야 합니다.

#### 3-4. 3절 기록과 첫 세션 보관

```powershell
notepad .\records\lesson11\learn_response.md
notepad .\records\lesson11\approval_response.md
notepad .\records\lesson11\self_improvement_review.md
```

`learn_response.md`에는 후보 작성의 마지막 Agent 응답을, `approval_response.md`에는 본인이 보낸 승인 명령과 Hermes의 실제 응답을 보관합니다. 보완했다면 최초와 보완 응답을 구분해서 남깁니다.

관찰 기록 **3절**을 채웁니다.

```markdown
## 3. Skill 후보 검토와 승인
- /learn 요청 / 응답 보관 파일: learn_request.txt / learn_response.md
- skill_manage 실제 호출 / action / name: 실제 호출 확인 내용 / create / course11-inquiry-triage
- 승인 대기 ID / 후보 기록 파일: 본인 ID / candidates/본인 ID/pending.json
- 검토 의견 / 보완 또는 거절 기록: 본인이 읽고 판단한 내용
- Hermes에서 실행한 승인 명령 / 실제 응답: /skills approve 본인 ID / 실제 응답
- 승인 Skill 경로 / skill_sha256: /opt/data/skills/course11-inquiry-triage/SKILL.md / 실제 해시
- capture 결과 / 보관 파일: 실제 결과 / approved-skill/SKILL.md, approved-skill.json
```

Hermes 웹 대시보드에서 첫 Chat을 JSON으로 내보내 `records\lesson11`에 보관합니다. 다운로드된 파일명은 그대로 사용합니다. 같은 세션을 다시 내보낼 때만 기존 파일을 덮어쓰지 않도록 `-revised` 등의 구분을 붙이고 실제 이름을 기록합니다.

### 단계 4. 새 Chat에서 저장된 절차 적용하기

#### 4-1. Skill을 읽을 새 Chat 열기

Hermes 웹 대시보드에서 새 Chat을 열고 한 줄씩 입력합니다.

```text
/title self-improvement-lesson11-reuse
/model z-ai/glm-5.3-flash
/reasoning low
/status
```

PowerShell에서 요청을 복사해 새 Chat에 보냅니다.

```powershell
Get-Content -Raw -Encoding utf8 .\workspace\lesson11\reuse_request.txt | Set-Clipboard
```

**Chat에 전달하는 요청문:**

```text
Hermes의 skill_view 도구로 course11-inquiry-triage Skill을 먼저 읽으세요.
그 Skill의 절차를 /workspace/lesson11/reuse.json에 적용하여 /workspace/lesson11/reuse_result.json만 작성하세요.
이전 Chat의 응답·첫 과제 결과·정답 파일은 읽지 마세요. Skill에 필수 규칙이 빠져 있으면 추측하지 말고 빠진 내용을 보고하고 멈추세요.
명령 실행·검색·설치·Memory·설정·Skill 변경은 하지 마세요.
마지막에 실제 사용한 도구, 적용한 규칙, 변경 파일, 아직 실행하지 않은 검사를 요약하고 멈추세요.
```

요청은 Agent가 **먼저 `skill_view`로 `course11-inquiry-triage`를 읽고**, 새로운 문의 네 건을 처리하도록 합니다. 새 문의는 비밀번호, 결제 내역, 로그인 단어가 함께 있는 전체 장애, 운영 시간 문의입니다. 앞 세 건은 익힌 판단 순서를 적용하고, 마지막은 어느 분야에도 해당하지 않는 조건을 확인합니다.

도구 이력에서 Skill 이름과 실제 조회 호출을 확인합니다. “Skill을 사용했다”는 요약만 있으면 실제 호출을 확인하기 전까지 조회 완료로 기록하지 않습니다. 필수 규칙이 빠져 작업이 중단되면 누락 내용을 관찰 기록에 남깁니다.

#### 4-2. 결과 검사

Agent가 결과 파일을 작성하고 멈추면 실행합니다.

```powershell
.\lesson11.ps1 test reuse
Get-Content -Raw -Encoding utf8 .\workspace\lesson11\reuse_result.json
Get-Content -Raw -Encoding utf8 .\workspace\lesson11\reuse_check.json
```

**결과 비교 예시(발췌):**

```json
{
  "phase": "reuse",
  "matched": 4,
  "total": 4,
  "passed": true,
  "differences": [],
  "skill_sha256": "승인된 Skill의 실제 64자리 SHA-256 값"
}
```

```text
RECORDED: records/lesson11/checks/reuse-예시식별자.json
TASK_PASS: reuse
```

`differences`가 비어 있고 `passed`가 `true`이면 제공한 네 입력의 출력 계약을 만족했습니다. 검사 기록의 `skill_sha256`은 그때 승인 Skill의 내용과 결과를 연결합니다. 이 값만으로 모델의 실제 조회 여부까지 증명하지는 않으므로 Chat 도구 이력도 확인합니다.

실패하면 첫 결과와 검사를 보관하고 원인을 나눕니다. Skill의 규칙은 맞는데 출력 키나 적용이 틀렸다면 같은 Chat에 그 지점 하나를 수정 요청하고 한 번만 재검사합니다. **Skill 자체의 규칙이 빠졌다면 승인본을 몰래 고치지 않습니다.** 누락과 실패를 기록한 뒤 멈추고 7절의 조건부 복원 여부를 판단합니다. 이번 입문 실습은 승인한 절차를 고정한 채 재사용하는 범위로 진행합니다.

#### 4-3. 4절 기록

```powershell
notepad .\records\lesson11\reuse_response.md
notepad .\records\lesson11\self_improvement_review.md
```

`reuse_response.md`에는 마지막 Agent 응답 원문을 저장합니다. 관찰 기록 **4절**은 다음 형식으로 작성합니다.

```markdown
## 4. 새 Chat의 조회와 적용
- 새 Chat 이름 / 모델 / 추론 설정: self-improvement-lesson11-reuse / z-ai/glm-5.3-flash / low
- skill_view 실제 호출 / 조회한 Skill: 실제 이력에서 확인한 호출 / course11-inquiry-triage
- 재사용 결과 / 검사 파일: workspace/lesson11/reuse_result.json / checks/본인 reuse 검사 파일명
- matched / total / passed: 본인의 검사 값
- 규칙을 적용한 근거: 장애 우선 조건과 어느 분야에도 해당하지 않는 문의의 review 처리를 실제 결과에서 확인한 내용
- 수정 요청 / 재검사 횟수와 결과: 본인의 실제 기록
- 판단 범위: Skill 조회와 제공 입력의 결과를 확인했다. 다른 업무 전체의 정확성이나 성능 향상은 검증하지 않았다.
```

새 Chat도 JSON으로 내보내 `records\lesson11`에 보관합니다. 첫 Chat과 새 Chat의 파일을 각각 남깁니다.

### 단계 5. 최종 점검과 관찰 기록 완성하기

```powershell
.\lesson11.ps1 check final
Get-Item .\records\lesson11\self_improvement_review.md
Get-Item .\records\lesson11\practice_response.md, .\records\lesson11\learn_response.md, .\records\lesson11\approval_response.md, .\records\lesson11\reuse_response.md
Get-ChildItem .\records\lesson11 -Filter 'session*.json'
Get-ChildItem .\records\lesson11\checks -Filter '*.json'
notepad .\records\lesson11\self_improvement_review.md
```

**최종 검사 예시(주요 항목 발췌):**

```json
{
  "stage": "final",
  "settings_unchanged": true,
  "earlier_workspace_unchanged": true,
  "earlier_records_unchanged": true,
  "existing_skill_contents_unchanged": true,
  "memory_unchanged": true,
  "inputs_unchanged": true,
  "other_pending_unchanged": true,
  "task_sources_unchanged": true,
  "workspace_scope_matches": true,
  "approved_skill_current": true,
  "reuse_result_current_and_passed": true,
  "practice_result_recorded": true,
  "lesson_pending_empty": true,
  "passed": true
}
```

```text
RECORDED: records/lesson11/check-final-예시식별자.json
CHECK_PASS: final
```

`approved_skill_current`는 승인 후 보관한 Skill과 현재 설치된 Skill이 같다는 뜻입니다. `reuse_result_current_and_passed`는 현재 결과 파일이 통과한 검사와 같고 그때의 Skill도 현재 승인본과 같다는 뜻입니다. 이전 교시의 파일과 입력은 `earlier_*`, `inputs_unchanged`로 확인합니다.

`practice_result_recorded`는 첫 결과가 검사됐다는 뜻이며 반드시 성공했다는 뜻은 아닙니다. 실패에서 배운 절차를 남긴 경우도 구분해서 기록합니다. 관찰 기록의 완성도와 실제 native 도구 사용은 사람이 확인합니다.

**5절을 완성합니다.** 아래 문장은 모든 해당 항목을 직접 확인했을 때 쓸 수 있는 가상 예시입니다.

```markdown
## 5. 최종 점검과 보관
- check final 결과 / 파일명: 본인 결과 / 본인 check-final 파일명
- 보호 대상 / 차이 목록: 기존 작업·기록·Skill 본문·Memory·설정·입력의 검사 결과를 그대로 기록
- 처음부터 끝까지의 세션 JSON: 첫 Chat의 실제 파일명 / 새 Chat의 실제 파일명
- 첫 응답 / 학습 응답 / 재사용 응답 보관 파일: practice_response.md / learn_response.md / reuse_response.md. 승인 명령과 응답은 approval_response.md
- 최종 판단 / 다음에 활용할 것: 첫 과제의 관찰에서 분류 절차를 Skill로 정리하고 후보를 검토·승인했다. 새 Chat에서 skill_view 호출과 다른 네 입력의 결과를 확인했다. 승인 Skill과 두 과제의 검사·세션을 보관한다. 확인한 범위는 이 교육용 규칙과 입력이며 일반 업무의 개선 효과까지 단정하지 않는다.
```

### 같은 기록이 완성되는 모습

| 시점 | 채우는 절 | 기록의 변화 |
|---|---|---|
| 준비 완료 | 1절 | 환경과 시작 검사 결과를 적음 |
| 첫 과제 검사 | 2절 | 실제 결과, 오류 유무, 재사용할 절차 추가 |
| 후보 검토·승인 | 3절 | 후보 ID, 검토 의견, 승인 명령, 실제 Skill 해시 추가 |
| 새 Chat 적용 | 4절 | 조회 도구 이력과 다른 입력의 검사 결과 추가 |
| 최종 확인 | 5절 | 보호 대상 검사, 두 세션 파일명, 최종 판단 완성 |

전체 작성 예시는 `examples/lesson11-stages/01_start.md`부터 `05_final.md`까지 제공합니다. 각 파일은 그 시점까지 누적된 가상 기록입니다. 본인 파일에 예시 결과를 덮어쓰는 용도가 아니라, 어떤 절을 언제 채우는지 참고하는 자료입니다.

## 7) 완료 점검과 조건부 복원

### 완료 점검

- `/learn` 요청 뒤 `skill_manage`로 후보가 저장됐는가?
- 후보의 실제 내용을 읽고 ID 하나를 승인했는가?
- `capture`가 승인된 Skill을 보관했는가?
- 새 Chat에서 `skill_view`가 실제로 호출됐는가?
- 재사용 결과가 검사를 통과하고 사람의 내용 검토도 끝났는가?
- 두 Chat, 원문 응답, 검사와 관찰 기록이 남았는가?

### 다시 시작해야 할 때만 복원하기

정상 완료한 뒤에는 복원하지 않아도 됩니다. 과제 파일을 잘못 수정했거나 승인한 Skill을 바꾸고 처음부터 다시 관찰해야 할 때 사용합니다. 현재 Agent 작업을 멈추고 두 Chat을 내보내 보관한 뒤 PowerShell에서 실행합니다.

```powershell
.\lesson11.ps1 restore
```

복원 도구는 현재 과제·결과·관찰 기록·이번 Skill·남아 있는 이번 후보를 `records/lesson11-attempts/고유식별자`에 먼저 복사하고 확인합니다. 이후 전용 과제 폴더를 **첫 요청 직전의 진입점**으로 되돌리고 이번에 만든 `course11-inquiry-triage`와 그 이름의 승인 대기 후보를 제거합니다. 기존 Skill 본문, 다른 후보, 앞 교시 기록·입력·설정·Memory와 인증은 유지합니다.

Hermes의 세션과 사용·변경 이력은 실제로 있었던 행동의 기록이므로 지우지 않습니다. 따라서 복원 후에는 반드시 새 Chat을 엽니다. 보호 대상 중 다른 파일이나 설정까지 달라졌다면 도구가 자동으로 덮어쓰지 않고 중단합니다. 중단 메시지와 보관 경로를 유지한 채 원인을 확인합니다.

**주요 출력 예시:**

```text
RESTORE_PASS: Lesson11 entry restored; attempt retained at /course-host/records/lesson11-attempts/예시식별자
START_READY
```

성공한 뒤 다음 순서로 진행합니다.

```powershell
docker compose up -d --force-recreate hermes
docker compose ps
```

`healthy`를 확인하고 새 Chat의 제목·모델·추론 설정을 지정한 뒤 실행합니다.

```powershell
.\lesson11.ps1 check start
```

`prepare`를 반복하지 않습니다. 단계 2의 첫 과제부터 새 시도로 진행하고, 앞선 실패·거절·재검사 기록은 보관한 시도에 남깁니다.

## 8) 핵심 내용과 수업 이후의 활용

Hermes는 작업 절차를 Skill로 저장하고 다음 Chat에서 조회하는 기능을 제공합니다. 교육생은 **어떤 경험을 남길지, 후보가 적절한지, 실제 적용 결과가 맞는지** 판단합니다. 저장·승인·조회·적용·검사 중 하나가 빠지면 나머지 결과로 대신 설명하지 않습니다.

앞으로 자신의 반복 업무에 적용할 때도 먼저 작은 과제와 판단 기준을 마련합니다. 한 번의 작업에서 얻은 절차를 후보로 만들고 검토한 뒤, 다른 입력에서 다시 확인합니다. 이번 실습의 분류 단어는 교육용이므로 실제 고객지원 업무에 그대로 적용하지 않습니다.

### 기능 확인 근거

- [Hermes 공식 Skills 안내](https://hermes-agent.nousresearch.com/docs/user-guide/features/skills): Skill 저장·조회와 사용자 승인 개념.
- [수업 고정 버전의 /learn 구현](https://github.com/NousResearch/hermes-agent/blob/v2026.9.7/agent/learn_prompt.py): 작업 경험을 Skill 작성 요청으로 전달.
- [수업 고정 버전의 skill_manage](https://github.com/NousResearch/hermes-agent/blob/v2026.9.7/tools/skill_manager_tool.py): 생성 작업과 승인 대기 처리.
- [수업 고정 버전의 승인 명령](https://github.com/NousResearch/hermes-agent/blob/v2026.9.7/hermes_cli/write_approval_commands.py): pending·diff·approve·reject 처리.

이 링크들은 참고 자료입니다. 실습 중 Agent에게 인터넷 검색을 시키거나 최신 버전으로 바꾸는 단계는 없습니다.
