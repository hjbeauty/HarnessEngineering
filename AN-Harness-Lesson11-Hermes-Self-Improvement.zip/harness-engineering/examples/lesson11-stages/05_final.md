# 11교시 자기 개선 관찰 기록 — 가상 예시

이 파일은 기록 방법을 보여 주는 가상 사례다. ID·파일명·해시·결과는 본인의 관찰값으로 작성한다.

## 1. 시작 상태
- 작성자 / 날짜: 예시 교육생 / 본인 실습 날짜
- 모델 / 추론 설정: z-ai/glm-5.3-flash / low
- 첫 Chat 이름: self-improvement-lesson11-learn
- prepare / healthy / check start 결과: PREPARE_PASS / healthy / START_READY
- capabilities 파일 / native_source_matches: checkpoint/capabilities.json / true
- 앞 교시와의 관계: 환경과 모델 연결을 사용하며 앞 교시 완료 파일은 요구하지 않음

## 2. 첫 과제와 배운 절차
- 첫 결과 / 검사 파일: workspace/lesson11/practice_result.json / checks/practice-예시첫검사.json
- matched / total / passed: 3 / 4 / false
- 실제 도구 / 변경 파일: 파일 읽기와 쓰기 호출 확인 / practice_result.json
- 사람이 확인한 규칙과 오류: T03을 billing으로 분류했으나 전체 서비스·사용 불가가 모두 있어 incident가 맞다. 실제 첫 결과와 검사 보고서를 보존했다.
- 재사용할 절차: 장애 조건부터 확인한 뒤 계정·결제 분야를 각각 확인한다. 두 분야 모두 해당하거나 모두 미해당이면 review로 분류한다. 출력 키와 입력 순서를 마지막에 확인한다.
- 수정 요청 / 재검사 횟수와 결과: 첫 결과 수정 없음 / 재검사 0회. 확인된 오류를 Skill 작성의 근거로 사용했다.

## 3. Skill 후보 검토와 승인
- /learn 요청 / 응답 보관 파일: learn_request.txt / learn_response.md
- skill_manage 실제 호출 / action / name: operations에 create 작업 1개 확인 / create / course11-inquiry-triage
- 승인 대기 ID / 후보 기록 파일: a1b2c3d4(가상 ID) / candidates/a1b2c3d4/pending.json
- 검토 의견 / 보완 또는 거절 기록: 장애 우선·두 분야 동시 해당·모두 미해당·출력 계약·검증 절차를 읽었다. 첫 문의의 정답 나열에 그치지 않고 새 id에도 적용할 절차였다. 보완·거절 없음.
- Hermes에서 실행한 승인 명령 / 실제 응답: /skills approve a1b2c3d4 / Approved 1 skills write(s).
- 승인 Skill 경로 / skill_sha256: /opt/data/skills/course11-inquiry-triage/SKILL.md / 본인의 실제 64자리 값을 기록
- capture 결과 / 보관 파일: CAPTURE_PASS / approved-skill/SKILL.md, approved-skill.json

## 4. 새 Chat의 조회와 적용
- 새 Chat 이름 / 모델 / 추론 설정: self-improvement-lesson11-reuse / z-ai/glm-5.3-flash / low
- skill_view 실제 호출 / 조회한 Skill: 도구 이력에서 조회 확인 / course11-inquiry-triage
- 재사용 결과 / 검사 파일: workspace/lesson11/reuse_result.json / checks/reuse-예시첫검사.json
- matched / total / passed: 4 / 4 / true
- 규칙을 적용한 근거: N03은 로그인 단어가 있어도 전체 장애를 먼저 판단해 incident였다. N04는 두 분야 모두 해당하지 않아 review였다. 출력의 네 키와 순서도 검사와 대조했다.
- 수정 요청 / 재검사 횟수와 결과: 없음 / 0회
- 판단 범위: 승인 Skill 조회와 새로운 네 문의의 결과를 확인했다. 첫 과제와 새 과제의 점수 차이를 성능 향상 수치로 사용하지 않는다.

## 5. 최종 점검과 보관
- check final 결과 / 파일명: CHECK_PASS: final / check-final-예시최종검사.json
- 보호 대상 / 차이 목록: 기존 작업·기록·Skill 본문·Memory·설정·입력과 다른 후보의 유지 항목 true / 실패 항목 없음
- 처음부터 끝까지의 세션 JSON: session-예시첫Chat.json / session-예시새Chat.json
- 첫 응답 / 학습 응답 / 재사용 응답 보관 파일: practice_response.md / learn_response.md / reuse_response.md. 승인 명령·응답은 approval_response.md
- 최종 판단 / 다음에 활용할 것: 첫 과제에서 확인한 장애 우선 규칙을 재사용 절차로 정리했다. Hermes로 후보를 저장하고 검토·승인한 뒤 새 Chat에서 조회·적용했다. 새 입력 네 건은 통과했다. 승인 Skill, 첫 실패와 새 결과의 검사, 두 세션을 함께 보관한다. 일반적인 성능 개선이나 모든 문의의 정확성을 검증한 것은 아니다.
