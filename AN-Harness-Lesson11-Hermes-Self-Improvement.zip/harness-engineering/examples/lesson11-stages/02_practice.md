# 11교시 자기 개선 관찰 기록 — 가상 예시

이 파일은 기록 방법을 보여 주는 가상 사례다. ID·파일명·해시·결과는 본인의 관찰값으로 작성한다.

## 1. 시작 상태
- 작성자 / 날짜: 예시 교육생 / 본인 실습 날짜
- 모델 / 추론 설정: z-ai/glm-5.3-flash / low
- 첫 Chat 이름: self-improvement-lesson11-learn
- prepare / healthy / check start 결과: PREPARE_PASS / healthy / START_READY
- capabilities 파일 / native_source_matches: checkpoint/capabilities.json / true
- 앞 교시와의 관계: 환경과 모델 연결을 사용하며 앞 교시 완료 파일은 요구하지 않음

## 2. 첫 과제와 배운 절차
- 첫 결과 / 검사 파일: workspace/lesson11/practice_result.json / checks/practice-예시첫검사.json
- matched / total / passed: 3 / 4 / false
- 실제 도구 / 변경 파일: 파일 읽기와 쓰기 호출 확인 / practice_result.json
- 사람이 확인한 규칙과 오류: T03을 billing으로 분류했으나 전체 서비스·사용 불가가 모두 있어 incident가 맞다. 실제 첫 결과와 검사 보고서를 보존했다.
- 재사용할 절차: 장애 조건부터 확인한 뒤 계정·결제 분야를 각각 확인한다. 두 분야 모두 해당하거나 모두 미해당이면 review로 분류한다. 출력 키와 입력 순서를 마지막에 확인한다.
- 수정 요청 / 재검사 횟수와 결과: 첫 결과 수정 없음 / 재검사 0회. 확인된 오류를 Skill 작성의 근거로 사용했다.

이후 절은 해당 단계를 수행한 뒤 같은 관찰 기록에 추가한다.
