# 11교시 자기 개선 관찰 기록 — 가상 예시

이 파일은 기록 방법을 보여 주는 가상 사례다. ID·파일명·해시·결과는 본인의 관찰값으로 작성한다.

## 1. 시작 상태
- 작성자 / 날짜: 예시 교육생 / 본인 실습 날짜
- 모델 / 추론 설정: z-ai/glm-5.3-flash / low
- 첫 Chat 이름: self-improvement-lesson11-learn
- prepare / healthy / check start 결과: PREPARE_PASS / healthy / START_READY
- capabilities 파일 / native_source_matches: checkpoint/capabilities.json / true
- 앞 교시와의 관계: 환경과 모델 연결을 사용하며 앞 교시 완료 파일은 요구하지 않음

이후 절은 해당 단계를 수행한 뒤 같은 관찰 기록에 추가한다.
