# 11교시 추가 자료

2교시에서 만든 `C:\AI-Native\harness-engineering` 폴더에 이 ZIP의 `harness-engineering` 안쪽 내용을 합칩니다. 새 프로그램 설치나 compose.yaml 교체는 없습니다.
`11_hermes_self_improvement_preview.html`을 브라우저로 열고 단계 1부터 진행하세요. Markdown 원문은 `11_hermes_self_improvement.md`입니다.

Docker Desktop과 Hermes 웹 대시보드가 동작하고 모델 연결이 되어 있어야 합니다. 앞 교시의 판매 분석 결과·완료 기록은 필요하지 않습니다. 기존 작업과 인증을 보존하며 11교시 전용 경로를 사용합니다.

`starter`는 시작 자료, `templates`는 작성 양식, `examples`는 가상 작성 예시, `course-tools`는 교육용 검사 프로그램입니다. 준비 스크립트가 작업 자료와 기록 양식을 알맞은 위치로 복사합니다. 예시의 통과 값을 본인의 기록으로 복사하지 말고 직접 검사한 결과를 적습니다.
