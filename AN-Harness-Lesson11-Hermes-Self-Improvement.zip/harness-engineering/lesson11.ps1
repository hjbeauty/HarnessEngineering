[CmdletBinding()]
param(
 [Parameter(Mandatory=$true)][ValidateSet('prepare','check','test','capture','restore')][string]$Action,
 [ValidateSet('start','pending','final','practice','reuse')][string]$Stage='start'
)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
Set-Location -LiteralPath $PSScriptRoot
foreach ($name in @('compose.yaml','.env','course-tools/lesson11_self_improvement.py','course-tools/lesson11_check.py','starter/lesson11/TASK.md','starter/lesson11/native_sources.json','templates/self_improvement_review.md')) {
 if (-not (Test-Path -LiteralPath $name -PathType Leaf)) { throw "Required file missing: $name" }
}
if ($Action -eq 'test' -and $Stage -notin @('practice','reuse')) { throw 'Use test practice or test reuse.' }
if ($Action -eq 'check' -and $Stage -notin @('start','pending','final')) { throw 'Use check start, check pending or check final.' }
function Invoke-CourseHelper([string]$Verb,[string]$Phase='start') {
 & docker compose run --rm --no-deps -T --user hermes --workdir /tmp --entrypoint python --volume "${PSScriptRoot}:/course-host" hermes /course-tools/lesson11_self_improvement.py $Verb $Phase
 if ($LASTEXITCODE -ne 0) { throw "Lesson11 $Verb stopped. Preserve output and see the guide." }
}
if ($Action -eq 'prepare') { Invoke-CourseHelper 'preflight' }
if ($Action -in @('prepare','restore')) {
 & docker compose stop hermes
 if ($LASTEXITCODE -ne 0) { throw 'Could not stop Hermes.' }
}
Invoke-CourseHelper $Action $Stage
if ($Action -eq 'prepare') {
 & docker compose up -d --force-recreate hermes
 if ($LASTEXITCODE -ne 0) { throw 'Prepared; startup failed. Inspect logs without repeating prepare.' }
 Write-Host 'Next: healthy; NEW Chat; .\lesson11.ps1 check start.'
}
if ($Action -eq 'restore') {
 Write-Host 'Next: docker compose up -d --force-recreate hermes; healthy; NEW Chat; .\lesson11.ps1 check start.'
 Write-Host 'Do not repeat prepare.'
}
