# 11교시 전용 과제: 문의 분류 절차를 Skill로 남기기

이번 과제의 근거는 이 폴더의 RULES.md다. 판매 분석 프로그램·SPEC·PLAN·이전 교시 기록은 사용하지 않는다.
문의는 실제 고객 정보가 없는 교육용 문장이다. 외부 검색·접속·설치·명령 실행 없이 파일 읽기와 결과 작성으로 수행한다.

1. 첫 Chat: RULES.md와 practice.json을 읽고 practice_result.json을 작성한다.
2. 교육생: PowerShell의 lesson11.ps1 test practice로 결과를 검사하고 오류가 있으면 기록한다.
3. 같은 Chat: /learn으로 이번 절차를 course11-inquiry-triage라는 이름의 Skill 후보로 만든다. 저장은 skill_manage의 operations 목록에 action="create" 작업 하나를 넣는 호출를 사용하고 category는 지정하지 않는다. 새 Skill은 SKILL.md 하나로 구성한다. 다른 Skill과 합치지 않는다.
4. 교육생: Hermes의 /skills pending과 /skills diff로 후보를 검토한다. 올바른 후보의 ID 하나만 /skills approve로 승인한다.
5. 새 Chat: skill_view로 승인된 Skill을 읽고 reuse.json에 적용해 reuse_result.json을 작성한다.
6. 교육생: lesson11.ps1 test reuse로 검사하고 실제 조회·적용 이력을 대조한다.

Agent가 직접 쓸 작업 파일은 /workspace/lesson11/practice_result.json과 reuse_result.json뿐이다. Skill 저장은 native skill_manage와 사람의 승인으로 수행한다. 런타임 Skill 파일·승인 대기 JSON을 read_file/write_file/patch/명령으로 직접 수정하지 않는다.
검사 보고서는 교육 도구가 작성한다. Agent가 검사 통과 기록을 대신 작성하지 않는다.
Memory·설정·다른 Skill·앞 교시 파일은 변경하지 않는다. 모델 호출에는 기존 연결을 사용하지만 별도의 인터넷 자료 조회는 필요하지 않다.
