# 교육용 문의 분류 규칙

입력 JSON은 id와 text가 있는 객체의 배열이다. 실제 서비스 판단이 아닌 문자열 규칙 실습이다. 아래 단어는 text에 정확히 포함되는지를 확인한다. 띄어쓰기나 단어를 임의로 바꾸지 않는다.

## 판단 순서
1. text에 `전체 서비스`와 `사용 불가`가 모두 있으면 다른 단어보다 먼저 incident / urgent / SERVICE_DOWN을 선택한다.
2. 장애 조건이 아니면 로그인 분야와 결제 분야를 각각 확인한다. 로그인 분야는 `로그인` 또는 `비밀번호`가 있으면 해당한다. 결제 분야는 `결제` 또는 `영수증`이 있으면 해당한다.
3. 로그인 분야만 해당하면 access / normal / ACCESS다.
4. 결제 분야만 해당하면 billing / normal / BILLING이다.
5. 두 분야가 모두 해당하거나 둘 다 해당하지 않으면 review / normal / REVIEW다. 내용을 추측해 한 분야로 밀어 넣지 않는다.

## 출력 계약
입력 순서를 유지한 JSON 배열을 UTF-8로 저장한다. 각 객체에는 정확히 id, route, priority, rule 네 키가 있어야 한다. id는 입력 그대로다. 설명·담당자·날짜·점수 같은 키를 추가하지 않는다.

- route: access(계정), billing(결제), incident(전체 장애), review(사람의 분류 필요).
- priority: urgent(전체 장애), normal(나머지).
- rule: 적용한 규칙 코드 ACCESS, BILLING, SERVICE_DOWN, REVIEW.

판정 순서가 중요하다. 장애 조건이 맞으면 결제라는 단어가 함께 있어도 incident다. 단어가 둘 이상 있다고 무조건 review로 보내지 않는다.
검사는 준비된 정답과 id·키·값·순서를 비교한다. 첫 결과가 맞아도 실제 수행한 확인 절차를 재사용할 Skill로 남길 수 있다. 실패를 만들기 위해 규칙을 빼지 않는다.
