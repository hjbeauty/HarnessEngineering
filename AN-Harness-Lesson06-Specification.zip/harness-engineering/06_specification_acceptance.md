# 6교시. Specification & Acceptance Criteria — 무엇을 확인해야 ‘완료’일까?

**AI Native 소프트웨어 개발: Harness Engineering — 학습 가이드북**

## 1) 이번 교시에서 해결할 문제

**총매출은 맞는데, 잘못된 주문 한 건을 조용히 빼고 계산했다면 완료일까요?**

“매출을 정확하게 분석하고 보고서를 보기 좋게 만들어 주세요.”라고 요청하면 그럴듯한 결과를 얻을 수 있습니다. 하지만 오류를 어떻게 처리할지, 어떤 파일을 만들지, 이전 결과를 보존할지는 서로 다르게 이해할 수 있습니다.

5교시에서는 Agent가 참고할 업무 사실과 실행 환경을 정리했습니다. 이번에는 같은 데이터로 **무엇을 만들고, 무엇을 확인해야 완료인지** 정합니다. 명세가 모호할 때와 구체적일 때의 검토 결과를 비교하고, 다음 교시에서 사용할 완료 기준을 직접 작성합니다.

**명세(Specification)**는 프로그램이 지켜야 할 동작과 출력 규칙입니다. **인수조건(Acceptance Criteria)**은 그 규칙을 만족했는지 확인할 구체적인 기준입니다. 예를 들어 “수량 0이면 오류로 중단한다”는 명세를, “오류 입력에서 종료코드 2가 나오고 기존 보고서가 유지된다”는 인수조건으로 확인할 수 있습니다. 종료코드는 프로그램이 끝날 때 내보내는 숫자로, 이번 명세에서는 0을 정상, 2를 입력 규칙 위반에 사용합니다.

## 2) 학습목표와 완료 상태

| 할 수 있게 되는 일 | 이번 교시에서 남길 결과 |
|---|---|
| Context와 명세의 역할을 구분한다 | 업무 사실과 구현 요구를 구분한 검토 기록 |
| 모호한 요구를 관찰 가능한 조건으로 바꾼다 | 정상·오류·반복 실행의 인수조건 세 가지 |
| Agent의 답을 데이터와 문서로 확인한다 | 10행 직접 계산과 두 검토 응답의 근거 |
| 다음 교시에서 쓸 기준을 준비한다 | 구체화된 workspace/SPEC.md와 records/lesson06의 기록 |

이번 완료 대상은 **명세와 검토 기록**입니다. 분석 프로그램의 구현·실행 결과는 이후 교시에서 이 기준으로 확인합니다.

## 3) 시작 전 준비

### 준비할 것

Docker Desktop을 실행하고 6교시 ZIP을 다운로드합니다. 압축 해제는 단계 1에서 함께 진행합니다.

5교시에서 저장 경로 충돌을 정리한 상태로 이어갑니다. 준비 명령은 앞 교시의 작업을 보관하고, 5교시에서 사용한 네 Context 문서의 공통 내용을 6교시 시작 파일로 준비합니다. 교육생마다 앞선 응답이 달라도 같은 파일에서 이번 실습을 시작할 수 있습니다.

| 준비물 | 확인할 상태 |
|---|---|
| 2교시 실행 환경 | compose.yaml, Docker, 웹 대시보드 로그인 준비 |
| 3교시 Baseline | lesson03.ps1 verify로 보존 확인 가능 |
| 공통 판매 데이터 | inputs/lesson03/sales.csv 및 inputs/sales/ 아래 파일들 |
| 실행 조건 | GLM 5.3 Flash, Hermes 추론 설정 low |

### 제공 파일

폴더 이름 뒤의 `/`는 그 안에 여러 파일이 들어 있다는 표시입니다. `workspace`는 Agent의 작업 공간, `records`는 교육생이 관찰과 검사 결과를 보관하는 곳입니다. `.md`는 메모장으로 읽고 쓰는 Markdown 문서이고, `.json`은 항목 이름과 값을 짝지어 저장하는 기록 형식입니다.

| 이번 ZIP의 주요 파일 | 역할 |
|---|---|
| lesson06.ps1 | 준비·검사·기준값 확인·명세 적용·복원 명령 |
| course-tools/lesson06_specification.py | 컨테이너에서 실행하는 보조 도구 |
| starter/lesson06/entry/ | 네 Context 문서, 명세 초안, 같은 검토 요청 |
| starter/lesson06/reference/SALES_SPEC.md | 구체화 단계에서 적용할 공통 명세 |
| templates/spec_review.md | 직접 작성할 기록 양식 |
| examples/spec_review_example.md | 실제 실행 결과를 반영한 최종 기록 예시 |
| examples/spec_review_progression.md | 한 기록 파일이 완성되는 과정 |
| examples/spec_review_stages/ | 시작부터 최종 확인까지 단계별 전체 기록 예시 |

`starter`는 준비 명령이 작업 폴더에 복사할 바탕 파일을 보관한 곳입니다. Agent는 `workspace`에 준비된 문서를 읽습니다. `records`에는 내가 작성한 관찰과 검사 결과를 보관합니다.

### 이번에 읽거나 작성하는 파일의 역할

| 위치 | 내용과 목적 | 이번에 하는 작업 |
|---|---|---|
| `workspace/CONTEXT_INDEX.md`, `workspace/context/` | 문서 목차와 환경·제약·업무 배경·관례 | 두 검토에서 공통 근거로 읽기 |
| `workspace/SPEC.md` | 처음에는 모호한 명세 초안, 뒤에는 구체화된 공통 명세 | 교체 전후 읽고 요구의 차이 비교 |
| `starter/lesson06/reference/SALES_SPEC.md` | 입력·계산·출력·오류를 정한 공통 명세의 바탕 | `specify`가 적용할 원본으로 유지 |
| `workspace/review_request.txt` | 두 검토에서 사용할 같은 요청 | 새 Chat에 각각 한 번 전송 |
| `inputs/sales/sales_micro.csv` | 직접 계산하기 쉬운 정상 판매 입력 10행. micro는 작은 표본을 뜻함 | 행별 계산과 56,000원·19개 확인 |
| `inputs/sales/errors/quantity_zero.csv` | 수량이 0인 주문을 포함한 시험용 입력 | 오류 위치와 처리 기준 비교 |
| `inputs/lesson03/sales.csv` | 200행 공통 원본 | 원본 보존 확인, 제공 도구의 기준값 참고 |
| `records/lesson06/spec_review.md` | 실행 조건·계산 근거·응답 비교·인수조건을 모으는 내 기록 | 단계가 끝날 때 해당 절을 추가 작성 |
| `records/lesson06/draft_response.md`, `specified_response.md` | 초안·구체화 후 Agent의 최종 응답 | 응답 원문을 각각 보관 |
| `records/lesson06/checkpoint/` | 준비 직후 파일과 관련 설정의 사본 | 검사 기준과 필요할 때의 복원 지점으로 유지 |

`templates/spec_review.md`는 빈 양식입니다. 준비 후에는 **`records/lesson06/spec_review.md`를 계속 채웁니다.** `examples` 아래 파일들은 한 기록이 단계별로 완성되는 모습을 보여 줍니다. 참고 예시의 작성자·시각·파일명을 내 결과로 바꿔 적습니다.

### 스크립트와 Python 프로그램을 사용하는 이유

`lesson06.ps1`은 Windows에서 실행할 명령을 받아 Docker를 관리합니다. `lesson06_specification.py`는 컨테이너 안에서 준비 파일·설정·데이터를 검사하고 기록을 남깁니다. Python은 제공 이미지에 들어 있습니다.

| 사용하는 명령 | 무엇을 왜 하는가 | 확인할 결과 |
|---|---|---|
| `prepare` | 앞 교시 작업을 보관하고 초안·같은 요청·빈 기록·체크포인트 준비 | `PREPARE_PASS` |
| `check start` / `check draft` | 초안 검토 전후에 파일과 조건이 유지됐는지 확인 | 시작 준비 또는 초안 상태의 검사 JSON |
| `facts` | 제공 CSV의 행별 매출과 합계를 보여 주어 내 계산의 근거 마련 | `facts-…json`, `FACTS_READY` |
| `specify` | 초안 상태를 확인하고 `SPEC.md`를 구체적인 공통 명세로 교체 | `SPEC_READY` |
| `check specified` / `check final` | 구체화 상태와 최종 상태가 해당 단계의 기준에 맞는지 검사 | 해당 단계의 검사 JSON |
| `restore` | 파일을 잘못 바꾼 경우 준비 직후의 초안 상태로 돌아감 | 현재 시도 보관 후 `RESTORE_PASS` |

`facts`의 계산은 나중에 만들 분석 프로그램과 결과를 비교할 기준입니다. 이번에는 그 기준을 직접 계산으로 대조하고 **무엇을 시험할지** 기록합니다. 실제 프로그램의 계산·오류 처리는 구현 후에 검사합니다. 명령은 아래 단계에서 순서대로 실행합니다.

**ZIP 전체를 다운로드합니다.** 가이드북 파일만 받으면 준비 도구와 시작 문서가 부족합니다. CSV는 앞에서 준비한 공통 데이터 세트를 그대로 사용합니다.

**검사 결과 읽기:** `PASS`는 그 명령이 검사한 조건을 통과했다는 표시이고, `RECORDED` 뒤의 경로는 자동 저장된 기록 파일입니다. `true`와 `false`는 각 항목의 참·거짓, `[]`는 빈 목록, `null`은 값이 지정되지 않았거나 해당 단계에서 평가하지 않았음을 뜻합니다. 예를 들어 시작 전에 “파일이 존재한다”가 `false`인 것은 정상일 수 있습니다. 바로 아래 단계별 예상 상태와 함께 읽습니다.

### 입력 장소

| 입력할 곳 | 이번 실습의 위치 |
|---|---|
| Windows PowerShell | C:\AI-Native\harness-engineering |
| Hermes 웹 대시보드 | http://127.0.0.1:9119 → CHAT |
| Agent가 읽는 작업 폴더 | /workspace |
| Windows에서 같은 파일을 여는 위치 | C:\AI-Native\harness-engineering\workspace |
| 관찰 기록 폴더 | C:\AI-Native\harness-engineering\records\lesson06 |

## 4) 실습에 필요한 핵심 이론

### 4.1 Context는 배경을, 명세는 만들어야 할 결과를 설명합니다

| 구분 | 쉽게 말하면 | 이번 데이터의 예 |
|---|---|---|
| Context | 일을 이해하는 데 필요한 사실과 제약 | 단가에는 할인이 이미 반영되어 있다 |
| 명세(Specification) | 프로그램이 지켜야 할 약속 | 수량 × 단가로 계산하고 두 결과 파일을 만든다 |
| 인수조건(Acceptance Criteria) | 완료라고 판단할 때 확인할 것 | 10행 입력에서 총매출 56,000원과 총수량 19개가 나온다 |

명세 파일 이름은 `SPEC.md`입니다. Agent에게 “알아서 잘 해라”라고 맡겼던 결정을 파일에 적어 두면, 사람과 Agent가 같은 기준으로 구현과 결과를 검토할 수 있습니다. 이것이 이번에 추가하는 Harness입니다.

### 4.2 인수조건은 세 문장으로 시작합니다

**준비된 조건 → 실행할 행동 → 확인할 결과**로 씁니다. 영어로는 Given–When–Then이라고 합니다.

| 모호한 문장 | 확인 가능한 문장 |
|---|---|
| 정확하게 계산한다 | sales_micro.csv의 총매출은 56,000원, 총수량은 19개다 |
| 오류를 적절히 처리한다 | 수량 0을 만나면 코드 2로 종료하고 기존 두 결과 파일은 바뀌지 않는다 |
| 일관된 보고서를 만든다 | 같은 프로그램·환경·논리 입력에서는 출력 파일의 바이트가 같다 |

여기서 **논리 입력**은 파일의 줄바꿈이나 행 배치가 달라도 주문과 값의 내용이 같은 입력을 뜻합니다. **바이트가 같다**는 것은 파일에 저장된 숫자·문자·줄바꿈까지 같은 상태를 말합니다. 합계만 같고 보고서에 매번 다른 현재 시각이 들어가면 바이트는 달라집니다.

**검증 방법도 함께 적습니다.** 합계는 숫자로, 오류는 종료코드와 오류 메시지로, 파일 보존은 변경 전후 해시로 확인합니다. 해시는 파일 내용으로 계산한 식별값입니다. 파일이 그대로인지 비교하는 데 사용합니다.

### 4.3 ‘실패할 때 어떻게 해야 하는가’도 명세입니다

정상 종료코드는 `0`, 이번 명세의 입력 오류 종료코드는 `2`입니다. `stderr`는 프로그램이 오류 내용을 내보내는 통로입니다. PowerShell에서 실행한 프로그램의 종료코드는 `$LASTEXITCODE`로 확인할 수 있습니다.

```mermaid
flowchart TD
  A["입력 전체 검사"] --> B{"입력 규칙을 만족하는가?"}
  B -->|예| C["계산 후 두 결과 파일 저장"]
  C --> D["종료코드 0"]
  B -->|아니오| E["오류 위치와 이유 기록"]
  E --> F["기존 결과 보존 · 종료코드 2"]
```

오류가 있는 행을 조용히 제외하면 보고서가 완성된 것처럼 보여도 매출이 달라집니다. 이번 공통 명세는 **입력 오류를 알리고 기존 결과를 보존**하도록 정합니다. 운영체제 오류 등 모든 실패를 무조건 코드 2로 분류한다는 뜻은 아닙니다.

### 4.4 검토 통과와 프로그램 통과는 다릅니다

| 지금 확인하는 것 | 프로그램 구현 후 확인할 것 |
|---|---|
| 명세에 파일명과 계산 규칙이 있는가 | 실제 파일과 계산값이 맞는가 |
| 오류 시 행동이 정해져 있는가 | 오류 입력에서 실제로 그 행동을 하는가 |
| 인수조건에 검증 방법이 있는가 | 그 방법으로 검사해 통과하는가 |

자동 검사는 파일과 저장된 설정이 바뀌었는지 확인합니다. Agent가 근거를 제대로 찾았는지는 실제 응답과 도구 기록을 읽어 판단합니다. 이번 비교는 명세의 역할을 관찰하는 실습이며, 프로그램의 성능 개선을 측정한 결과는 아닙니다.

## 5) 전체 작업 흐름

| 단계 | 하는 일 | 확인할 결과 |
|---|---|---|
| 1 | 파일 준비, 새 Chat, 시작 상태 검사 | START_READY |
| 2 | 10행 계산과 오류 위치 확인, 기준값 기록 | 56,000원·19개, 오류 레코드 5 |
| 3 | 명세 초안 검토, 첫 응답과 세션 보관 | 빠진 조건과 이미 주어진 조건의 구분 |
| 4 | 공통 명세 적용, 세 가지 인수조건 작성 | SPEC_READY와 정상·오류·반복 실행의 판정 기준 |
| 5 | 같은 요청으로 새 Chat에서 검토, 두 응답 비교 | 구체화 전후의 근거와 판단 기록 |
| 6 | 최종 검사와 기록 확인 | CHECK_PASS: final, Baseline 보존, 증거 파일 |

```mermaid
flowchart TD
  A["공통 진입점 준비 · 기준값 확인"] --> B["명세 초안 검토"]
  B --> C["SPEC.md를 구체화"]
  C --> D["같은 요청으로 새 Chat에서 검토"]
  D --> E{"질문과 인수조건을 확인했는가?"}
  E -->|예| F["기록 보관 · 7교시 준비"]
  E -->|결정 필요| G["근거와 질문을 기록"]
  G --> F
```

두 검토 사이에 바꾸는 작업 파일은 `SPEC.md` 하나입니다. Context·데이터·요청·모델·추론 설정은 유지합니다. 두 번째 검토는 새 Chat에서 시작하여 첫 답변을 대화로 물려받지 않게 합니다. 응답 표현이나 질문 개수가 같아야 하는 실습은 아닙니다.

## 6) 단계별 실습

**기록 예시를 사용하는 방법**

아래 예시는 실제 실습 결과를 바탕으로 **각 단계에서 무엇을 추가로 적는지** 보여 줍니다. 시작 상태 → 계산 근거 → 초안 검토 → 인수조건 → 전후 비교 → 최종 확인 순서로 같은 기록을 완성합니다.

교육생이 작성하는 파일은 `records/lesson06/spec_review.md` 하나입니다. 앞에서 적은 내용은 유지하고, 해당 단계에서 확인한 내용만 추가합니다. 단계별 예시 파일을 차례로 덮어쓰는 실습은 아닙니다.

**예시의 작성자·날짜·세션 이름·자동 생성 파일명·관찰 결과는 본인의 결과로 바꾸세요.** 직접 계산했다는 기록도 실제로 확인한 뒤 적습니다. 아직 실행하지 않은 검사는 ‘확인 전’으로 두고, 해당 단계에서 받은 결과로 바꿉니다. `CHECK_PASS`는 파일과 저장된 설정을 검사한 결과이고, 응답 내용의 정확성은 문서와 대조해 판단합니다.

| 작성 시점 | 이번에 채우는 부분 | 다음 단계에서 채울 부분 | 누적 기록 예시 |
|---|---|---|---|
| prepare 직후 | 기록 양식 준비 | 모든 관찰 내용 | [00_blank.md](examples/spec_review_stages/00_blank.md) |
| 단계 1-8 | 1절 실행 조건, 5절 시작 검사, 6절 시작 파일명 | 기준값·두 응답·인수조건 | [01_start.md](examples/spec_review_stages/01_start.md) |
| 단계 2-2 | 2절 기준값과 계산 근거, 6절 facts 파일명 | 두 응답·인수조건 | [02_facts.md](examples/spec_review_stages/02_facts.md) |
| 단계 3-5 | 3절 초안 열, 초안 세션·도구·검사 기록 | 구체화 후 열·나의 판단·인수조건 | [03_draft.md](examples/spec_review_stages/03_draft.md) |
| 단계 4-3 | 4절 정상·오류·반복 인수조건·명세 교체 결과 | 두 번째 응답·전후 비교 | [04_acceptance.md](examples/spec_review_stages/04_acceptance.md) |
| 단계 5-5 | 3절 나머지 두 열, 두 번째 세션·도구·질문 | 최종 파일 검사·종료 시 Baseline | [05_comparison.md](examples/spec_review_stages/05_comparison.md) |
| 단계 6-3~6-4 | 5·6절 최종 검사·실제 파일명·보관 확인 | 내용 확인 후 완료 | [06_final.md](examples/spec_review_stages/06_final.md) |


PowerShell 명령은 `C:\AI-Native\harness-engineering`에서 실행합니다. 각 블록 위의 **입력 장소와 목적**을 확인한 뒤 실행하고, 바로 아래의 결과를 확인합니다. 메모장에서 작업 파일을 읽을 때와 관찰 기록을 작성할 때도 구분해서 안내합니다.

### 단계 1. 제공 파일을 추가하고 명세 검토를 준비한다

먼저 5교시 작업을 보관하고, 이번에 비교할 명세 초안을 준비합니다. 이 단계가 끝나면 파일·모델·설정이 준비되어 첫 검토를 시작할 수 있습니다.

**1-1. ZIP을 작업 폴더에 합칩니다**

**Windows 파일 탐색기**

1. 다운로드한 `AN-Harness-Lesson06-Specification.zip`을 찾습니다.
2. 마우스 오른쪽 버튼으로 클릭하고 **압축 풀기**를 선택합니다.
3. 압축을 풀 위치를 **`C:\AI-Native`**로 지정합니다. ZIP 안의 `harness-engineering` 폴더가 앞 교시에서 사용한 같은 이름의 폴더에 합쳐지게 합니다.
4. **`C:\AI-Native\harness-engineering\lesson06.ps1`**이 `compose.yaml`과 나란히 있는지 확인합니다.

압축 프로그램이 ZIP 이름의 폴더를 한 겹 더 만들었다면, 그 안의 `harness-engineering` 폴더 **안에 있는 파일과 하위 폴더**를 `C:\AI-Native\harness-engineering`로 복사합니다. `harness-engineering\harness-engineering`처럼 폴더가 두 번 겹치지 않게 합니다.

같은 6교시 자료를 다시 받았다면 ZIP에 포함된 수업 자료만 교체합니다. 개인 기록 `records`, 현재 작업 `workspace`, 인증 정보 `.env`는 이 ZIP에 포함되지 않습니다.

**1-2. PowerShell에서 위치와 파일을 확인합니다**

**PowerShell — 목적: 수업 폴더로 이동하고 필요한 파일이 있는지 확인**

```powershell
Set-Location 'C:\AI-Native\harness-engineering'
Get-Location
Test-Path .\compose.yaml
Test-Path .\lesson06.ps1
Test-Path .\course-tools\lesson06_specification.py
Test-Path .\starter\lesson06\entry\CONTEXT_INDEX.md
Test-Path .\starter\lesson06\reference\SALES_SPEC.md
Test-Path .\templates\spec_review.md
Test-Path .\inputs\lesson03\sales.csv
Test-Path .\inputs\sales\sales_micro.csv
Test-Path .\inputs\sales\errors\quantity_zero.csv
```

**확인:** 작업 위치가 `C:\AI-Native\harness-engineering`이고 모든 `Test-Path`가 `True`이면 계속합니다. 수업 자료가 `False`이면 압축 해제 위치를 확인합니다. CSV가 `False`이면 3교시 패키지의 공통 데이터에서 해당 파일을 준비합니다. 빈 CSV를 만들어 대신 사용하지 않습니다.

**1-3. 준비 명령이 할 일을 확인합니다**

`prepare`는 첫 요청 전에 필요한 파일을 준비하고 **진입점**, 즉 이번 교시를 다시 시작할 수 있는 상태를 보관합니다.

| 순서 | 준비 명령이 하는 일 | 확인·보관 위치 |
|---:|---|---|
| 1 | 3교시 Baseline을 검사하고 Hermes를 멈춘다 | BASELINE_INTEGRITY_PASS |
| 2 | 현재 workspace 전체를 보관한다 | records/lesson06/prior-workspace |
| 3 | 네 Context 문서, 명세 초안, 검토 요청을 준비한다 | workspace |
| 4 | 시작 파일·관련 설정·Memory·Skill 및 공통 입력의 해시를 기록한다 | records/lesson06/checkpoint |
| 5 | 빈 관찰 기록을 준비하고 Hermes를 다시 시작한다 | records/lesson06/spec_review.md |

| 준비 후 확인할 내용 | 위치 |
|---|---|
| 이전 작업 폴더 사본 | `records\lesson06\prior-workspace` |
| 보관된 원래 작업 폴더 | `records\lesson06\workspace-before-prepare` |
| Agent가 읽을 문서 | `workspace\CONTEXT_INDEX.md`, `workspace\context`, `workspace\SPEC.md` |
| 두 번 사용할 같은 요청 | `workspace\review_request.txt` |
| 내가 작성할 기록 | `records\lesson06\spec_review.md` |
| 복원에 사용할 사본 | `records\lesson06\checkpoint` |

앞 교시의 개인 작업은 보관하고 공통 Context를 준비합니다. **새 workspace에서 앞 교시 파일이 보이지 않아도 보관 폴더에 남아 있습니다.** `checkpoint`는 복원과 검사에 사용하므로 직접 편집하지 않습니다. 5교시에서 정리한 보고서 경로 `/workspace/outputs/`와 업무 규칙을 이어갑니다. 실행 환경 문서에는 이번 준비에서 확인한 환경 정보를 기록합니다. 모델과 관련 설정이 수업 조건과 다르면 자동으로 바꾸지 않고 중단합니다.

**1-4. 준비를 실행합니다**

메모장에서 열어 둔 작업 파일을 저장하고 닫습니다. Hermes가 요청을 처리 중이라면 먼저 멈춥니다.

**PowerShell — 목적: 이전 작업 보관과 6교시 시작 파일 준비**

```powershell
Unblock-File -LiteralPath .\lesson03.ps1
Unblock-File -LiteralPath .\lesson06.ps1
.\lesson06.ps1 prepare
```

`Unblock-File`은 내려받은 스크립트의 실행 차단을 해제합니다. 준비 명령 안에서 3교시의 `verify`도 사용하므로 두 스크립트를 해제합니다. 이 `verify`는 보관 기록을 검사하며 판매 분석과 Baseline 동결을 다시 실행하지 않습니다. 준비 도중 `Container ... Creating`이 보이는 것은 보조 도구용 임시 컨테이너를 만드는 과정입니다.

**실제 실행에서 확인한 핵심 메시지:**

```text
BASELINE_INTEGRITY_PASS
PREPARE_PASS: prior work preserved; Lesson06 entry checkpoint saved.
BASELINE_INTEGRITY_PASS
Next: check healthy, open a new Hermes Chat, then .\lesson06.ps1 check start
```

`Lesson06 records already exist`가 나오면 이미 준비된 상태입니다. 오류를 보관하고 7)의 안내에 따라 현재 상태를 확인합니다. 기록 폴더를 삭제하고 준비를 반복하지 않습니다.

**1-5. 컨테이너가 준비됐는지 확인합니다**

**PowerShell — 목적: 준비한 파일을 사용하는 Hermes가 실행됐는지 확인**

```powershell
docker compose ps
```

`PREPARE_PASS`는 파일 준비가 끝났다는 뜻입니다. 대시보드를 사용할 준비도 끝났는지는 컨테이너 상태로 확인합니다. `STATUS`에 `healthy`가 보이면 새 Chat을 엽니다. `health: starting`이면 잠시 후 같은 명령을 다시 실행합니다. 계속 준비되지 않거나 종료되면 다음 명령으로 원인을 확인하고 로그를 보관합니다.

```powershell
docker compose logs --tail 80 hermes
```

**1-6. 초안 검토용 새 Chat을 엽니다**

브라우저에서 `http://127.0.0.1:9119`에 접속합니다. **CHAT → New chat**으로 새 대화를 열고, Chat 입력창에서 아래 명령을 **한 줄씩** 실행합니다.

```text
/title specification-lesson06-draft
/model z-ai/glm-5.3-flash
/reasoning low
/status
```

모델 변경 응답과 `reasoning: low`, 하단 상태를 확인합니다. `/model`만 입력하여 선택 화면에서 같은 모델을 골라도 됩니다. 시작 화면의 작업 위치는 `/workspace`인지 확인합니다. 이 `low`는 수업에서 통제하는 Hermes 설정값입니다.

**1-7. 첫 요청 전에 시작 상태를 검사합니다**

**PowerShell**에서 실행합니다. 아직 명세 검토 요청은 보내지 않습니다.

```powershell
.\lesson06.ps1 check start
```

**시작 검사 출력 예시:**

```text
{
  "stage": "start",
  "workspace_matches": true,
  "workspace_differences": [],
  "settings_match": true,
  "settings_differences": [],
  "memory_and_skills_unchanged": true,
  "original_csv_unchanged": true,
  "common_inputs_unchanged": true,
  "spec_sha256": "6e05d4387cdf8f8283f1a81e802e6587cf90d4be95a52a464f4d378b887f9397",
  "request_sha256": "04da5ae70666badcc77f7b591574fb31e61e75e5fe83e1ef700a377cb0e79556",
  "scope": "Checks files and saved settings; assess reasoning and actual tool use from the exported Chat."
}
RECORDED: records/lesson06/check-start-20260911T035057489884Z-44577c.json
START_READY
```

위 JSON에서 다음 항목을 확인합니다.

| JSON 항목 | 시작 시 확인할 값 | 의미 |
|---|---|---|
| workspace_matches | true | 준비한 시작 파일과 현재 파일이 같다 |
| settings_match | true | 저장된 실행 조건이 같다 |
| memory_and_skills_unchanged | true | 기록한 Memory·Skill 파일 상태가 같다 |
| original_csv_unchanged / common_inputs_unchanged | true / true | 공통 원본이 유지됐다 |
| workspace_differences / settings_differences | [] / [] | 발견된 차이가 없다 |

`request_sha256`은 `workspace\review_request.txt`, `spec_sha256`은 `workspace\SPEC.md`의 내용으로 계산한 해시입니다. 두 항목은 바로 위 JSON 안에 있으며 콜론 오른쪽의 긴 문자열이 값입니다. `RECORDED` 파일명에 붙은 시각·식별자와 구분합니다. 이후 **요청 해시는 같고 명세 해시는 달라지는지** 확인합니다. 검사 결과는 `records/lesson06/check-start-…json`에 자동 저장됩니다.

**1-8. 기록을 시작합니다**

PowerShell에서 아래 명령으로 기록 파일을 엽니다. 준비 명령은 양식을 만들지만, 화면에서 확인한 결과와 자신의 판단은 직접 적어야 합니다.

```powershell
notepad .\records\lesson06\spec_review.md
```

`1. 실행 조건`을 채웁니다. 현재 모델·추론 설정, 준비와 시작 검사 결과, 초안 Chat 이름을 적습니다. 세션 JSON은 아직 내보내지 않았으므로 ‘내보내기 전’으로 둡니다. 아래는 이 시점의 작성 예시입니다.

````markdown
## 1. 실행 조건

- 작성자: Nuguna
- 실습 날짜: 2026-09-11
- 모델 / Hermes 추론 설정: `z-ai/glm-5.3-flash` / `low`
- 사용 화면: Windows PowerShell 7.6.5, Hermes 웹 대시보드, 메모장
- 실행 환경 / Agent 작업 폴더: Docker 컨테이너 / `/workspace`
- 정상 Context를 준비한 결과: `PREPARE_PASS`를 확인했고 컨테이너는 `healthy`였다. 준비 전후 모두 `BASELINE_INTEGRITY_PASS`를 확인했다.
- 첫 요청 전 검사: `START_READY`. 작업 파일·설정의 차이가 없었으며 Memory·Skill·공통 입력이 유지됐다.
- 초안 세션 이름: `specification-lesson06-draft`
- 요청 SHA-256: `04da5ae70666badcc77f7b591574fb31e61e75e5fe83e1ef700a377cb0e79556`
- 초안 SPEC SHA-256: `6e05d4387cdf8f8283f1a81e802e6587cf90d4be95a52a464f4d378b887f9397`
- 초안 세션 JSON: 아직 내보내기 전. 단계 3에서 추가한다.
- 구체화 후 세션: 단계 5에서 추가한다.
- 검토 요청 전송: 아직 전송하지 않았다.
````

`5. 실제 관찰과 자동 검사`에는 시작 검사 결과를, `6. 증거 파일과 다음 교시`에는 `check-start-20260911T035057489884Z-44577c.json`처럼 본인의 `RECORDED` 파일명을 추가합니다. 기준값과 응답 비교는 다음 단계에서 채웁니다. **Ctrl+S로 저장한 뒤 메모장을 닫습니다.**

전체 모양은 `examples/spec_review_stages/01_start.md`에 있습니다.

### 단계 2. 데이터의 기준값을 확인하고 기록한다

명세에 숫자를 적기 전에 그 숫자의 근거부터 확인합니다. 공통 데이터 세트 안의 10행 파일로 계산을 직접 따라가고, 수량 0이 있는 오류 파일에서는 어느 위치가 문제인지 확인합니다.

**2-1. 제공 데이터의 기준값을 확인합니다**

**PowerShell**에서 실행합니다.

```powershell
.\lesson06.ps1 facts
```

이 명령은 시작 상태를 다시 확인한 뒤, 제공된 보조 도구로 CSV를 읽어 계산 근거를 보여 줍니다. Agent가 만든 분석 프로그램을 실행하는 명령은 아닙니다. `facts-…json` 파일이 기록되고 마지막에 `FACTS_READY`가 나옵니다.

**facts 출력에서 기록에 사용할 항목 — 실제 결과 일부 발췌:** 실제 JSON에는 입력 해시와 전체 행별 계산도 들어 있습니다. 아래 `micro_rows`는 10건 중 한 건만 보여 줍니다.

```json
{
  "inputs": {
    "inputs/sales/sales_micro.csv": {
      "rows": 10,
      "units": 19,
      "revenue": 56000,
      "categories": {
        "Accessory": 16000,
        "Monitor": 18000,
        "Office": 5000,
        "Storage": 17000
      },
      "top3": [
        [
          "USB Drive 128GB",
          16000
        ],
        [
          "27-inch Monitor",
          13000
        ],
        [
          "Laptop Stand",
          12000
        ]
      ]
    },
    "inputs/lesson03/sales.csv": {
      "rows": 200,
      "units": 708,
      "revenue": 56715000
    }
  },
  "micro_rows": [
    {
      "record": 4,
      "order_id": "M-0002",
      "quantity": 3,
      "unit_price": 3000,
      "revenue": 9000
    }
  ],
  "invalid_example": [
    {
      "record": 5,
      "field": "quantity",
      "value": "0"
    }
  ]
}
```

```text
RECORDED: records/lesson06/facts-20260911T035420469556Z-d3db68.json
FACTS_READY: inspect micro_rows and record your independent check.
```

| 기록할 내용 | JSON에서 찾을 곳 |
|---|---|
| 행 수·총수량·총매출 | `inputs` 안의 해당 파일 경로 → `rows`, `units`, `revenue` |
| 카테고리 매출·상위 제품 | 같은 파일 묶음 안의 `categories`, `top3` |
| 직접 계산할 행 | `micro_rows`의 `order_id`, `quantity`, `unit_price`, `revenue` |
| 수량 0의 위치와 값 | `invalid_example`의 `record`, `field`, `value` |

이 값을 아래 표와 대조합니다. `record`는 헤더를 1로 센 CSV 레코드 번호이며 주문 ID가 아닙니다.

| 데이터 | 행 수 | 총수량 | 총매출 |
|---|---:|---:|---:|
| /inputs/sales/sales_micro.csv | 10 | 19 | 56,000원 |
| /inputs/lesson03/sales.csv | 200 | 708 | 56,715,000원 |

직접 확인하기 쉬운 10행 파일을 메모장으로 엽니다.

```powershell
notepad .\inputs\sales\sales_micro.csv
```

파일을 읽으면서 다음 표와 대조합니다. 수량에 실제 단가를 곱하며 할인을 다시 적용하지 않습니다. 파일 내용은 그대로 두고 메모장을 닫습니다.

| 주문 ID | 수량 × 단가 | 행 매출 |
|---|---:|---:|
| M-0009 | 1 × 1,000 | 1,000 |
| M-0004 | 2 × 2,000 | 4,000 |
| M-0002 | 3 × 3,000 | 9,000 |
| M-0010 | 1 × 4,000 | 4,000 |
| M-0001 | 2 × 5,000 | 10,000 |
| M-0007 | 3 × 1,000 | 3,000 |
| M-0005 | 1 × 2,000 | 2,000 |
| M-0003 | 2 × 3,000 | 6,000 |
| M-0006 | 3 × 4,000 | 12,000 |
| M-0008 | 1 × 5,000 | 5,000 |
| 합계 | 총수량 19 | 56,000원 |

**작은 확인 과제:** 누군가 기대값을 55,000원이라고 적었다면 채택할 수 있을까요? 위 열 건을 더해 확인하고, 답을 곧 작성할 기록에 남깁니다. 명세의 숫자도 검토 대상입니다.

오류 파일은 `quantity_zero.csv`입니다. **헤더**는 열 이름을 적은 첫 레코드이며, **CSV 레코드**는 CSV 파서가 읽는 한 묶음의 값입니다. `facts`의 `invalid_example`은 **CSV 레코드 5, quantity(수량), 값 0**을 보여 줍니다. 헤더가 레코드 1이므로 네 번째 주문의 위치가 5입니다. 이번에는 잘못된 값을 발견하고, 이후 실행에서 어떤 행동을 해야 할지 정합니다.

**2-2. 확인한 값을 관찰 기록에 적는다**

**PowerShell → 메모장 — 목적: 방금 확인한 계산 근거를 기록**

```powershell
notepad .\records\lesson06\spec_review.md
```

단계 1에서 실행 조건을 적은 같은 파일입니다. **1절은 유지하고, 2절의 제목부터 다음 3절 제목 직전까지를 작성**합니다. 아래 예시의 값과 `facts-…json` 파일명을 본인의 결과와 대조합니다. 직접 확인한 계산 근거도 남깁니다.

````markdown
## 2. 데이터로 확인한 기준값

- facts 기록 파일명: `facts-20260911T035420469556Z-d3db68.json`
- 기준값 확인 결과: `FACTS_READY`

| 입력 | 행 수 | 총수량 | 총매출 |
|---|---:|---:|---:|
| inputs/sales/sales_micro.csv | 10 | 19 | 56,000원 |
| inputs/lesson03/sales.csv | 200 | 708 | 56,715,000원 |

10행 파일의 카테고리별 매출은 다음과 같다.

| 카테고리 | 매출 |
|---|---:|
| Accessory | 16,000원 |
| Monitor | 18,000원 |
| Office | 5,000원 |
| Storage | 17,000원 |
| 합계 | 56,000원 |

상위 제품은 `USB Drive 128GB` 16,000원, `27-inch Monitor` 13,000원, `Laptop Stand` 12,000원 순이다.

행별 계산 근거 중 `M-0002`는 수량 3 × 실제 적용 단가 3,000원 = 9,000원이다. 단가에는 할인이 이미 반영되어 있으므로 할인을 다시 적용하지 않는다.

55,000원을 기대값으로 채택할 수 없는 이유는 열 건의 행 매출 합계가 다음과 같이 56,000원이기 때문이다.

```text
1,000 + 4,000 + 9,000 + 4,000 + 10,000
+ 3,000 + 2,000 + 6,000 + 12,000 + 5,000 = 56,000원
```

`quantity_zero.csv`에서는 CSV 레코드 5의 `quantity`가 `0`이다. 헤더를 1번으로 세므로 네 번째 주문의 위치가 레코드 5다.

이 결과는 제공된 보조 도구가 계산한 기준값이다. Agent가 작성한 분석 프로그램을 실행하거나 그 프로그램의 정확성을 검증한 결과는 아니다.
````

`6. 증거 파일과 다음 교시`에는 facts 실행에서 생긴 시작 재검사와 facts 파일을 추가합니다. 실제 예에서는 `check-start-20260911T035420428996Z-fd4558.json`, `facts-20260911T035420469556Z-d3db68.json`이 생겼습니다.

**지금까지 완성한 것:** 1절 실행 조건과 2절 기준값입니다. 3절 비교와 4절 인수조건은 아직 작성 전입니다. Ctrl+S로 저장하고 닫습니다. 누적 예시는 `examples/spec_review_stages/02_facts.md`입니다.

### 단계 3. 명세 초안을 검토하고 근거를 기록한다

5교시에서 문서의 근거를 찾았던 것처럼, 이번에는 ‘완료를 판단할 근거가 충분한가’를 봅니다. 초안의 부족한 부분을 찾아 두어야 명세를 구체화한 뒤 무엇이 달라졌는지 비교할 수 있습니다.

**3-1. 명세 초안을 읽습니다**

**PowerShell → 메모장 — 목적: 검토할 작업 문서 읽기**

```powershell
notepad .\workspace\SPEC.md
```

초안에는 “정확하게 분석”, “보기 좋게”, “적절히 처리”, “일관된 결과”라는 네 요구가 있습니다. 메모장에서 읽은 뒤 닫습니다. 계산식이나 저장 경로는 앞선 Context에서 일부 찾을 수 있지만, 파일 형식과 오류 종료코드까지 정해져 있는지 생각해 봅니다.

**3-2. 저장된 요청을 복사해 초안 Chat에 보냅니다**

**PowerShell — 작업 위치: `C:\AI-Native\harness-engineering`**

```powershell
Get-Content -Raw -Encoding utf8 .\workspace\review_request.txt | Set-Clipboard
```

**Hermes Chat:** `specification-lesson06-draft` 대화에 붙여넣고 한 번 전송합니다. 복사되는 전체 요청은 다음과 같습니다.

```text
/workspace/CONTEXT_INDEX.md를 먼저 읽고, 그 순서대로 네 Context 문서와 /workspace/SPEC.md를 읽으세요.
추가로 읽을 입력은 /inputs/sales/sales_micro.csv와 /inputs/sales/errors/quantity_zero.csv 두 개뿐입니다.
프로그램 구현, 명령 실행, 파일 생성·수정·삭제, 설정·Memory·Skill 변경, 외부 검색은 하지 마세요.
다음 여섯 항목을 표로 검토하세요: 입력 규칙, 매출 계산, 출력 파일과 형식, 오류 처리와 기존 출력 보존, 정렬과 반복 실행, 원본 보호와 근거 없는 해석 방지.
각 항목에 근거 파일과 문장, 자동 검증 가능/수동 확인 필요/판정 불가, 확인할 결과를 적으세요. 한 항목에 여러 판정이 필요하면 나누어 적으세요.
문서에 없는 요구는 임의로 정하지 말고 결정할 질문으로 적으세요. 충돌이 있으면 두 지시를 함께 적고 보류하세요.
quantity가 0인 입력은 어떤 결과를 내야 하는지도 근거와 함께 설명하세요.
아직 프로그램을 실행하지 않았으므로 프로그램이 통과했다거나 보고서를 생성했다고 쓰지 마세요.
추가 질문이 필요하면 표에 기록하고 검토를 마치세요. 이번에는 사람이 비교 후 결정합니다.
실제로 읽은 파일과 사용한 도구를 마지막에 알려 주세요.
```

요청을 보낸 뒤 응답이 끝날 때까지 기다립니다. 표의 세 가지 분류는 다음 뜻입니다.

| 분류 | 쉽게 이해하기 | 예시 |
|---|---|---|
| 자동 검증 가능 | 프로그램으로 값·파일·코드를 비교할 수 있다 | 총매출, CSV 열 이름, 종료코드 |
| 수동 확인 필요 | 사람이 내용을 읽어 판단해야 한다 | 보고서가 근거 없이 원인을 단정하는지 |
| 판정 불가 | 무엇을 기준으로 볼지 아직 정해지지 않았다 | ‘보기 좋게’만 있고 필요한 내용이 없는 경우 |

여기서 ‘자동 검증 가능’은 **나중에 프로그램으로 검사할 수 있다는 분류**입니다. 지금 프로그램을 실행해 합격했다는 뜻이 아닙니다. **초안에서 빠진 조건을 질문으로 찾아내는 것도 정상 결과**입니다. 이미 Context에 있는 계산식·저장 경로까지 없다고 판단하면, 해당 근거와 함께 기록합니다.

추가 선택 화면이 나온다면 “현재 문서만 검토하고, 미정 항목은 질문으로 남겨 주세요. 이번에는 구현하지 않습니다.”라는 취지로 답하고 실제 답변을 기록합니다. 새로운 요구를 즉석에서 추가했다면 두 검토의 요청 조건이 달라졌다는 사실도 남깁니다.

**3-3. 응답과 파일 상태를 함께 확인합니다**

Hermes에서 실제로 읽은 파일, 사용한 도구, 여섯 항목의 근거를 확인합니다. 도구 호출 횟수나 문장 모양은 달라도 됩니다. 파일 변경이나 명령 실행이 있었는지는 별도로 살펴봅니다.

**PowerShell — 작업 위치: `C:\AI-Native\harness-engineering`**

```powershell
.\lesson06.ps1 check draft
```

**초안 검토 후 검사 출력 예시:**

```text
{
  "stage": "draft",
  "workspace_matches": true,
  "workspace_differences": [],
  "settings_match": true,
  "settings_differences": [],
  "memory_and_skills_unchanged": true,
  "original_csv_unchanged": true,
  "common_inputs_unchanged": true,
  "spec_sha256": "6e05d4387cdf8f8283f1a81e802e6587cf90d4be95a52a464f4d378b887f9397",
  "request_sha256": "04da5ae70666badcc77f7b591574fb31e61e75e5fe83e1ef700a377cb0e79556",
  "scope": "Checks files and saved settings; assess reasoning and actual tool use from the exported Chat."
}
RECORDED: records/lesson06/check-draft-20260911T040036018876Z-ce9b61.json
CHECK_PASS: draft
```

`CHECK_PASS: draft`는 초안과 관련 파일·설정이 그대로라는 뜻입니다. “Agent가 모든 누락을 정확히 발견했다”는 점수는 아닙니다.

**3-4. 첫 응답과 세션을 저장합니다**

Hermes의 최종 응답을 복사한 다음 **PowerShell**에서 메모장을 엽니다.

```powershell
notepad .\records\lesson06\draft_response.md
```

응답을 붙여넣고 저장합니다. 이어서 이 대화를 JSON으로 내보냅니다. 5교시와 같이 내보낸 `session-…json`을 파일 탐색기로 `C:\AI-Native\harness-engineering\records\lesson06`에 복사합니다. 원래 내보낸 파일명을 유지하면 두 실행을 구분하기 쉽습니다.

```powershell
Get-Item .\records\lesson06\draft_response.md
Get-ChildItem .\records\lesson06 -Filter 'session*.json'
```

**확인:** 응답 파일과 첫 세션 JSON이 보이면 저장이 끝났습니다. 세션에는 도구 실행도 들어 있으므로 최종 답변 파일과 함께 보관합니다.

**3-5. 초안의 검토 내용을 기록한다**

**PowerShell → 메모장 — 목적: 첫 응답의 근거를 비교 표에 남기기**

```powershell
notepad .\records\lesson06\spec_review.md
```

`1. 실행 조건`에 초안 세션 JSON의 실제 파일명을 추가합니다. 실제 실행에서는 `session-20260911_034916_fb10c3.json`을 보관했고 응답은 `draft_response.md`에 저장했습니다.

이어서 **3절 제목부터 4절 제목 직전까지** 아래 형식으로 작성합니다. **초안 응답 열만 채웁니다.** 나머지 두 열은 두 번째 검토를 마친 뒤 채울 자리입니다.

````markdown
## 3. 명세 검토 전후

초안 세션의 실제 응답을 요약했다. 두 번째 검토와 전후 판단은 아직 작성 전이다.

| 항목 | 초안 응답과 근거 | 구체화 후 응답과 근거 | 나의 판단 |
|---|---|---|---|
| 입력 규칙 | 업무 Context와 CSV에서 열과 의미를 찾았다. 다만 sales.csv 수정 금지와 시험용 CSV 읽기 요청을 충돌로 판단했다. | 작성 전 | 두 번째 검토 후 비교 |
| 계산 | 업무 Context를 근거로 수량 × 실제 적용 단가를 제시하고 할인 재적용 금지를 설명했다. | 작성 전 | 두 번째 검토 후 비교 |
| 출력 | Context에서 /workspace/outputs/ 경로를 찾았다. 초안의 ‘보기 좋게’만으로 파일명과 형식을 확정할 수 없다고 지적했다. | 작성 전 | 두 번째 검토 후 비교 |
| 오류와 보존 | 수량 0의 허용 여부와 처리 방식, 기존 결과 보존 정책이 정해지지 않았다고 보고했다. | 작성 전 | 두 번째 검토 후 비교 |
| 정렬과 반복 | 구체적인 정렬 기준이 없다고 지적했다. ‘일관된 결과’를 파일 해시 비교로 확인할 수 있다고 제안했다. | 작성 전 | 두 번째 검토 후 비교 |
| 원본과 해석 | 원본 보호와 근거 없는 이익 계산·원인 단정 금지를 찾았다. 일부 자동 확인 가능한 항목도 수동 확인으로 분류했다. | 작성 전 | 두 번째 검토 후 비교 |

Agent가 원본 보호와 시험용 CSV 읽기를 충돌로 판단했다는 것은 응답의 관찰이다. 그 판단이 옳은지는 문서와 대조하여 따로 적는다.
````

`5. 실제 관찰과 자동 검사`에는 아래 내용을 본인의 도구 기록과 검사 출력에 맞게 적습니다.

```markdown
- 초안 도구: read_file 8회. 인덱스, 네 Context 문서, SPEC, CSV 두 개를 읽었다.
- 다른 도구 호출이나 명령 실행, 파일 변경은 세션에 없었다.
- 질문은 최종 응답에 적었고 Clarify 호출은 없었다.
- 초안 검사: CHECK_PASS: draft. 작업 파일·설정의 차이가 없고 Memory·Skill·공통 입력이 유지됐다.
- 구체화 후 응답과 종료 시 검사는 아직 확인 전이다.
```

`6. 증거 파일과 다음 교시`에 초안 응답·세션·`check-draft` 파일명을 추가합니다. 실제 검사 파일은 `check-draft-20260911T040036018876Z-ce9b61.json`입니다.

**지금까지 완성한 것:** 실행 조건·기준값·초안 응답과 사용 도구입니다. 두 번째 응답의 내용을 미리 채우지 않습니다. Ctrl+S로 저장하고 닫습니다. 누적 예시는 `examples/spec_review_stages/03_draft.md`입니다.

### 단계 4. 명세를 구체화하고 인수조건을 작성한다

이제 ‘정확하게’, ‘적절히’라는 표현을 확인 가능한 약속으로 바꿉니다. 먼저 제공된 공통 명세를 읽고, 그 약속을 어떻게 검사할지 세 가지 인수조건으로 직접 적습니다. 이 단계에서 할 일은 **문서를 읽고 검사 기준을 작성하는 것**입니다.

**4-1. 구체화 명령이 바꾸는 파일을 확인합니다**

`specify`는 ‘명세를 구체화한다’는 뜻의 준비 명령입니다. 명세 전체를 메모장에서 다시 입력하는 대신, 공통 데이터에 맞춰 제공된 명세를 작업 폴더에 적용합니다.

**PowerShell — 목적: 모호한 초안을 구체적인 공통 명세로 교체**

```powershell
.\lesson06.ps1 specify
```

이 명령은 먼저 초안 상태를 다시 검사하여 `CHECK_PASS: draft`를 출력합니다. 이어서 **workspace/SPEC.md 하나를 공통 판매 명세로 바꿉니다.** Context와 요청 파일은 그대로입니다. 초안은 진입점 보관본에 남아 있습니다.

**실제 실행에서 확인한 메시지:**

```text
RECORDED: records/lesson06/check-draft-20260911T041643241957Z-c1adbf.json
CHECK_PASS: draft
SPEC_READY: SPEC.md replaced with the common sales contract. Open a NEW Chat and use the same request.
```

이 메시지는 프로그램 생성이 아니라 명세 교체가 끝났다는 뜻입니다. `specify`는 한 번 실행합니다.

**4-2. 바뀐 명세를 읽습니다**

```powershell
notepad .\workspace\SPEC.md
```

명세에서 **BOM**은 텍스트 파일 앞에 붙을 수 있는 인코딩 표식이고, **LF·CRLF**는 줄바꿈을 저장하는 방식입니다. **CSV 파서**는 쉼표·따옴표 규칙에 따라 열을 읽는 프로그램입니다. 저장 방식이 달라도 같은 주문 값으로 읽을 수 있어야 하므로 이 조건을 명세에 둡니다.

아래 표를 옆에 두고 1절부터 6절까지 차례로 읽습니다. 확인한 문장에 대응하는 질문을 스스로 답해 봅니다.

| 읽을 절 | 확인할 질문 | 이번 공통 명세의 답 |
|---|---|---|
| 1. 읽기 | 어떤 CSV를 받을까? | 필수 열 집합 일치, 열 순서 변경 허용, 누락·추가·중복 헤더 오류 |
| 2. 값 검사 | 읽힌 값은 모두 유효할까? | 실제 날짜·고유 주문 ID·제품 관계·양수 정수·허용 지역 검사 |
| 3. 계산과 출력 | 무엇을 계산하고 어떤 파일을 만들까? | 총매출·총수량·카테고리·상위 제품, summary.csv와 report.md |
| 4. 실패와 보존 | 잘못된 입력이면 어떻게 할까? | 첫 오류 보고, 코드 2, 기존 두 결과 보존 |
| 5. 관계 검사 | 다른 표현의 같은 입력은 어떨까? | 행·열 순서나 BOM·줄바꿈 차이에도 같은 논리 입력이면 출력 동일 |
| 6. 실행 인터페이스와 적용 시점 | 프로그램을 어떻게 실행할까? | python analyze_sales.py --input 입력경로 --output-dir 결과폴더 |

낯선 표기는 다음처럼 읽으면 됩니다.

| 명세의 표현 | 뜻과 예 |
|---|---|
| 입력·출력 인터페이스 | 프로그램 실행 시 입력 파일과 결과 폴더를 어떻게 알려 줄지 정한 형식 |
| `--input` | 분석할 CSV의 위치를 지정하는 옵션 |
| `--output-dir` | 결과 두 파일을 저장할 폴더를 지정하는 옵션 |
| BOM·줄바꿈 차이 | 같은 CSV 내용이 저장 방식 때문에 다르게 표현된 경우 |
| 같은 논리 입력 | 행·열의 배치가 달라도 주문과 값의 내용은 같은 입력 |

수량·단가는 우리가 사용하는 `0`~`9` 숫자로 적으며, 앞의 `+` 또는 `-` 기호는 있어도 됩니다. **숫자로 해석한 값은 1 이상**이어야 하므로 `+2`는 허용하지만 `-2`와 `0`은 오류입니다. 공백·소수점·천 단위 쉼표를 몰래 제거해 보정하지 않습니다. 제품마다 단가가 고정되어 있다고 가정하지 않습니다. 카테고리와 제품의 허용 표기는 명세의 표를 따릅니다.

`summary.csv`는 `section,name,value` 세 열을 사용합니다. **현재 읽은 10행 입력에서 기대할 내용**은 다음과 같습니다. 지금 이 출력 파일을 만들거나 복사하는 단계는 아닙니다.

```csv
section,name,value
total,revenue,56000
total,units,19
category,Accessory,16000
category,Monitor,18000
category,Office,5000
category,Storage,17000
product_top3,USB Drive 128GB,16000
product_top3,27-inch Monitor,13000
product_top3,Laptop Stand,12000
```

카테고리는 이름 오름차순, 상위 제품은 매출 내림차순입니다. 매출이 같으면 제품명 Unicode 오름차순으로 정합니다. Unicode는 문자에 번호를 부여한 표준이며, 여기서는 그 순서를 기준으로 제품명을 비교해 동률의 순위를 일정하게 정한다는 뜻입니다. 보고서는 총매출·카테고리 집계·상위 3개를 구분하되 설명 문장 자체를 한 가지로 고정하지 않습니다.

**4-3. 관찰 기록에 세 가지 인수조건을 작성합니다**

**PowerShell — 작업 위치: `C:\AI-Native\harness-engineering`**

```powershell
notepad .\records\lesson06\spec_review.md
```

단계 2와 3에서 일부 작성한 같은 기록 파일입니다. 이제 `4. 내가 작성한 인수조건`을 채웁니다. 아래 표의 각 행을 **준비된 조건 → 실행할 행동 → 확인할 결과 → 검증 방법**으로 풀어 씁니다.

**AC**는 Acceptance Criteria의 줄임말입니다. `AC-01`, `AC-02`, `AC-03`은 정상 입력, 오류와 보존, 반복 실행을 가리키는 조건 번호입니다. 다음 교시에서 계획과 검사를 이 번호에 연결하므로 그대로 사용합니다.

| 인수조건 | 준비된 조건 | 실행할 행동 | 반드시 확인할 결과 |
|---|---|---|---|
| AC-01 정상 입력 | 10행 micro와 빈 시험용 결과 폴더 | 분석 프로그램 실행 | 코드 0, 두 파일, 56,000원·19개, 명세의 열·순서 |
| AC-02 오류와 보존 | 정상 결과 두 파일과 실행 전 해시 | 같은 결과 폴더에 quantity_zero 입력으로 실행 | 코드 2, 레코드 5·quantity·오류 이유, 두 파일 해시 유지 |
| AC-03 반복 실행 | 같은 프로그램·환경·입력 | 같은 입력을 두 번 실행 | 두 번 모두 코드 0, 파일별 실행 전후 해시 동일 |

각 항목에 **검증 방법**도 적습니다. 예를 들어 AC-02는 “실행 전후 summary.csv와 report.md의 SHA-256을 각각 비교한다”라고 씁니다. `outputs/ac01`처럼 목적별 하위 폴더를 쓰면 정상·오류 시험의 결과를 구분할 수 있습니다.

**첫째, 정상 입력의 기준을 적습니다.**

- 준비: 10행 CSV와 비어 있는 시험용 결과 폴더가 있다.
- 행동: 이 CSV로 분석 프로그램을 실행한다.
- 결과: 코드 0, 결과 파일 두 개, 총매출 56,000원과 총수량 19개를 확인한다.
- 방법: CSV의 값·열·순서를 대조하고 보고서의 필수 내용을 읽는다.

이 내용을 AC-01의 네 칸에 적습니다. 숫자만 적기보다 어떤 입력을 사용했는지 함께 적어야 다른 사람이 같은 확인을 할 수 있습니다.

**둘째, 오류가 생겼을 때의 기준을 적습니다.**

AC-02에서는 **정상 결과가 먼저 있어야** ‘이전 결과가 보존됐는지’를 볼 수 있습니다. 정상 결과 두 파일의 해시를 기록한 다음 같은 결과 폴더에 오류 입력을 주는 순서로 적습니다. 결과에는 코드 2, 오류 레코드 5·quantity·이유, 기존 두 파일의 해시 유지를 포함합니다.

**셋째, 같은 실행을 반복했을 때의 기준을 적습니다.**

AC-03에서는 같은 프로그램·환경·입력으로 두 번 실행한다고 적습니다. 첫 실행 직후의 `summary.csv`와 둘째 실행 직후의 `summary.csv`를 비교하고, `report.md`도 같은 방식으로 비교합니다. CSV와 보고서를 서로 비교하는 것이 아닙니다.

**작성 후 확인:** 세 항목 모두 ‘어떤 상태에서, 무엇을 실행하고, 어떤 결과를 확인하는지’가 들어 있는지 읽어 봅니다. 이번에는 프로그램을 만들지 않았으므로 실제 출력이나 해시 대신 **나중에 확인할 기준**을 적습니다. Ctrl+S로 저장하고 닫으면 두 번째 명세 검토를 시작할 준비가 끝납니다.

**기록 예시 — 4절에 넣을 내용**

`4. 내가 작성한 인수조건` 제목부터 `5. 실제 관찰과 자동 검사` 직전까지 다음 형식으로 작성합니다. 아래 명령은 **앞으로 구현한 프로그램으로 시험할 행동을 기록한 것**입니다. 지금 PowerShell이나 Hermes에서 실행하지 않습니다.

````markdown
## 4. 내가 작성한 인수조건

다음 인수조건은 구체화된 공통 SPEC.md의 입력·출력·오류·반복 조건에 대응한다. 10행 입력의 기대값은 facts 결과를 근거로 사용한다. 아래 실행 행동과 기대값은 앞으로 프로그램을 검사할 기준이며 실제 실행 결과가 아니다.

### AC-01 정상 입력

- 준비된 조건: `sales_micro.csv`와 비어 있는 시험용 결과 폴더 `/workspace/outputs/ac01`이 있다.
- 실행할 행동: `/workspace`에서 `python analyze_sales.py --input /inputs/sales/sales_micro.csv --output-dir /workspace/outputs/ac01`을 실행한다.
- 확인할 결과: 종료코드 0이며 `summary.csv`와 `report.md`가 생성된다. 총매출은 56,000원, 총수량은 19개다. CSV는 `section,name,value` 열을 사용하고 명세의 행 순서를 따른다. 보고서에는 총매출·카테고리 집계·상위 3개 제품이 구분되어 있다.
- 검증 방법: 종료코드와 CSV의 열·값·순서를 확인한다. 보고서의 필수 내용과 설명은 문서를 열어 검토한다.

### AC-02 오류와 기존 출력 보존

- 준비된 조건: 정상 입력으로 생성한 `summary.csv`와 `report.md`가 `/workspace/outputs/ac02`에 있다. 두 파일의 SHA-256을 각각 기록했다.
- 실행할 행동: 같은 결과 폴더를 지정하여 `/inputs/sales/errors/quantity_zero.csv`로 분석 프로그램을 실행한다.
- 확인할 결과: 종료코드 2이며 stderr에 CSV 레코드 5, 필드 quantity, 규칙 위반 이유 또는 오류 코드가 나온다. 기존 두 결과 파일의 바이트는 유지된다.
- 검증 방법: 종료코드와 stderr를 확인하고, 각 결과 파일의 실행 전후 SHA-256을 비교한다. 오류 메시지의 표현 자체가 한 문장으로 고정될 필요는 없다.

### AC-03 반복 실행

- 준비된 조건: 같은 분석 프로그램·실행 환경·`sales_micro.csv`를 사용한다.
- 실행할 행동: `/workspace/outputs/ac03`을 결과 폴더로 지정하여 두 번 실행한다. 첫 실행 직후와 두 번째 실행 직후에 두 결과 파일의 SHA-256을 각각 기록한다.
- 확인할 결과: 두 실행 모두 종료코드 0이다. 첫 실행의 summary.csv와 두 번째 실행의 summary.csv 해시가 같고, report.md도 실행 간 해시가 같다.
- 검증 방법: 같은 이름의 파일끼리 해시를 비교한다. 서로 다른 프로그램이 작성한 보고서 문장까지 같아야 한다는 조건은 아니다.
````

`5. 실제 관찰과 자동 검사`에 `SPEC_READY`를, `6. 증거 파일과 다음 교시`에 specify가 생성한 검사 파일명을 추가합니다. 실제 예는 `check-draft-20260911T041643241957Z-c1adbf.json`입니다.

**지금까지 완성한 것:** 4절의 세 인수조건까지입니다. 3절의 구체화 후 응답과 나의 판단은 여전히 작성 전입니다. 명세를 읽고 기준을 작성한 것과 Agent의 두 번째 응답을 관찰한 것을 구분합니다. 누적 예시는 `examples/spec_review_stages/04_acceptance.md`입니다.

### 단계 5. 같은 요청으로 다시 검토하고 차이를 기록한다

지금은 Context와 데이터가 같고 `SPEC.md`만 달라진 상태입니다. 같은 요청으로 다시 검토하여, Agent가 사람의 결정을 기다려야 했던 항목 중 무엇을 이제 문서에서 확인할 수 있는지 살펴봅니다.

**5-1. 두 번째 새 Chat을 엽니다**

**웹 대시보드 → CHAT → New chat**에서 새 대화를 만들고 한 줄씩 실행합니다.

```text
/title specification-lesson06-specified
/model z-ai/glm-5.3-flash
/reasoning low
/status
```

모델과 추론 설정이 첫 검토와 같은지 확인합니다. 초안 답변을 새 대화에 붙여넣지는 않습니다. 이번에는 바뀐 명세 자체로 무엇을 판단하는지 봅니다.

**5-2. 지정한 명세만 바뀌었는지 확인합니다**

**PowerShell — 작업 위치: `C:\AI-Native\harness-engineering`**

```powershell
.\lesson06.ps1 check specified
```

**구체화 후 검사 출력 예시:**

```text
{
  "stage": "specified",
  "workspace_matches": true,
  "workspace_differences": [],
  "settings_match": true,
  "settings_differences": [],
  "memory_and_skills_unchanged": true,
  "original_csv_unchanged": true,
  "common_inputs_unchanged": true,
  "spec_sha256": "80813a38ca366a3a8e1e454e039a7d677cd5aebdfa1aa5edcdb836a557bc3475",
  "request_sha256": "04da5ae70666badcc77f7b591574fb31e61e75e5fe83e1ef700a377cb0e79556",
  "scope": "Checks files and saved settings; assess reasoning and actual tool use from the exported Chat."
}
RECORDED: records/lesson06/check-specified-20260911T042849030724Z-a64d44.json
CHECK_PASS: specified
```

`CHECK_PASS: specified`가 나오고 차이 목록이 비어 있으면 진행합니다. 여기서 `workspace_matches: true`는 **구체화된 명세가 적용되어야 하는 현재 단계의 예상 상태**와 같다는 뜻입니다. 첫 초안과 모든 파일이 같다는 뜻은 아닙니다.

**5-3. 같은 요청을 보내고 응답을 읽습니다**

```powershell
Get-Content -Raw -Encoding utf8 .\workspace\review_request.txt | Set-Clipboard
```

**Hermes Chat**의 `specification-lesson06-specified` 대화에 붙여넣고 한 번 보냅니다. 표에 나오는 근거를 `SPEC.md`와 대조합니다.

| 살펴볼 점 | 판단 방법 |
|---|---|
| 새로 분명해진 항목 | 출력 파일·열, 오류 코드·보존, 정렬·반복 기준을 실제 근거로 설명하는가 |
| 이미 Context에서 알 수 있던 항목 | 계산식, 저장 경로, 원본 보호를 명세 변경의 새 성과로 과장하지 않는가 |
| 수량 0의 처리 | 행을 건너뛰지 않고 입력 오류로 보고하는가 |
| 남은 질문 | 명세에 없는 필수 요구인지, 구현 방법의 선택인지 구분하는가 |
| 실행을 했다는 주장 | 실제 도구 기록과 일치하는가 |

모델이 초안에서도 규칙을 많이 제안할 수 있습니다. **제안과 합의된 요구는 다릅니다.** 첫 응답을 일부러 실패시키거나 두 번째 응답이 좋아질 때까지 반복하지 않습니다. 차이가 적었다면 그대로 기록합니다.

추가 선택 화면이 나오면 “현재 문서만 검토하고, 미정 항목은 질문으로 남겨 주세요. 이번에는 구현하지 않습니다.”라는 취지로 답하고 실제 답변을 기록합니다. 구현 시작을 막는 질문이 남았다면 근거와 질문을 기록해 다음 교시의 계획 전에 판단합니다. 제공된 명세는 공통 시작 기준으로 유지합니다.

**5-4. 두 번째 응답과 세션을 보관합니다**

최종 응답을 복사하고 **PowerShell**에서 메모장을 엽니다.

```powershell
notepad .\records\lesson06\specified_response.md
```

붙여넣고 저장합니다. 현재 대화를 JSON으로 내보내어 `records\lesson06`에 복사합니다. 첫 세션과 두 번째 세션의 파일명을 `spec_review.md`의 실행 조건에 각각 적습니다.

```powershell
Get-Item .\records\lesson06\draft_response.md, .\records\lesson06\specified_response.md
Get-ChildItem .\records\lesson06 -Filter 'session*.json'
```

응답 두 개와 서로 다른 세션 JSON 두 개를 확인합니다. 파일이 여러 개라면 본인이 사용한 두 대화를 기록에서 정확히 연결합니다.

**5-5. 두 응답을 비교하고 자신의 판단을 적습니다**

**PowerShell → 메모장 — 목적: 한 파일 안에서 전후 비교 완성**

```powershell
notepad .\records\lesson06\spec_review.md
```

1. `3. 명세 검토 전후`를 찾습니다. 단계 3에서 적은 **초안 응답과 근거**는 유지합니다.
2. `specified_response.md`에서 같은 항목의 답을 찾아 **구체화 후 응답과 근거**에 적습니다.
3. `workspace/SPEC.md`와 Context 문서를 대조하여 **나의 판단**을 적습니다. Agent가 질문했다고 해서 모두 미정 요구인 것은 아닙니다.

예를 들어 ‘오류와 보존’ 행은 초안에서 “수량 0을 어떻게 처리할지 정해지지 않았다”로 시작했습니다. 두 번째 응답에는 “레코드 5의 quantity=0은 오류이고 종료코드 2, 기존 두 결과 보존”이 나왔습니다. 나의 판단에는 “명세에서 오류 행동을 확인할 수 있게 됐지만 프로그램 시험은 아직 수행하지 않았다”라고 적습니다.

**실제 두 응답을 비교한 3절 전체 예시**입니다. 표 편집이 어렵다면 **3절 제목부터 4절 제목 직전까지** 이 형식으로 바꾼 뒤 자신의 응답에 맞게 수정합니다. 1·2·4·5·6절은 그대로 둡니다.

````markdown
## 3. 명세 검토 전후

두 세션의 실제 응답과 읽은 문서를 비교했다. 아래 내용은 명세 검토 결과이며, 분석 프로그램을 실행해 검증한 결과는 아니다.

| 항목 | 초안 응답과 근거 | 구체화 후 응답과 근거 | 나의 판단 |
|---|---|---|---|
| 입력 규칙 | 업무 Context와 CSV에서 열과 의미를 찾았다. 다만 sales.csv 수정 금지와 시험용 CSV 읽기 요청을 충돌로 판단했다. | SPEC 1·2·6절에서 헤더, 인코딩, 필드 수, 날짜, 양수 정수 등의 규칙을 제시했다. 부호와 음수 처리는 추가 질문으로 남겼다. | 입력 검사 기준이 구체화됐다. 원본 보호와 시험용 파일 읽기는 충돌하지 않는다. 선택적 부호와 값이 1 이상이라는 규칙으로 +5는 허용하고 -5는 거부할 수 있으므로 추가 결정이 필요하지 않다. |
| 계산 | 업무 Context를 근거로 수량 × 실제 적용 단가를 제시하고 할인 재적용 금지를 설명했다. | SPEC 3절을 근거로 총매출, 카테고리 매출, 제품 매출, 총수량 계산을 제시했다. | 계산식은 초안에서도 확인할 수 있었다. 구체화 후에는 무엇을 집계해야 하는지까지 명세의 근거로 설명했다. |
| 출력 | Context에서 /workspace/outputs/ 경로를 찾았다. 초안의 ‘보기 좋게’만으로 파일명과 형식을 확정할 수 없다고 지적했다. | summary.csv와 report.md, section/name/value 열, total·카테고리·제품 행의 순서를 제시했다. 결과 폴더와 보고서 내부 구조는 추가 결정 사항으로 보고했다. | 출력 형식이 명확해졌다. 현재는 문서 검토 요청이므로 출력 폴더 미지정을 충돌로 볼 필요는 없다. 이후 실행에서 /workspace/outputs/ 아래 폴더를 지정하면 된다. 필수 내용을 지키는 제목과 표 모양은 구현 시 선택할 수 있다. |
| 오류와 보존 | 수량 0의 허용 여부와 처리 방식, 기존 결과 보존 정책이 정해지지 않았다고 보고했다. | SPEC 2·4·6절을 근거로 레코드 5의 quantity 값 0을 입력 오류로 판단했다. 종료코드 2, 오류 위치·필드·이유 기록, 기존 두 결과 파일의 바이트 보존을 설명했다. | 초안에서 결정할 수 없었던 오류 행동을 명세로 설명했다. 계산값이 0원이라는 사실과 입력을 허용할지는 다른 문제임을 확인했다. 실제 오류 처리와 보존 시험은 아직 수행하지 않았다. |
| 정렬과 반복 | 구체적인 정렬 기준이 없다고 지적했다. ‘일관된 결과’를 파일 해시 비교로 확인할 수 있다고 제안했다. | 매출 내림차순, 동률 제품명 Unicode 오름차순, 동일 논리 입력의 출력 바이트 동일을 명세에서 찾아 제시했다. 관계 검사 파일은 이번 읽기 범위 밖이라고 설명했다. | 초안에서 제안한 검증 방법이 구체화된 명세에서는 명시적인 요구가 됐다. 관계 파일을 이번에 읽지 않은 것과 파일이 제공되지 않은 것은 구분해야 한다. |
| 원본과 해석 | 원본 보호와 근거 없는 이익 계산·원인 단정 금지를 찾았다. 일부 자동 확인 가능한 항목도 수동 확인으로 분류했다. | 원본 해시 비교는 자동 검사, 보고서의 근거 없는 해석은 사람의 검토로 구분했다. 입력 경로가 달라도 원본 불변 원칙과 양립한다고 설명했다. | 자동 확인과 사람의 내용 검토를 나눠 설명한 점은 적절하다. 다만 마지막 질문 목록에서 원본 경로 관계를 다시 확인해 달라고 하여 답변 전체가 일관되게 정리된 것은 아니다. |

### 비교에서 확인한 점

같은 모델과 같은 요청을 사용하면서 SPEC.md를 구체화하자, 출력·오류 처리·결과 보존·정렬에 대해 문서 근거가 있는 답변을 얻었다.

그러나 이미 정해진 규칙을 다시 질문하거나, 충돌하지 않는 지시를 충돌로 판단한 부분도 남았다. 명세를 제공한 뒤에도 Agent의 설명을 사람이 문서와 대조해야 한다.

이번 결과는 명세 검토의 변화다. 분석 프로그램의 정확성·성능·오류 처리 동작을 실제 실행으로 검증한 결과는 아니다.
````

이번 실제 응답에는 구체화 후에도 다시 판단해야 할 질문이 있었습니다.

| Agent의 질문·판단 | 기록할 때 확인한 내용 |
|---|---|
| 원본 sales.csv 보호와 시험용 CSV 읽기가 충돌한다 | 서로 양립한다. 파일을 읽는 대상과 수정 금지 규칙을 구분한다 |
| +5와 -5의 처리를 다시 결정해야 한다 | 선택적 부호와 값 1 이상 규칙이 함께 있으므로 +5는 허용, -5는 거부한다 |
| 검토 요청에 결과 폴더가 없어 충돌한다 | 지금은 읽기 검토다. 이후 실행 요청에 outputs/ 아래 폴더를 지정하면 된다 |
| report.md 제목·표 모양이 없으므로 진행을 보류해야 한다 | 필수 내용을 만족하는 세부 표현은 구현할 때 선택할 수 있다 |
| 관계 파일을 제공받지 못했다 | 이번 요청의 읽기 범위 밖이라는 사실과 파일이 없다는 판단은 구분한다 |

이어서 나머지 기록도 갱신합니다.

| 기록 위치 | 지금 추가할 내용 |
|---|---|
| 1절 | 두 번째 Chat 이름, 세션 JSON 파일명, 같은 요청을 사용했는지, 구체화된 SPEC 해시 |
| 5절 | 두 번째 read_file 8회, 질문 목록과 문서 대조 결과, CHECK_PASS: specified는 요청 전 검사였다는 점 |
| 6절 | specified_response.md, 두 번째 세션 JSON, check-specified의 실제 파일명 |

실제 두 번째 세션은 `session-20260911_042705_4b7851.json`이며, 요청 전 검사는 `check-specified-20260911T042849030724Z-a64d44.json`입니다. 이 예시의 두 세션에서는 각각 요청을 한 번 보내고 파일 읽기 도구인 `read_file`을 8회 사용했습니다. 질문은 최종 응답에 적혀 있었습니다. 사람에게 추가 답변을 받는 `Clarify` 도구 호출은 없었습니다.

**저장 직전 확인:** 3절 여섯 행의 세 칸이 모두 채워졌는지 읽고, 4절의 인수조건이 남아 있는지 확인합니다. 최종 검사 결과는 아직 실행 전이므로 ‘확인 전’으로 둡니다. Ctrl+S로 저장하고 닫은 뒤 단계 6으로 갑니다. 누적 예시는 `examples/spec_review_stages/05_comparison.md`입니다.

### 단계 6. 최종 상태와 관찰 기록을 확인한다

지금까지 작성한 기준값·초안 검토·인수조건·두 번째 검토가 한 파일에 모였습니다. 마지막으로 원본과 설정이 유지됐는지 확인하고, 빠진 기록을 채웁니다.

**6-1. 파일과 Baseline 보존을 확인합니다**

**PowerShell — 작업 위치: `C:\AI-Native\harness-engineering`**

```powershell
.\lesson06.ps1 check final
```

`CHECK_PASS: final`을 확인하면 아래 명령으로 3교시 Baseline 보존을 확인합니다. 오류가 나오면 먼저 원문을 보관하고 7)의 복구 안내를 적용합니다.

```powershell
.\lesson03.ps1 verify
```

`BASELINE_INTEGRITY_PASS`는 최초 실행 기록이 유지된다는 뜻입니다. 이번 검토가 더 정확했는지를 평가하는 메시지가 아닙니다.

실제 실행에서는 다음 결과를 확인했습니다. 본인 기록에는 본인의 검사 파일명을 적습니다.

```text
{
  "stage": "final",
  "workspace_matches": true,
  "workspace_differences": [],
  "settings_match": true,
  "settings_differences": [],
  "memory_and_skills_unchanged": true,
  "original_csv_unchanged": true,
  "common_inputs_unchanged": true,
  "spec_sha256": "80813a38ca366a3a8e1e454e039a7d677cd5aebdfa1aa5edcdb836a557bc3475",
  "request_sha256": "04da5ae70666badcc77f7b591574fb31e61e75e5fe83e1ef700a377cb0e79556",
  "scope": "Checks files and saved settings; assess reasoning and actual tool use from the exported Chat."
}
RECORDED: records/lesson06/check-final-20260911T050630472122Z-68b3bb.json
CHECK_PASS: final
```

이어 실행한 `lesson03.ps1 verify`의 결과입니다.

```text
BASELINE_INTEGRITY_PASS
```

| 최종 검사 항목 | 실제 결과 |
|---|---|
| workspace_matches / settings_match | true / true |
| workspace_differences / settings_differences | [] / [] |
| memory_and_skills_unchanged | true |
| original_csv_unchanged / common_inputs_unchanged | true / true |

**6-2. 두 검사 조건을 비교합니다**

```powershell
Get-ChildItem .\records\lesson06 -Filter 'check-*.json'
Get-ChildItem .\records\lesson06 -Filter 'facts-*.json'
```

`check-start`, `check-draft`, `check-specified`, `check-final`이 있는지 확인합니다. `facts`와 `specify`가 앞 상태를 다시 검사하므로 start·draft 기록이 추가로 생기는 것은 정상입니다. 개인별 실행 시각이 파일명에 들어갑니다.

파일 탐색기에서 첫 `check-draft`와 마지막 `check-final` JSON을 메모장으로 열어 비교합니다. `request_sha256`은 같고 `spec_sha256`은 달라야 합니다. 두 검사에서 설정·Memory·Skill·공통 입력 유지 여부도 확인합니다. 이 결과를 관찰 기록에 옮깁니다.

실제 실행의 해시는 다음과 같습니다. 해시는 파일 내용의 지문처럼 사용합니다. 숫자를 외우는 대신 같은 조건에서 유지되는지 확인합니다.

| 대상 | 실제 SHA-256 | 비교 결과 |
|---|---|---|
| 요청 파일 | `04da5ae70666badcc77f7b591574fb31e61e75e5fe83e1ef700a377cb0e79556` | 시작·초안·구체화 후·최종 검사에서 동일 |
| 초안 SPEC | `6e05d4387cdf8f8283f1a81e802e6587cf90d4be95a52a464f4d378b887f9397` | 시작·초안 검사에서 동일 |
| 구체화된 SPEC | `80813a38ca366a3a8e1e454e039a7d677cd5aebdfa1aa5edcdb836a557bc3475` | 구체화 후 요청 전·최종 검사에서 동일 |

**6-3. 기록을 완성합니다**

```powershell
notepad .\records\lesson06\spec_review.md
```

단계별로 작성한 내용을 처음부터 읽고 빈 항목만 채웁니다. 마지막 검사 결과와 실제 검사 파일명을 추가합니다. 응답 비교에는 실제 응답과 근거 문장을 사용합니다. **보조 도구의 PASS와 Agent의 판단을 한 가지 결과로 쓰지 않습니다.**

> `spec_review.md`, `draft_response.md`, `specified_response.md`는 수업에서 정한 파일명입니다. `session-…json`, `check-…json`, `facts-…json`은 본인에게 생성된 실제 파일명을 씁니다. 아래 예시의 이름과 성공 문장을 그대로 제출하지 말고, 본인의 관찰 결과에 맞게 바꾸세요.

이 시점에 바꾸는 기록은 **5·6절의 최종 확인 부분**입니다. 단계 5에서 완성한 3절 비교를 새 문안으로 다시 바꾸지 않습니다.

```markdown
- 최종 파일 검사: CHECK_PASS: final.
- 작업 파일·저장된 설정 차이 없음. Memory·Skill·입력 원본·공통 입력 유지.
- 구체화된 SPEC 해시는 check specified와 check final에서 동일했다.
- 요청 파일 해시는 시작부터 최종 검사까지 동일했다.
- 종료 시 Baseline 검사: BASELINE_INTEGRITY_PASS.
- 최종 검사 파일: check-final-20260911T050630472122Z-68b3bb.json.
- 검사 JSON 6개, facts JSON 1개, 응답 파일 2개, 세션 JSON 2개를 보관했다.
- 완료 범위: 명세 검토·인수조건 작성·증거 보관·파일과 설정 보존 확인.
- 분석 프로그램의 정상·오류·반복 실행 시험은 이후 구현한 프로그램으로 수행한다.
```

위 검사 수는 이번 실행의 예입니다. 중간 검사를 더 했다면 파일 수가 늘 수 있으므로 본인의 목록으로 확인합니다. 파일별 이름은 아래 최종 예시의 6절처럼 목록으로 남깁니다.

**6-4. 저장된 파일을 확인합니다**

```powershell
Get-Item .\workspace\SPEC.md
Get-Item .\records\lesson06\spec_review.md
Get-Item .\records\lesson06\draft_response.md, .\records\lesson06\specified_response.md
Get-ChildItem .\records\lesson06 -Filter 'session*.json'
```

파일 이름과 크기가 표시되면 파일이 저장된 것입니다. `spec_review.md`를 열어 빈 항목이 없는지도 확인합니다. 파일이 있다는 사실만으로 기록 내용이 완성되었다고 판단하지 않습니다.

**실제 저장 확인 예**

| 파일 | PowerShell에서 확인한 크기 |
|---|---:|
| workspace/SPEC.md | 6,173바이트 |
| records/lesson06/spec_review.md | 16,744바이트 |
| records/lesson06/draft_response.md | 7,561바이트 |
| records/lesson06/specified_response.md | 9,612바이트 |
| session-20260911_034916_fb10c3.json | 44,753바이트 |
| session-20260911_042705_4b7851.json | 56,133바이트 |

**기록·응답·세션 파일의 크기는 본인의 작성 내용과 실행에 따라 달라집니다. 위 크기에 맞추는 과제가 아닙니다.** 파일이 저장됐는지 확인한 뒤, 기록 내용을 읽어 자신의 실행과 맞는지 확인합니다.

**6-5. 시작부터 완성된 기록까지 대조합니다**

`examples/spec_review_progression.md`에는 단계별 변화가, `examples/spec_review_stages`에는 각 시점의 전체 기록 예시가 있습니다. 시작 예시에는 실행 조건만 있고, 기준값·초안·인수조건·두 번째 응답·최종 검사 순서로 내용이 쌓입니다.

아래는 실제 실행 결과를 반영한 최종 기록 예시입니다. **3절은 단계 5-5와 같은 문안**입니다. 파일로는 `examples/spec_review_example.md`와 `examples/spec_review_stages/06_final.md`가 이 내용과 같습니다. 자신의 기존 기록과 대조하면서 빠진 항목만 보완합니다.

````markdown
# 6교시 명세 검토 기록

현재 진행 상태: 기준값 확인, 초안·구체화 후 명세 검토, 응답·세션 보관, 최종 파일 검사와 Baseline 보존 검사 완료.

## 1. 실행 조건

- 작성자: Nuguna
- 실습 날짜: 2026-09-11
- 모델 / Hermes 추론 설정: `z-ai/glm-5.3-flash` / `low`
- 사용 화면: Windows PowerShell 7.6.5, Hermes 웹 대시보드, 메모장
- 실행 환경 / Agent 작업 폴더: Docker 컨테이너 / `/workspace`
- 정상 Context를 준비한 결과: `PREPARE_PASS`를 확인했고 컨테이너는 `healthy`였다. 준비 전후 모두 `BASELINE_INTEGRITY_PASS`를 확인했다.
- 첫 요청 전 검사: `START_READY`. 작업 파일·설정의 차이가 없었으며 Memory·Skill·공통 입력이 유지됐다.
- 초안 세션 이름: `specification-lesson06-draft`
- 초안 세션 JSON: `session-20260911_034916_fb10c3.json`
- 구체화 후 세션 이름: `specification-lesson06-specified`
- 구체화 후 세션 JSON: `session-20260911_042705_4b7851.json`
- 사용한 요청: `workspace/review_request.txt`의 검토 요청을 서로 다른 두 Chat에서 각각 한 번 전송했다.
- 요청 SHA-256: `04da5ae70666badcc77f7b591574fb31e61e75e5fe83e1ef700a377cb0e79556`
- 초안 SPEC SHA-256: `6e05d4387cdf8f8283f1a81e802e6587cf90d4be95a52a464f4d378b887f9397`
- 같은 요청을 사용했는가: 두 검사에서 요청 파일 해시가 같았고, 두 세션 JSON에 실제 전송된 요청 본문도 완전히 일치했다.
- 비교에서 변경한 파일: `workspace/SPEC.md`. 두 세션에서 읽은 파일의 반환 내용을 대조했을 때도 SPEC.md만 달랐다.
- 구체화 후 SPEC SHA-256: `80813a38ca366a3a8e1e454e039a7d677cd5aebdfa1aa5edcdb836a557bc3475` — 두 번째 요청 전 check specified에서 확인했다.

## 2. 데이터로 확인한 기준값

- facts 기록 파일명: `facts-20260911T035420469556Z-d3db68.json`
- 기준값 확인 결과: `FACTS_READY`

| 입력 | 행 수 | 총수량 | 총매출 |
|---|---:|---:|---:|
| inputs/sales/sales_micro.csv | 10 | 19 | 56,000원 |
| inputs/lesson03/sales.csv | 200 | 708 | 56,715,000원 |

10행 파일의 카테고리별 매출은 다음과 같다.

| 카테고리 | 매출 |
|---|---:|
| Accessory | 16,000원 |
| Monitor | 18,000원 |
| Office | 5,000원 |
| Storage | 17,000원 |
| 합계 | 56,000원 |

상위 제품은 `USB Drive 128GB` 16,000원, `27-inch Monitor` 13,000원, `Laptop Stand` 12,000원 순이다.

행별 계산 근거 중 `M-0002`는 수량 3 × 실제 적용 단가 3,000원 = 9,000원이다. 단가에는 할인이 이미 반영되어 있으므로 할인을 다시 적용하지 않는다.

55,000원을 기대값으로 채택할 수 없는 이유는 열 건의 행 매출 합계가 다음과 같이 56,000원이기 때문이다.

```text
1,000 + 4,000 + 9,000 + 4,000 + 10,000
+ 3,000 + 2,000 + 6,000 + 12,000 + 5,000 = 56,000원
```

`quantity_zero.csv`에서는 CSV 레코드 5의 `quantity`가 `0`이다. 헤더를 1번으로 세므로 네 번째 주문의 위치가 레코드 5다.

이 결과는 제공된 보조 도구가 계산한 기준값이다. Agent가 작성한 분석 프로그램을 실행하거나 그 프로그램의 정확성을 검증한 결과는 아니다.

## 3. 명세 검토 전후

두 세션의 실제 응답과 읽은 문서를 비교했다. 아래 내용은 명세 검토 결과이며, 분석 프로그램을 실행해 검증한 결과는 아니다.

| 항목 | 초안 응답과 근거 | 구체화 후 응답과 근거 | 나의 판단 |
|---|---|---|---|
| 입력 규칙 | 업무 Context와 CSV에서 열과 의미를 찾았다. 다만 sales.csv 수정 금지와 시험용 CSV 읽기 요청을 충돌로 판단했다. | SPEC 1·2·6절에서 헤더, 인코딩, 필드 수, 날짜, 양수 정수 등의 규칙을 제시했다. 부호와 음수 처리는 추가 질문으로 남겼다. | 입력 검사 기준이 구체화됐다. 원본 보호와 시험용 파일 읽기는 충돌하지 않는다. 선택적 부호와 값이 1 이상이라는 규칙으로 +5는 허용하고 -5는 거부할 수 있으므로 추가 결정이 필요하지 않다. |
| 계산 | 업무 Context를 근거로 수량 × 실제 적용 단가를 제시하고 할인 재적용 금지를 설명했다. | SPEC 3절을 근거로 총매출, 카테고리 매출, 제품 매출, 총수량 계산을 제시했다. | 계산식은 초안에서도 확인할 수 있었다. 구체화 후에는 무엇을 집계해야 하는지까지 명세의 근거로 설명했다. |
| 출력 | Context에서 /workspace/outputs/ 경로를 찾았다. 초안의 ‘보기 좋게’만으로 파일명과 형식을 확정할 수 없다고 지적했다. | summary.csv와 report.md, section/name/value 열, total·카테고리·제품 행의 순서를 제시했다. 결과 폴더와 보고서 내부 구조는 추가 결정 사항으로 보고했다. | 출력 형식이 명확해졌다. 현재는 문서 검토 요청이므로 출력 폴더 미지정을 충돌로 볼 필요는 없다. 이후 실행에서 /workspace/outputs/ 아래 폴더를 지정하면 된다. 필수 내용을 지키는 제목과 표 모양은 구현 시 선택할 수 있다. |
| 오류와 보존 | 수량 0의 허용 여부와 처리 방식, 기존 결과 보존 정책이 정해지지 않았다고 보고했다. | SPEC 2·4·6절을 근거로 레코드 5의 quantity 값 0을 입력 오류로 판단했다. 종료코드 2, 오류 위치·필드·이유 기록, 기존 두 결과 파일의 바이트 보존을 설명했다. | 초안에서 결정할 수 없었던 오류 행동을 명세로 설명했다. 계산값이 0원이라는 사실과 입력을 허용할지는 다른 문제임을 확인했다. 실제 오류 처리와 보존 시험은 아직 수행하지 않았다. |
| 정렬과 반복 | 구체적인 정렬 기준이 없다고 지적했다. ‘일관된 결과’를 파일 해시 비교로 확인할 수 있다고 제안했다. | 매출 내림차순, 동률 제품명 Unicode 오름차순, 동일 논리 입력의 출력 바이트 동일을 명세에서 찾아 제시했다. 관계 검사 파일은 이번 읽기 범위 밖이라고 설명했다. | 초안에서 제안한 검증 방법이 구체화된 명세에서는 명시적인 요구가 됐다. 관계 파일을 이번에 읽지 않은 것과 파일이 제공되지 않은 것은 구분해야 한다. |
| 원본과 해석 | 원본 보호와 근거 없는 이익 계산·원인 단정 금지를 찾았다. 일부 자동 확인 가능한 항목도 수동 확인으로 분류했다. | 원본 해시 비교는 자동 검사, 보고서의 근거 없는 해석은 사람의 검토로 구분했다. 입력 경로가 달라도 원본 불변 원칙과 양립한다고 설명했다. | 자동 확인과 사람의 내용 검토를 나눠 설명한 점은 적절하다. 다만 마지막 질문 목록에서 원본 경로 관계를 다시 확인해 달라고 하여 답변 전체가 일관되게 정리된 것은 아니다. |

### 비교에서 확인한 점

같은 모델과 같은 요청을 사용하면서 SPEC.md를 구체화하자, 출력·오류 처리·결과 보존·정렬에 대해 문서 근거가 있는 답변을 얻었다.

그러나 이미 정해진 규칙을 다시 질문하거나, 충돌하지 않는 지시를 충돌로 판단한 부분도 남았다. 명세를 제공한 뒤에도 Agent의 설명을 사람이 문서와 대조해야 한다.

이번 결과는 명세 검토의 변화다. 분석 프로그램의 정확성·성능·오류 처리 동작을 실제 실행으로 검증한 결과는 아니다.

## 4. 내가 작성한 인수조건

다음 인수조건은 구체화된 공통 SPEC.md의 입력·출력·오류·반복 조건에 대응한다. 10행 입력의 기대값은 facts 결과를 근거로 사용한다. 아래 실행 행동과 기대값은 앞으로 프로그램을 검사할 기준이며 실제 실행 결과가 아니다.

### AC-01 정상 입력

- 준비된 조건: `sales_micro.csv`와 비어 있는 시험용 결과 폴더 `/workspace/outputs/ac01`이 있다.
- 실행할 행동: `/workspace`에서 `python analyze_sales.py --input /inputs/sales/sales_micro.csv --output-dir /workspace/outputs/ac01`을 실행한다.
- 확인할 결과: 종료코드 0이며 `summary.csv`와 `report.md`가 생성된다. 총매출은 56,000원, 총수량은 19개다. CSV는 `section,name,value` 열을 사용하고 명세의 행 순서를 따른다. 보고서에는 총매출·카테고리 집계·상위 3개 제품이 구분되어 있다.
- 검증 방법: 종료코드와 CSV의 열·값·순서를 확인한다. 보고서의 필수 내용과 설명은 문서를 열어 검토한다.

### AC-02 오류와 기존 출력 보존

- 준비된 조건: 정상 입력으로 생성한 `summary.csv`와 `report.md`가 `/workspace/outputs/ac02`에 있다. 두 파일의 SHA-256을 각각 기록했다.
- 실행할 행동: 같은 결과 폴더를 지정하여 `/inputs/sales/errors/quantity_zero.csv`로 분석 프로그램을 실행한다.
- 확인할 결과: 종료코드 2이며 stderr에 CSV 레코드 5, 필드 quantity, 규칙 위반 이유 또는 오류 코드가 나온다. 기존 두 결과 파일의 바이트는 유지된다.
- 검증 방법: 종료코드와 stderr를 확인하고, 각 결과 파일의 실행 전후 SHA-256을 비교한다. 오류 메시지의 표현 자체가 한 문장으로 고정될 필요는 없다.

### AC-03 반복 실행

- 준비된 조건: 같은 분석 프로그램·실행 환경·`sales_micro.csv`를 사용한다.
- 실행할 행동: `/workspace/outputs/ac03`을 결과 폴더로 지정하여 두 번 실행한다. 첫 실행 직후와 두 번째 실행 직후에 두 결과 파일의 SHA-256을 각각 기록한다.
- 확인할 결과: 두 실행 모두 종료코드 0이다. 첫 실행의 summary.csv와 두 번째 실행의 summary.csv 해시가 같고, report.md도 실행 간 해시가 같다.
- 검증 방법: 같은 이름의 파일끼리 해시를 비교한다. 서로 다른 프로그램이 작성한 보고서 문장까지 같아야 한다는 조건은 아니다.

## 5. 실제 관찰과 자동 검사

### 실제 도구 사용

- 초안에서 사용한 도구: `read_file` 8회.
- 읽은 파일: CONTEXT_INDEX.md, 네 Context 문서, SPEC.md, sales_micro.csv, quantity_zero.csv.
- 읽기 기록: CONTEXT_INDEX.md를 먼저 읽었다. 다음으로 네 Context 문서와 SPEC.md를 하나의 도구 호출 묶음으로 요청했고, 이후 CSV 두 개를 읽었다. 묶음 내부의 엄격한 순차 실행까지 확인한 것은 아니다.
- 제공된 세션 JSON에는 다른 도구 호출이 없다.
- 결정 대기 질문은 최종 응답에 기록했다. `Clarify` 호출이나 질문에 대한 추가 사용자 답변은 첨부 세션에 없다.
- 구체화 후 도구 사용: `read_file` 8회. 두 세션에서 읽은 파일 목록이 같다.
- 두 번째 세션에도 다른 도구 호출이나 Clarify 호출은 없으며, 결정 질문은 최종 응답에 적었다.

### 파일과 설정 검사

| 검사 항목 | 시작 | 초안 검토 후 | 구체화 후 요청 전 | 최종 |
|---|---|---|---|---|
| workspace_matches | true | true | true | true |
| workspace_differences | [] | [] | [] | [] |
| settings_match | true | true | true | true |
| settings_differences | [] | [] | [] | [] |
| memory_and_skills_unchanged | true | true | true | true |
| original_csv_unchanged | true | true | true | true |
| common_inputs_unchanged | true | true | true | true |

- 초안 검토 후 결과: `CHECK_PASS: draft`.
- 요청과 초안 SPEC의 해시는 시작 검사 때와 동일했다.
- 구체화 후 검사: `CHECK_PASS: specified`. 작업 파일·설정의 차이 목록은 비었고 Memory·Skill·공통 입력은 유지됐다. 이 검사는 두 번째 요청을 보내기 전 수행했다.
- 최종 파일 보존 검사: 두 번째 검토 후 `lesson06.ps1 check final`에서 `CHECK_PASS: final`을 확인했다. 검사 대상 작업 파일과 저장된 설정이 기대 상태와 일치하고, Memory·Skill·입력 원본·공통 입력이 보존됐다.
- 최종 SPEC 해시: `80813a38ca366a3a8e1e454e039a7d677cd5aebdfa1aa5edcdb836a557bc3475`. 구체화 후 요청 전 검사와 동일하다.
- 최종 요청 파일 해시: `04da5ae70666badcc77f7b591574fb31e61e75e5fe83e1ef700a377cb0e79556`. 시작부터 최종 검사까지 동일하다.
- Baseline 검증: prepare 전후에 이어 6교시 종료 시 `lesson03.ps1 verify`에서도 `BASELINE_INTEGRITY_PASS`를 확인했다. 3교시에서 동결한 비교 기준의 무결성이 유지됐다.
- 프로그램 실행 결과: 이번 교시에는 분석 프로그램을 구현하지 않아 해당 없음.
- 재시도·복원: 제공된 실행 기록에서는 없음.

### 두 번째 응답에서 추가로 검토한 판단

- 출력 폴더: 검토 요청에서는 생성 작업을 하지 않는다. 실제 실행에서 `/workspace/outputs/` 아래 결과 폴더를 지정하면 공통 경계와 실행 인터페이스를 함께 만족한다.
- 보고서 구조: 총매출·카테고리 집계·상위 3개와 한국어·금액 단위 등 필수 조건을 지키는 범위에서 제목과 표 모양을 선택할 수 있다.
- 음수: 부호가 포함된 정수 형식과 값이 1 이상이라는 규칙은 함께 적용한다. -5는 값 범위 위반이며 구체적인 오류 문구를 새로 고정할 필요는 없다.
- 수량 표기: 명세에 금액·수량 value 모두 구분기호 없는 정수라고 명시되어 있다.
- 관계 파일: 이번 읽기 범위 밖이므로 미검증이다. 이번 세션만으로 파일 부재나 미제공을 판단하지 않는다.
- 한국어 보고서: 인코딩·CSV 열 같은 형식 검사와 한국어 설명의 적절성을 사람이 읽어 판단하는 일을 구분한다. 바이트 검사만으로 설명의 품질을 확인할 수는 없다.

## 6. 증거 파일과 다음 교시

### 현재 보관된 증거

| 파일 | 확인한 내용 |
|---|---|
| draft_response.md | PowerShell에서 파일 존재와 크기 7,561바이트 확인. |
| session-20260911_034916_fb10c3.json | 44,753바이트. 세션 JSON에서 요청·모델 설정·도구 호출과 응답 확인. |
| check-start-20260911T035057489884Z-44577c.json | 첫 요청 전 START_READY |
| check-start-20260911T035420428996Z-fd4558.json | facts가 먼저 수행한 시작 상태 재검사 |
| facts-20260911T035420469556Z-d3db68.json | 제공 데이터의 계산 기준값과 오류 위치 |
| check-draft-20260911T040036018876Z-ce9b61.json | 초안 검토 후 CHECK_PASS: draft |
| check-draft-20260911T041643241957Z-c1adbf.json | specify가 교체 전에 수행한 초안 상태 검사 |
| check-specified-20260911T042849030724Z-a64d44.json | 두 번째 요청 전 CHECK_PASS: specified |
| specified_response.md | PowerShell에서 파일 존재와 크기 9,612바이트 확인. |
| session-20260911_042705_4b7851.json | 56,133바이트. 두 번째 실제 요청·모델 설정·read_file 8회·응답 확인. PC의 records/lesson06에 보관된 것도 확인. |
| check-final-20260911T050630472122Z-68b3bb.json | 두 번째 검토 후 CHECK_PASS: final. 파일 목록에서도 존재 확인. |

### 종료 시 확인 결과

- `lesson06.ps1 check final`: `CHECK_PASS: final`.
- `lesson03.ps1 verify`: `BASELINE_INTEGRITY_PASS`.
- `records/lesson06`에서 검사 JSON 6개와 facts JSON 1개의 보관을 확인했다.
- 초안·구체화 후 응답 파일 2개와 세션 JSON 2개의 보관을 확인했다.
- 시작 검사와 초안 검사 파일이 각각 2개인 것은 facts와 specify 실행 시 상태를 다시 검사한 기록이 포함되어 있기 때문이다.

### 다음 교시로 넘길 내용

구체화된 `SPEC.md`, 인수조건, 두 응답의 비교와 증거 파일을 보관한다. 6교시의 명세 검토와 파일·설정 보존 확인을 마쳤다. 다음 교시에서는 이 명세와 인수조건을 구현·검증의 기준으로 사용한다.

이번 교시에서 분석 프로그램을 실행해 정상 출력·오류 처리·결과 보존을 시험한 것은 아니다. 4번 인수조건은 앞으로 구현한 프로그램을 확인할 기준이다.

### 이번 단계에서 배운 점

업무 Context가 있으면 계산식과 원본 보호처럼 이미 주어진 근거를 찾을 수 있다. 그러나 출력 형식·오류 처리·반복 실행의 완료 기준은 별도로 구체화해야 한다. 또한 Agent가 제안한 규칙이나 충돌 판단이 항상 명세의 근거와 일치하는 것은 아니므로 사람이 문서와 대조해야 한다.

같은 모델과 같은 요청에서 명세를 구체화하자, 출력·오류·보존·정렬에 대해 문서 근거가 있는 답변을 얻었다. 그러나 불필요한 결정 질문과 과도한 충돌 판단은 남았다. 이번 결과는 명세 검토의 변화이며 분석 프로그램의 성능 향상을 측정한 결과는 아니다.
````

## 7) 완료 점검과 오류 복구

### 완료 점검

- [ ] 구체화된 SPEC.md에서 입력·계산·출력·오류·반복 조건을 찾을 수 있다.
- [ ] 10행 총매출 56,000원과 총수량 19개를 데이터로 확인했다.
- [ ] 세 인수조건에 준비·행동·결과·검증 방법을 적었다.
- [ ] 두 검토의 응답·세션과 실제 사용한 도구를 기록했다.
- [ ] 같은 요청을 사용했으며 설정·공통 입력의 유지 여부를 확인했다.
- [ ] 최종 파일 검사와 Baseline 보존 검사를 통과했다.
- [ ] 남은 질문은 근거와 함께 적고, 구현 시작 전에 판단하도록 남겼다.

### 증상별로 먼저 확인하기

| 증상 | 의미와 다음 행동 |
|---|---|
| 스크립트가 서명되지 않았다는 오류 | Unblock-File -LiteralPath .\lesson06.ps1을 실행한 뒤 실패한 명령을 한 번 다시 실행한다 |
| 준비에서 Settings differ | 출력에 표시된 설정 항목을 확인한다. API Key를 포함한 전체 설정을 출력하지 않는다. 원인 항목을 바로잡고 한 번 다시 준비한다 |
| Lesson06 records already exist | 준비는 이미 수행했다. 현재 초안이면 check start, 구체화 이후면 check specified로 확인한다. 처음부터 다시 할 때는 아래 restore를 사용한다 |
| 구체화 후 check start가 실패 | start는 초안을 기대한다. 단계 5에서는 check specified, 종료 시에는 check final을 사용한다 |
| quantity_zero의 ‘레코드 5’가 낯설다 | 헤더가 1번이며 오류 주문은 네 번째 데이터 행이다 |
| Agent가 Clarify를 사용 | 질문 내용과 실제 답을 기록한다. 질문 자체를 파일 변경 실패로 보지 않는다 |
| CHECK_STOPPED와 차이 목록 | 실행을 멈추고 세션·오류를 보관한다. 지정 단계가 맞는지 확인한 뒤 실제 파일·설정 변화면 아래 복원을 사용한다 |
| 입력 해시가 다르다는 오류 | 공통 데이터 원본을 확인한다. restore는 inputs를 교체하지 않으므로 원본 문제를 먼저 해결한다 |
| Pending operation exists | 준비·복원이 중간에 멈췄다. pending JSON과 보관 폴더를 유지하고 강사에게 전달한다. 파일을 지우며 재시도하지 않는다 |

### 실습을 처음부터 다시 시작해야 할 때만 복원하기

문제가 없다면 이 절을 실행할 필요가 없습니다. 파일을 잘못 바꿨거나 Agent가 구현을 시작해 공통 진입점으로 돌아가야 할 때 사용합니다.

```mermaid
flowchart TD
  A["오류 발견 · 응답 생성 중단"] --> B["오류와 세션 보관"]
  B --> C{"시작 파일·설정 복원이 필요한가?"}
  C -->|아니오| D["원인 하나 수정 · 1회 재시도"]
  C -->|예| E["restore · 시도 보관 및 진입점 복원"]
  E --> F["Hermes 시작 · 새 Chat · 시작 검사"]
  D --> G["검사 후 해당 단계 계속"]
  F --> G
```

**복원하는 시점:** `prepare` 직후, 첫 명세 검토 요청 전입니다. `SPEC.md`는 모호한 초안으로 돌아갑니다. 관련 설정과 Memory·Skill 파일 상태도 진입점 기록으로 돌아갑니다.

**보관하는 것:** 이번 시도의 workspace·관찰 기록·변경된 관련 상태는 `records/lesson06-attempt-…`에 남습니다. 3교시 Baseline, 이전 교시 기록, 공통 CSV, 로그인·API Key는 유지됩니다. 대화 이력은 자동으로 되감지 않으므로 새 Chat을 만듭니다.

1. Hermes의 응답 생성을 멈춥니다. 현재 세션을 JSON으로 내보내어 `records/lesson06`에 복사하고 오류 원문도 보관합니다.
2. **PowerShell**에서 실행합니다.

```powershell
Set-Location 'C:\AI-Native\harness-engineering'
Unblock-File -LiteralPath .\lesson03.ps1
Unblock-File -LiteralPath .\lesson06.ps1
.\lesson06.ps1 restore
```

`RESTORE_PASS: Lesson06 entry files and recorded Harness state restored.`와 `BACKUP: records/lesson06-attempt-…`를 확인합니다. 이 보관 경로를 적어 둡니다. 복원 후 Hermes는 멈춘 상태입니다.

3. **prepare를 다시 실행하지 않고** 컨테이너를 시작합니다.

```powershell
docker compose up -d --force-recreate hermes
docker compose ps
```

`healthy`를 확인합니다. 컨테이너를 다시 만드는 이유는 복원된 Windows 작업 폴더를 정확하게 연결하기 위해서입니다.

4. 웹 대시보드에서 **New chat**을 열고 새 대화 이름을 붙입니다. 복원 시도를 구분하려면 `specification-lesson06-draft-retry1`처럼 이름을 사용할 수 있습니다. 모델과 추론 설정을 확인합니다.

```text
/title specification-lesson06-draft-retry1
/model z-ai/glm-5.3-flash
/reasoning low
/status
```

5. **PowerShell**에서 시작을 검사합니다.

```powershell
.\lesson06.ps1 check start
```

`START_READY`가 나오면 단계 2의 기준값 확인부터 계속합니다. 이전 시도의 좋은 답변을 새 시도의 결과와 섞지 않고 재시도 횟수를 기록합니다. 같은 문제가 다시 발생하면 새 증거를 남기고 중단합니다.

## 8) 핵심 내용과 다음 교시 준비

명세는 사람이 결정해야 할 요구를 Agent가 추측하지 않도록 정리한 약속입니다. 인수조건은 그 약속이 지켜졌는지 확인할 파일·숫자·행동을 정합니다. 모델을 바꾸지 않고도 일을 맡기는 조건을 구체화할 수 있습니다.

7교시에는 이번 `SPEC.md`와 인수조건을 바탕으로 **어떤 순서로 구현하고 어디에서 확인할지** 계획합니다. `workspace`에는 Context와 구체화된 명세를 두고, `records/lesson06`에는 관찰 기록과 두 검토의 증거를 보관합니다. 남은 질문은 구현 전에 확인할 계획 항목으로 전달합니다.
