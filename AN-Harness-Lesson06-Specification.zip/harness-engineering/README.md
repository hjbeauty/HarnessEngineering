# 6교시 실습 자료

**AI Native 소프트웨어 개발: Harness Engineering — 학습 가이드북**

`06_specification_acceptance_preview.html`을 브라우저에서 열거나 `06_specification_acceptance.md`를 읽으며 시작합니다. ZIP 안의 harness-engineering 폴더를 C:\AI-Native에 합칩니다. 자세한 압축 해제와 준비 절차는 가이드북 단계 1에 있습니다.

공통 CSV와 2~5교시 실행 환경을 이어서 사용합니다. 준비 명령은 앞 교시 작업을 보관하고 6교시 시작 파일과 빈 기록 양식을 준비합니다.

## 기록을 작성하는 방법

학생은 `records/lesson06/spec_review.md` 하나를 계속 수정합니다. 실행 조건 → 기준값 → 초안 검토 → 인수조건 → 두 응답 비교 → 최종 확인 순서로 내용을 추가합니다. 가이드북의 각 단계에 지금 채울 절과 실제 결과를 반영한 예시가 있습니다.

- `templates/spec_review.md`: 준비 명령이 복사하는 빈 양식.
- `examples/spec_review_progression.md`: 단계별 기록의 변화 설명.
- `examples/spec_review_stages/00_blank.md`~`06_final.md`: 각 시점의 전체 기록 예시.
- `examples/spec_review_example.md`: 실제 실행 결과를 반영한 최종 예시. `06_final.md`와 내용이 같습니다.

단계별 파일은 실제 로그와 세션을 바탕으로 재구성한 작성 예시입니다. 해당 시점의 원본 백업이 아닙니다. 예시의 작성자·날짜·파일명·응답·성공 여부는 본인의 결과로 바꾸세요. 앞으로 실행할 인수조건을 이미 통과한 결과처럼 기록하지 않습니다.

## 자료를 다시 받은 경우

ZIP에 포함된 가이드북·양식·예시 등 수업 자료를 교체합니다. 개인 `records`, 현재 `workspace`, `.env`, `compose.yaml`, 공통 CSV는 ZIP에 포함되지 않습니다. 이미 실습을 마쳤다면 `prepare`나 모델 요청을 반복할 필요 없이 새 가이드의 기록 예시와 자신의 기록을 대조하면 됩니다. `examples`의 파일을 개인 기록에 자동으로 덮어쓰지 않습니다.

문제로 시작 상태를 되돌려야 할 때만 가이드북 7)의 복원 절차를 사용합니다.
