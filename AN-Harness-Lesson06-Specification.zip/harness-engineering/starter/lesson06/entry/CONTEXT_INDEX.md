# Context를 읽는 순서

적용 범위: 공통 판매 데이터 분석 프로젝트의 6교시 명세 검토.
출처: 과정에서 정한 작업 경계와 제공된 업무 배경.

1. context/constraints.md: 지켜야 할 경계
2. context/environment.md: 실행 환경
3. context/sales_business_context.md: 데이터의 업무상 의미
4. context/conventions.md: 작성 방식
5. SPEC.md: 이번에 검토할 입력·계산·출력·오류 조건

이 순서는 읽는 순서입니다. 충돌이 있으면 두 문장과 출처를 보고하고 사람의 결정을 기다립니다.
확인하지 못한 사실과 명세에 없는 요구는 구분해 적습니다.
6교시에는 이 문서들과 요청에서 지정한 CSV만 읽고, 프로그램 구현과 파일 변경은 하지 않습니다.
