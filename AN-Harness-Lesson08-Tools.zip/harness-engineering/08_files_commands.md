# 8교시 폴더·파일·명령 참고

**AI Native 소프트웨어 개발: Harness Engineering — 학습 가이드북**

가이드북 3절과 같은 설명을 모았습니다. 실제 입력 순서는 [8교시 가이드북](08_tool_harness.md)의 단계별 실습을 따릅니다.

### 3.2 Windows와 컨테이너의 경로

컨테이너는 Hermes와 분석 프로그램을 실행하는 별도의 Linux 실행 환경입니다. 교육생은 Windows에서 명령을 입력하고, 스크립트가 Docker를 통해 컨테이너의 프로그램을 호출합니다. 이번 실습에서 Ubuntu 터미널을 따로 열 필요는 없습니다.

| Windows에서 보이는 위치 | 컨테이너에서 보이는 위치 | 용도 |
|---|---|---|
| `workspace/` | `/workspace/` | Agent가 읽는 문서와 수정하는 코드 |
| `inputs/` | `/inputs/` | 읽기 전용 원본 CSV |
| `course-tools/` | `/course-tools/` | 읽기 전용 교육용 검사 프로그램 |
| `records/lesson08/` | 일반 Chat에 별도 기록 경로로 제공하지 않음 | 교육생의 관찰 기록·승인 사본·수집된 실행 로그 |

`prepare`나 `restore`를 실행하면 `lesson08.ps1`이 준비·백업 작업을 맡을 **관리용 보조 컨테이너**를 잠깐 실행합니다. 이 안에서 교육용 관리 프로그램인 `lesson08_tools.py`가 시작 파일을 준비하거나 작업 기록을 보관합니다. 교육생이 이 컨테이너에 직접 접속할 필요는 없습니다.

**`/course-host`는 Windows의 프로젝트 폴더 `C:\AI-Native\harness-engineering`을 관리용 보조 컨테이너 안에서 찾아갈 때 사용하는 경로입니다.** Docker가 두 경로를 연결하므로, 관리 프로그램은 다음과 같은 이름으로 Windows의 파일에 접근합니다.

| Windows에 있는 폴더 | 관리용 보조 컨테이너 안의 경로 | 관리 프로그램이 하는 일 |
|---|---|---|
| `C:\AI-Native\harness-engineering\starter` | `/course-host/starter` | 교시 시작 자료를 읽음 |
| `C:\AI-Native\harness-engineering\workspace` | `/course-host/workspace` | 실습할 작업 파일을 준비하거나 복원함 |
| `C:\AI-Native\harness-engineering\records` | `/course-host/records` | 이전 작업과 검사·승인 기록을 보관함 |

이 연결은 파일을 다른 곳에 복사하는 것이 아닙니다. 예를 들어 관리 프로그램이 `/course-host/records`에 백업을 저장하면 Windows의 `records` 폴더에도 그 파일이 보입니다. 시작 자료·작업 파일·기록 폴더를 함께 다뤄야 하므로 프로젝트 폴더 전체를 연결하는 것입니다.

Agent가 작성한 `analyze_sales.py`는 **일반 Hermes 컨테이너에서 실행**합니다. 여기서는 코드가 `/workspace/analyze_sales.py`에 보이고, 관리용 연결인 `/course-host`는 추가하지 않습니다. 백업과 승인 기록을 다루는 넓은 접근 범위에서 분석 코드가 실행되지 않도록 실행 장소를 구분한 것입니다. 이 구분과 별도로, 실제 도구 사용과 파일 변경이 허용 범위에 맞았는지도 확인합니다.

### 3.3 사용하는 폴더와 파일

`starter`는 시작 자료, `workspace`는 실제 작업 공간, `templates`는 빈 기록 양식, `records`는 교육생의 기록, `examples`는 작성 방법을 보는 예시입니다. 예시를 읽는 것과 자신의 결과를 기록하는 것은 별개의 작업입니다.

| 폴더·파일 | 주요 내용과 역할 | 누가 언제 사용하는가 |
|---|---|---|
| `starter/lesson08/` | 현재 경계·읽기 순서·빈 정책·실습 요청문 | `prepare`가 workspace에 복사. 교육생은 starter를 편집하지 않음 |
| `workspace/CONTEXT_INDEX.md` | 문서와 코드를 읽을 순서 | 새 Chat에서 Agent가 먼저 읽음 |
| `workspace/context/` | 경계, 환경, 판매 데이터 의미, 작성 관례의 네 문서 | Agent와 교육생이 판단 근거로 읽음. 준비 시 8교시 경계만 바뀜 |
| `workspace/SPEC.md` | 입력·계산·출력·오류·정렬 기준 | 6교시 정본을 그대로 읽음 |
| `workspace/PLAN.md` | P1·P2·P3의 계획 | 7교시 검토본을 그대로 읽음 |
| `workspace/TOOL_POLICY.md` | 행동별 주체·대상·조건·기록 | 정책 단계에서 Agent가 작성. 승인 후 고정 |
| `workspace/analyze_sales.py` | P1 입력 검사에 P2 계산·출력을 추가할 코드 | 승인 뒤 Agent가 이 파일만 수정 |
| `workspace/lesson08/TASK.md` | P2의 작업 범위, 네 실행, 성공 기준 | 모든 단계의 작업 안내 |
| `workspace/lesson08/ACCEPTANCE.md` | 7교시에서 이어받은 인수조건 사본 | `prepare`가 복사. 인수조건은 완료 여부를 판단할 약속 |
| `workspace/lesson08/*_request.txt` | 정책 작성, P2 구현, 범위 판단의 요청문 | 해당 단계에서 PowerShell로 클립보드에 복사 후 Chat에 전송 |
| `workspace/lesson08/approval.json` | P2 승인 단계와 승인한 PLAN·정책 해시 | `approve`가 생성, Agent는 읽기만 함 |
| `inputs/sales/sales_micro.csv` | 손으로도 계산을 확인할 수 있는 정상 10행 | 정상·반복 실행에 사용 |
| `inputs/sales/errors/quantity_zero.csv` | 레코드 5의 quantity가 0인 입력 | 오류 위치와 결과 보존 확인 |
| `workspace/outputs/lesson08-p2/` | 프로그램의 `summary.csv`, `report.md` | 정상 실행이 생성·교체. 오류 실행은 기존 바이트 유지 |
| `workspace/lesson08/checks/p2-…/` | 실행별 명령·stdout·stderr·출력 사본·검사 보고서 | 검사 도구가 자동 생성 |
| `templates/tool_audit.md` | 비어 있는 관찰 기록 양식 | `prepare`가 records로 복사 |
| `records/lesson08/tool_audit.md` | 처음부터 마지막까지 누적하는 나의 기록 | 교육생이 메모장에서 단계별로 작성 |
| `records/lesson08/check-*.json` | 파일·저장 설정의 단계별 관찰 | `check`와 일부 명령이 자동 생성 |
| `records/lesson08/approved-TOOL_POLICY.md`, `approved-PLAN.md`, `approved-policy.json` | 승인한 문서 사본과 승인 정보 | `approve`가 생성. 이후 변경 여부를 대조 |
| `records/lesson08/probe-runs/p2-…/` | workspace 검사 로그의 보관 사본 | `test`가 실행 뒤 수집 |
| `records/lesson08/latest-probe.json` | 가장 최근 수집한 실행 보고서 | 최종 검사와 실행 폴더 찾기에 사용 |
| `records/lesson08/*_response.md`, `session*.json` | Agent 응답 원문과 대화·도구 이력 | 교육생이 저장·내보내 보관 |
| `records/lesson08/checkpoint/` | 시작 파일·관련 설정·Memory·Skill의 복원 원본 | prepare가 보관. 직접 편집하지 않음 |
| `records/lesson08/prior-workspace/` 등 준비 백업 | 준비 전 작업의 보존 사본 | 관리 도구가 보관 |
| `records/lesson08-attempt-…/` | 복원 전 시도의 작업과 기록 | restore 때 자동 생성 |
| `examples/tool_audit_stages/` | 기록이 단계마다 늘어나는 예상 예시 | 필요할 때 참고. 자신의 기록을 대신하지 않음 |

### 3.4 스크립트는 무엇을 하는가

| 파일 | 역할 | 분석 코드를 실행하는가 |
|---|---|---|
| `lesson08.ps1` | PowerShell의 실행 창구. 검사 순서, 컨테이너 중지·시작, Python 호출을 연결 | `test`에서 일반 컨테이너의 검사 도구를 호출 |
| `course-tools/lesson08_tools.py` | 진입 조건 확인, 시작 상태 백업, 승인 저장, 파일·설정 비교, 로그 수집, 복원 | 직접 실행하지 않음 |
| `course-tools/lesson08_probe.py` | 네 번의 실행과 기대값 비교, 출력·오류·파일 해시 기록 | 일반 컨테이너에서 실행당 최대 15초 기다림 |
| 기존 `lesson07.ps1` | 8교시 준비 전에 P1 완료 상태 확인 | 준비 과정에서는 final 검사만 호출 |
| 기존 `lesson03.ps1` | Baseline이 보존됐는지 확인 | `verify`만 사용 |

`probe`는 준비된 입력을 넣어 동작을 확인하는 검사 프로그램입니다. `check`가 작업 파일과 설정을 살펴보는 것과 달리, `test`는 실제로 분석 코드를 실행합니다.

```mermaid
flowchart TD
  P["PowerShell · lesson08.ps1"] --> M["관리 도구 · 준비와 기록"]
  P --> T["일반 컨테이너 · 실행 검사"]
  T --> C["analyze_sales.py"]
  C --> O["결과 파일과 오류 메시지"]
  O --> M
```

아래 명령표는 역할을 미리 보는 표입니다. 지금 한꺼번에 실행하지 않고 단계별 실습의 순서를 따릅니다.

| 명령 | 목적과 변경되는 것 |
|---|---|
| `prepare` | P1 완료 확인, 이전 작업 보존, 빈 정책·요청·기록과 복원 지점 준비, Hermes 재시작 |
| `check start` | 준비한 시작 파일·관련 설정의 일치 확인, JSON 기록 |
| `check policy` | 정책 파일만 변경된 상태인지 확인, JSON 기록 |
| `approve` | 검토한 정책·PLAN 사본과 P2 승인 기록 생성 |
| `check implemented` | 승인된 PLAN·정책을 유지하면서 코드와 허용된 실행 산출물만 달라졌는지 확인 |
| `test` | 네 실행, 값·순서·반복·보존 검사, 실행 로그 수집 |
| `check final` | 현재 코드·PLAN·정책·결과 파일이 통과한 실행과 이어지는지 확인 |
| `restore` | 현재 시도를 보관하고 8교시 시작 상태로 복원. Hermes는 중지 상태로 남음 |

