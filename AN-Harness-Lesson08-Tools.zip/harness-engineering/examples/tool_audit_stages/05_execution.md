# 8교시 도구 사용과 P2 실행 관찰 기록

실제 실습의 단계별 기록 예시입니다. 파일명과 결과는 자신의 실행에 맞게 바꾸고, 보고서 내용 검토 항목은 직접 읽은 판단으로 채웁니다.

## 1. 시작 상태
- 작성자 / 날짜: Nuguna / 2026-09-12
- 모델 / 추론 설정: z-ai/glm-5.3-flash / low
- Chat 이름 / 세션 JSON: tools-lesson08 / 내보내기 전
- 이어받은 것: 7교시의 SPEC.md·PLAN.md·인수조건과 P1 입력 검사 코드
- prepare / healthy / check start 결과: PREPARE_PASS / healthy / START_READY
- 시작 검사 파일: check-start-20260911T153645463655Z-3de0a7.json

## 2. 도구 정책 검토
- 정책 단계 변경 파일: TOOL_POLICY.md 하나
- 최초 작성 도구: Read File 13회, Write File 1회
- 최초 검토 의견: CSV 읽기 범위, 읽기 기록, 실행 장소와 로그 작성 주체, 프로그램 출력 권한, 환경 정보와 재검사 표현을 보완해야 한다.
- 보완 요청 / 결과: 여덟 항목의 보완을 요청했다. 두 CSV로 읽기를 한정하고, 세션의 읽기 이력·일반 컨테이너 실행·자동 로그 수집·분석 프로그램의 결과 쓰기를 구분했다. 읽기 전용 지시와 강제 제한을 나누고, 미확인 Python 버전을 생략했으며 재검사를 한 번으로 통일했다.
- 보완 도구 / 변경 파일: Write File 1회 / TOOL_POLICY.md
- 보완 후 검사 결과 / 파일명: CHECK_PASS: policy / check-policy-20260911T155929570809Z-359a70.json
- 보완 후 정책 해시: 818371c919aee8aea723aeb5a3fc2eb1a0a6322e9e878fb541737c14177cf8b0
- 실행 주체: 교육생이 PowerShell에서 lesson08.ps1 test를 실행하고, 일반 Hermes 컨테이너의 검사 도구가 분석 코드를 실행한다. Agent는 명령을 실행하지 않는다.
- 프로그램 결과: /workspace/outputs/lesson08-p2/summary.csv와 report.md. 모든 입력 검사 후 생성·교체하며 입력 오류에서는 기존 파일을 보존한다.
- 필요하지 않은 행동: 환율 조회·패키지 설치·설정·Memory·Skill 변경. 원 단위 집계는 표준 라이브러리로 수행한다.
- 문서와 제한의 구분: 정책은 행동 지시이며 읽기 전용 마운트는 환경의 제한이다. 정책 작성이 네트워크 강제 차단을 뜻하지 않는다.
- 응답 보관: policy_response.md / policy_revision_response.md
- 현재 판단: 보완된 정책을 검토했다. P2 승인 기록을 남겼다.

## 3. 승인과 구현
- 승인한 단계: P2 계산·출력 구현
- 승인하지 않은 단계: P3 더 넓은 검증
- approve 결과 / 승인 기록: APPROVE_PASS / approved-policy.json
- 승인 때 정책 검사 파일: check-policy-20260911T160351812389Z-a52361.json
- 승인 PLAN 해시: bd124587cdc364a2d1fdeaa46a1b799d9fe26afa58563c03749b51767f1af414
- 승인 정책 해시: 818371c919aee8aea723aeb5a3fc2eb1a0a6322e9e878fb541737c14177cf8b0
- Chat에 보낸 P2 구현 요청: lesson08/implement_request.txt의 전체 내용을 전송했다.
- 실제 도구 / 변경 파일: Read File 6회, Patch 6회 / analyze_sales.py 하나
- 구현 파일 확인: 12,479바이트
- check implemented 결과 / 파일명: CHECK_PASS: implemented / check-implemented-20260911T161400604532Z-6d8a66.json
- 구현 응답 보관 파일: implementation_response.md
- 실행 상태: 코드 작성과 변경 범위를 확인했다. 네 실행 검사 결과는 4절에 기록했다.

## 4. 실행과 결과 검토
- 실행 검사 결과: P2_CHECK_PASS
- 실행 보고서: records/lesson08/probe-runs/p2-20260911T162113309861Z-f5861e/report.json
- 실행한 코드 해시: eaefcc71537bad37378d30e30b37f1cb1b7e70ef8b1ba8de29a84fcc58cf4eca
- 실행 중 코드 유지: source_unchanged가 true임

| 사례 | 기대 종료코드 | 실제 종료코드 | 확인한 결과 | 나의 판단 |
|---|---|---|---|---|
| 정상 10행 | 0 | 0 | summary_matches와 report_utf8_nonempty가 true | CSV 집계와 순서가 기준에 맞고 보고서를 UTF-8로 읽을 수 있다. 내용은 별도로 검토한다. |
| 같은 입력 재실행 | 0 | 0 | repeat_bytes_equal이 true | 두 파일 각각 첫 실행과 같은 바이트를 유지했다. |
| 수량 0 | 2 | 2 | record=5, field=quantity, 값 1 이상 규칙 위반. existing_outputs_preserved가 true | 기대한 입력 오류이며 기존 정상 결과를 유지했다. |
| 없는 입력 | 2 | 2 | INPUT_NOT_FOUND, record=0. existing_outputs_preserved가 true | 없는 파일을 오류로 보고하고 기존 정상 결과를 유지했다. |

- 총매출 / 총수량: 56,000원 / 19개
- 카테고리 매출: Accessory 16,000원, Monitor 18,000원, Office 5,000원, Storage 17,000원
- 상위 3개 제품: USB Drive 128GB 16,000원, 27-inch Monitor 13,000원, Laptop Stand 12,000원
- summary.csv 해시: 9fbca724b702d7d656d5c95ed8cca25a9ff7df63d9c88767eabfee6f7039ecb1
- report.md 해시: 9a0f32769cd36d40d71a33cb6b7454c5e0b81a3207b70bf5da016cf5bf01338a
- 오류 설명 검토: 수량 0의 레코드·필드·규칙 위반 이유와 없는 입력의 오류 코드가 기대한 동작에 맞는다.
- 보고서 내용 검토: report.md를 직접 읽고 필수 집계 구분·한국어·원 단위·근거 없는 해석 여부에 대한 자신의 판단을 여기에 적는다.
- 실패 / 코드 수정 요청 / 재검사: 없음 / 없음 / 0회. 첫 검사에서 네 실행이 통과했다. 정책 보완 1회와 구분한다.
- 확인 범위: 네 실행의 자동 검사 통과. 전체 명세 검증과 P3의 다양한 오류·동률·관계 검사 완료를 뜻하지 않는다.
