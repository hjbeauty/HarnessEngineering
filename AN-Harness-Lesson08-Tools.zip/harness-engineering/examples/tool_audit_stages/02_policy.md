# 8교시 도구 사용과 P2 실행 관찰 기록

실제 실습의 단계별 기록 예시입니다. 파일명과 결과는 자신의 실행에 맞게 바꾸고, 보고서 내용 검토 항목은 직접 읽은 판단으로 채웁니다.

## 1. 시작 상태
- 작성자 / 날짜: Nuguna / 2026-09-12
- 모델 / 추론 설정: z-ai/glm-5.3-flash / low
- Chat 이름 / 세션 JSON: tools-lesson08 / 내보내기 전
- 이어받은 것: 7교시의 SPEC.md·PLAN.md·인수조건과 P1 입력 검사 코드
- prepare / healthy / check start 결과: PREPARE_PASS / healthy / START_READY
- 시작 검사 파일: check-start-20260911T153645463655Z-3de0a7.json

## 2. 도구 정책 검토
- 정책 단계 변경 파일: TOOL_POLICY.md 하나
- 최초 작성 도구: Read File 13회, Write File 1회
- 최초 검토 의견: CSV 읽기 범위, 읽기 기록, 실행 장소와 로그 작성 주체, 프로그램 출력 권한, 환경 정보와 재검사 표현을 보완해야 한다.
- 보완 요청 / 결과: 여덟 항목의 보완을 요청했다. 두 CSV로 읽기를 한정하고, 세션의 읽기 이력·일반 컨테이너 실행·자동 로그 수집·분석 프로그램의 결과 쓰기를 구분했다. 읽기 전용 지시와 강제 제한을 나누고, 미확인 Python 버전을 생략했으며 재검사를 한 번으로 통일했다.
- 보완 도구 / 변경 파일: Write File 1회 / TOOL_POLICY.md
- 보완 후 검사 결과 / 파일명: CHECK_PASS: policy / check-policy-20260911T155929570809Z-359a70.json
- 보완 후 정책 해시: 818371c919aee8aea723aeb5a3fc2eb1a0a6322e9e878fb541737c14177cf8b0
- 실행 주체: 교육생이 PowerShell에서 lesson08.ps1 test를 실행하고, 일반 Hermes 컨테이너의 검사 도구가 분석 코드를 실행한다. Agent는 명령을 실행하지 않는다.
- 프로그램 결과: /workspace/outputs/lesson08-p2/summary.csv와 report.md. 모든 입력 검사 후 생성·교체하며 입력 오류에서는 기존 파일을 보존한다.
- 필요하지 않은 행동: 환율 조회·패키지 설치·설정·Memory·Skill 변경. 원 단위 집계는 표준 라이브러리로 수행한다.
- 문서와 제한의 구분: 정책은 행동 지시이며 읽기 전용 마운트는 환경의 제한이다. 정책 작성이 네트워크 강제 차단을 뜻하지 않는다.
- 응답 보관: policy_response.md / policy_revision_response.md
- 현재 판단: 보완된 정책을 검토했다. P2 구현은 아직 승인하지 않았다.
