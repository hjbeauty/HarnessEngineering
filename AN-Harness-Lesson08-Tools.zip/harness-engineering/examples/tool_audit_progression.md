# tool_audit.md를 채우는 순서

각 파일은 실제 실습을 바탕으로 한 누적 기록 예시입니다. 같은 records/lesson08/tool_audit.md에 자신의 결과를 누적합니다. 템플릿의 뒤쪽 절은 필요한 단계가 되었을 때 채웁니다.

| 실습 시점 | 갱신할 내용 | 누적 예시 |
|---|---|---|
| 단계 1 시작 검사 뒤 | 1절 시작 상태 작성 | [01_start.md](tool_audit_stages/01_start.md) |
| 단계 2 최초 정책 검토 뒤 | 2절에 문제와 보완할 내용을 기록 | [02_policy_initial.md](tool_audit_stages/02_policy_initial.md) |
| 단계 2 정책 보완·재검사 뒤 | 2절 작성, 필요하면 보완 결과까지 교체 | [02_policy.md](tool_audit_stages/02_policy.md) |
| 단계 3 승인 명령 뒤 | 2절 현재 판단 갱신, 3절 승인 내용 작성 | [03_approval.md](tool_audit_stages/03_approval.md) |
| 단계 4 구현 검사 뒤 | 3절 요청·실제 도구·검사 결과 갱신, 4절은 실행 전 | [04_implementation.md](tool_audit_stages/04_implementation.md) |
| 단계 5 네 실행과 사람 검토 뒤 | 4절 전체를 실제 결과로 교체 | [05_execution.md](tool_audit_stages/05_execution.md) |
| 단계 6 범위 질문·최종 검사 뒤 | 5절 작성, 1절 세션 파일명 갱신 | [06_final.md](tool_audit_stages/06_final.md) |

최종 예시 전체는 [tool_audit_example.md](tool_audit_example.md)입니다. 예시의 통과 표현을 자신의 검사 없이 완료 기록으로 사용하지 않습니다.

정책 보완은 1회였고 코드 실행 검사는 첫 검사에서 네 사례가 통과했습니다. 정책 보완을 코드 실패·재검사로 세지 않습니다. 최종 예시의 보고서 내용 검토 항목은 자신의 판단으로 완성합니다.
