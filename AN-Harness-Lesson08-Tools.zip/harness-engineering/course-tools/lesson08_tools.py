"""Trusted Python-only course helper. Does not invoke an Agent or export credentials.
The temporary helper alone receives /course-host; Dashboard mounts stay unchanged.
"""
import argparse, csv, copy, hashlib, json, os, platform, shutil, sys, uuid
from datetime import datetime, timezone
from pathlib import Path
import yaml

CSV_SHA='60f14a8cbe5fd6eba994ef2f6c43fbc714b232a3d7a37e60cb02ee6cdad9f0d8'
INPUT_HASHES={'inputs/lesson03/sales.csv': '60f14a8cbe5fd6eba994ef2f6c43fbc714b232a3d7a37e60cb02ee6cdad9f0d8', 'inputs/sales/sales_micro.csv': '38f24772be20f9ac7ee4118e232b23c48809492c24b7aaaee812f7cb8ded47f8', 'inputs/sales/errors/quantity_zero.csv': '5b204667cc3ed55f864c75a3a9a89fca2e4f6a0d200031fe2d766fa7de42140d'}
EXPECTED={'terminal.backend':'local','terminal.cwd':'/workspace','model.provider':'openrouter','model.default':'z-ai/glm-5.3-flash','agent.reasoning_effort':'low','agent.reasoning_overrides':None,'approvals.mode':'manual','memory.memory_enabled':False,'memory.user_profile_enabled':False,'skills.write_approval':True,'auxiliary.background_review.enabled':False,'auxiliary.title_generation.enabled':False}
EXTRA=['agent.disabled_toolsets','command_allowlist']

def stamp(): return datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')+'-'+uuid.uuid4().hex[:6]
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def require(ok,msg):
    if not ok: raise RuntimeError(msg)
def write_json(p,obj):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x',encoding='utf-8') as f: json.dump(obj,f,ensure_ascii=False,indent=2)
def tree(p):
    require(p.is_dir() and not p.is_symlink(),f'Not a regular directory: {p.name}')
    out={}
    for root,dirs,files in os.walk(p,followlinks=False):
        for n in dirs+files:
            q=Path(root)/n
            require(not q.is_symlink(),f'Links are not followed: {q.name}')
            require(q.is_file() or q.is_dir(),f'Unsupported file type: {q.name}')
            out[q.relative_to(p).as_posix()]='DIR' if q.is_dir() else sha(q)
    return out

def get(c,key):
    cur=c
    for part in key.split('.'):
        if not isinstance(cur,dict) or part not in cur: return {'present':False,'value':None}
        cur=cur[part]
    return {'present':True,'value':cur}
def put(c,key,item):
    parts=key.split('.'); cur=c
    for part in parts[:-1]:
        if part not in cur:
            if not item['present']: return
            cur[part]={}
        require(isinstance(cur[part],dict),'Config section is not a mapping')
        cur=cur[part]
    if item['present']: cur[parts[-1]]=item['value']
    else: cur.pop(parts[-1],None)
def settings(c): return {k:get(c,k) for k in list(EXPECTED)+EXTRA}
def acceptable(c):
    bad=[]
    for k,expected in EXPECTED.items():
        v=get(c,k)['value']
        if k=='agent.reasoning_overrides' and v in (None,{}): continue
        if type(v)!=type(expected) or v!=expected: bad.append(k)
    disabled=get(c,'agent.disabled_toolsets')['value']
    if not isinstance(disabled,list) or not {'memory','session_search'}.issubset(disabled): bad.append('agent.disabled_toolsets')
    return bad

def state_tree(home):
    return {n:tree(home/n) if (home/n).exists() else None for n in ('memories','skills')}
def capture(home,dest):
    dest.mkdir()
    meta={'settings':settings(yaml.safe_load((home/'config.yaml').read_text()) or {}),'trees':state_tree(home)}
    for n,t in meta['trees'].items():
        if t is not None: shutil.copytree(home/n,dest/n)
    require({n:tree(dest/n) if t is not None else None for n,t in meta['trees'].items()}==meta['trees'],'Harness backup differs.')
    write_json(dest/'state.json',meta)
    return meta

def verify_saved(cp):
    saved=json.loads((cp/'manifest.json').read_text())
    actual=tree(cp); actual.pop('manifest.json',None)
    require(actual==saved,'Checkpoint integrity failed. Preserve files; do not restore.')

SPEC_SHA='80813a38ca366a3a8e1e454e039a7d677cd5aebdfa1aa5edcdb836a557bc3475'

class Course:
    def __init__(self,host=Path('/course-host'),home=Path('/opt/data')):
        self.host=host; self.home=home; self.ws=host/'workspace'; self.records=host/'records'
        self.rec=self.records/'lesson08'; self.pending=self.records/'lesson08-pending.json'
        self.starter=host/'starter/lesson08'
    def config(self):
        p=self.home/'config.yaml'
        require(p.is_file() and not p.is_symlink(),'Config must be a regular file.')
        return yaml.safe_load(p.read_text()) or {}
    def guard(self):
        require(not self.pending.exists(),'Pending operation exists. Preserve lesson08-pending.json and all backups.')
        for p in [self.host,self.home,self.records,self.ws]:
            require(p.is_dir() and not p.is_symlink(),f'Expected regular directory: {p.name}')
        for name,h in INPUT_HASHES.items():require(sha(self.host/name)==h,'Common input missing or changed: '+name)
    def journal(self,action,backup):write_json(self.pending,{'action':action,'backup':str(backup),'started_utc':stamp()})
    def prior_records(self):
        return {n:tree(self.records/n) for n in ('lesson03','lesson04','lesson05','lesson06','lesson07') if (self.records/n).exists()}
    def preflight(self):
        self.guard()
        require(not self.rec.exists(),'Lesson08 already prepared. Continue your stage or use restore.')
        require(not acceptable(self.config()),'Settings differ: '+', '.join(acceptable(self.config())))
        require(sha(self.ws/'SPEC.md')==SPEC_SHA,'Complete Lesson07 with the common SPEC first.')
        tree(self.ws);tree(self.starter);tree(self.host/'inputs');state_tree(self.home)
        prior=self.records/'lesson07'
        receipt=json.loads((prior/'latest-probe.json').read_text())
        require(receipt.get('passed') is True and receipt.get('source_sha256')==sha(self.ws/'analyze_sales.py') and receipt.get('plan_sha256')==sha(self.ws/'PLAN.md'),'Lesson07 P1 result is missing or stale. Run Lesson07 test and final before preparing Lesson08.')
        require((self.ws/'lesson07/ACCEPTANCE.md').is_file(),'Lesson07 ACCEPTANCE.md is missing.')
        for name in ('TOOL_POLICY.md','lesson08','outputs/lesson08-p2'):
            require(not (self.ws/name).exists(),'Entry path already exists; preserve and inspect: '+name)
        print('PREFLIGHT_PASS: Lesson07 P1 source and plan match the saved result.')
    def prepare(self):
        self.preflight()
        self.journal('prepare',self.rec);self.rec.mkdir();cp=self.rec/'checkpoint';cp.mkdir()
        shutil.copytree(self.ws,self.rec/'prior-workspace')
        require(tree(self.ws)==tree(self.rec/'prior-workspace'),'Prior workspace backup differs.')
        capture(self.home,cp/'harness');write_json(cp/'inputs.json',tree(self.host/'inputs'))
        write_json(cp/'earlier-records.json',self.prior_records())
        entry=cp/'entry-workspace';shutil.copytree(self.ws,entry)
        shutil.copytree(self.starter,entry,dirs_exist_ok=True)
        shutil.copy2(entry/'lesson07/ACCEPTANCE.md',entry/'lesson08/ACCEPTANCE.md')
        (entry/'lesson08/checks').mkdir(exist_ok=True)
        (entry/'outputs/lesson08-p2').mkdir(parents=True,exist_ok=False)
        write_json(cp/'manifest.json',tree(cp));verify_saved(cp)
        self.ws.rename(self.rec/'workspace-before-prepare');shutil.copytree(entry,self.ws)
        require(tree(self.ws)==tree(entry),'Entry workspace differs.')
        shutil.copy2(self.host/'templates/tool_audit.md',self.rec/'tool_audit.md')
        write_json(self.rec/'prepared.json',{'spec_sha256':SPEC_SHA,'p1_source_sha256':sha(self.ws/'analyze_sales.py'),'entry':'checkpoint/entry-workspace','scope':'selected settings, memories, skills; credentials and session database excluded'})
        self.pending.rename(self.rec/'prepare-result.json')
        print('PREPARE_PASS: Lesson07 P1 preserved; Lesson08 entry checkpoint saved.')
    def compare(self,stage):
        self.guard();cp=self.rec/'checkpoint';verify_saved(cp)
        expected=tree(cp/'entry-workspace');actual=tree(self.ws)
        approval=None
        if stage in ('approved','implemented','final'):
            require((self.rec/'approved-policy.json').is_file(),'Approve the reviewed tool policy for P2 before implementation.')
            approval=json.loads((self.rec/'approved-policy.json').read_text())
            require(sha(self.rec/'approved-TOOL_POLICY.md')==approval['policy_sha256'],'Approved policy backup differs.')
            require(expected['PLAN.md']==approval['plan_sha256'] and sha(self.rec/'approved-PLAN.md')==approval['plan_sha256'],'Approved plan differs from entry or saved copy.')
            expected['TOOL_POLICY.md']=approval['policy_sha256']
            expected['lesson08/approval.json']=sha(self.rec/'approved-policy.json')
        if stage=='policy':
            require((self.ws/'TOOL_POLICY.md').is_file(),'TOOL_POLICY.md is missing.')
            require(sha(self.ws/'TOOL_POLICY.md')!=expected['TOOL_POLICY.md'],'TOOL_POLICY.md is still the blank template.')
            expected['TOOL_POLICY.md']=actual['TOOL_POLICY.md']
        if stage in ('implemented','final'):
            require((self.ws/'analyze_sales.py').is_file() and (self.ws/'analyze_sales.py').stat().st_size>0,'analyze_sales.py is missing or empty.')
            expected['analyze_sales.py']=actual['analyze_sales.py']
            # Only probe logs may be added here. This is an observation, not an OS ACL.
            for k,v in actual.items():
                if k.startswith('lesson08/checks/'):expected[k]=v
                if k in ('outputs/lesson08-p2/summary.csv','outputs/lesson08-p2/report.md'):expected[k]=v
        diffs=[k for k in sorted(set(expected)|set(actual)) if expected.get(k)!=actual.get(k)]
        saved=json.loads((cp/'harness/state.json').read_text());current=settings(self.config());sd=[]
        for k,v in saved['settings'].items():
            if k=='agent.reasoning_overrides' and v['value'] in (None,{}) and current[k]['value'] in (None,{}):continue
            if current[k]!=v:sd.append(k)
        state_ok=state_tree(self.home)==saved['trees']
        inputs_ok=tree(self.host/'inputs')==json.loads((cp/'inputs.json').read_text())
        prior_ok=self.prior_records()==json.loads((cp/'earlier-records.json').read_text())
        probe_ok=None
        if stage=='final':
            receipt=self.rec/'latest-probe.json'
            require(receipt.is_file(),'Run lesson08.ps1 test before final.')
            report=json.loads(receipt.read_text());src=self.ws/'analyze_sales.py'
            probe_ok=(report.get('passed') is True and report.get('source_sha256')==sha(src) and report.get('plan_sha256')==approval['plan_sha256'] and report.get('policy_sha256')==approval['policy_sha256'] and report.get('output_hashes')=={n:sha(self.ws/'outputs/lesson08-p2'/n) if (self.ws/'outputs/lesson08-p2'/n).is_file() else None for n in ('summary.csv','report.md')})
        out={'stage':stage,'workspace_matches':not diffs,'workspace_differences':diffs,'settings_match':not sd,'settings_differences':sd,'memory_and_skills_unchanged':state_ok,'common_inputs_unchanged':inputs_ok,'earlier_lesson_records_unchanged':prior_ok,'spec_sha256':sha(self.ws/'SPEC.md') if (self.ws/'SPEC.md').is_file() else None,'plan_sha256':sha(self.ws/'PLAN.md') if (self.ws/'PLAN.md').is_file() else None,'policy_sha256':sha(self.ws/'TOOL_POLICY.md') if (self.ws/'TOOL_POLICY.md').is_file() else None,'p2_probe_current_and_passed':probe_ok,'scope':'Stage-specific file observations and saved settings; review plan quality, actual tool use and approval in the Chat.'}
        p=self.rec/('check-'+stage+'-'+stamp()+'.json');write_json(p,out)
        print(json.dumps(out,ensure_ascii=False,indent=2));print('RECORDED: records/lesson08/'+p.name)
        require(not diffs and not sd and state_ok and inputs_ok and prior_ok and probe_ok is not False,'CHECK_STOPPED: preserve the evidence; inspect differences before continuing.')
        print('START_READY' if stage=='start' else 'CHECK_PASS: '+stage)
        return out
    def approve(self):
        require(not (self.rec/'approved-policy.json').exists(),'P2 approval already exists. Preserve its history.')
        self.compare('policy')
        p=self.ws/'TOOL_POLICY.md';content=p.read_text(encoding='utf-8-sig')
        require(all(x in content for x in ('P2','analyze_sales.py','lesson08.ps1 test','/workspace/outputs/lesson08-p2')),'Policy must name P2, its code, test command and output folder. Review the TASK.')
        shutil.copy2(p,self.rec/'approved-TOOL_POLICY.md')
        shutil.copy2(self.ws/'PLAN.md',self.rec/'approved-PLAN.md')
        value={'approved_step':'P2','plan_sha256':sha(self.ws/'PLAN.md'),'policy_sha256':sha(p),'created_utc':stamp(),'allowed_change':['analyze_sales.py'],'allowed_execution':'Student runs lesson08.ps1 test; Agent does not run commands','approval_scope':'P2 implementation only; no P3, settings, Memory or Skill changes. Not a blanket tool permission.'}
        write_json(self.rec/'approved-policy.json',value)
        shutil.copy2(self.rec/'approved-policy.json',self.ws/'lesson08/approval.json')
        print('APPROVE_PASS: reviewed policy saved; P2 only. Send the P2 request in Hermes Chat.')
    def collect(self):
        # Called after the probe in the normal container; never runs Agent code with /course-host.
        self.guard();files=sorted((self.ws/'lesson08/checks').glob('p2-*/report.json'))
        require(files,'No P2 probe report found.')
        tree(self.ws)
        p=files[-1];report=json.loads(p.read_text())
        require(report.get('source_sha256')==sha(self.ws/'analyze_sales.py'),'Probe is stale. Program changed; test again.')
        dest=self.rec/'probe-runs'/p.parent.name
        if not dest.exists():shutil.copytree(p.parent,dest)
        require(tree(p.parent)==tree(dest),'Probe backup differs.')
        latest=self.rec/'latest-probe.json'
        temp=self.rec/('probe-receipt-'+stamp()+'.json');write_json(temp,report);os.replace(temp,latest)
        print('RECORDED: records/lesson08/probe-runs/'+p.parent.name+'/report.json')
        self.compare('implemented')
        require(report.get('policy_sha256')==sha(self.ws/'TOOL_POLICY.md') and report.get('plan_sha256')==sha(self.ws/'PLAN.md'),'Probe policy/plan differs from current files.')
        require(report.get('passed') is True,'P2_CHECK_STOPPED: inspect case logs; correct only approved P2 scope.')
        print('P2_CHECK_PASS: four executions passed. Review report content and tool history; P3 remains outside scope.')
    def restore(self):
        self.guard();cp=self.rec/'checkpoint';verify_saved(cp)
        require((self.rec/'prepared.json').is_file(),'Preparation incomplete; preserve journal.')
        tree(self.ws);state_tree(self.home);self.config()
        attempt=self.records/('lesson08-attempt-'+stamp());self.journal('restore',attempt);attempt.mkdir()
        shutil.copytree(self.ws,attempt/'workspace-after-attempt')
        require(tree(self.ws)==tree(attempt/'workspace-after-attempt'),'Attempt copy differs.')
        capture(self.home,attempt/'harness-after-attempt')
        shutil.copytree(cp,attempt/'checkpoint');verify_saved(attempt/'checkpoint')
        saved=json.loads((cp/'harness/state.json').read_text());c=self.config()
        for k,v in saved['settings'].items():put(c,k,v)
        config_path=self.home/'config.yaml';temp=self.home/('lesson08-config-'+uuid.uuid4().hex+'.tmp')
        temp.write_text(yaml.safe_dump(c,allow_unicode=True,sort_keys=False),encoding='utf-8');temp.chmod(config_path.stat().st_mode & 0o777);os.replace(temp,config_path)
        for n,t in saved['trees'].items():
            p=self.home/n
            if p.exists():shutil.rmtree(p)
            if t is not None:shutil.copytree(cp/'harness'/n,p)
        self.ws.rename(attempt/'workspace-moved');shutil.copytree(cp/'entry-workspace',self.ws)
        self.rec.rename(attempt/'lesson08-records');self.rec.mkdir()
        shutil.copytree(attempt/'checkpoint',self.rec/'checkpoint')
        shutil.copy2(attempt/'lesson08-records/prepared.json',self.rec/'prepared.json')
        shutil.copy2(self.host/'templates/tool_audit.md',self.rec/'tool_audit.md')
        require(tree(self.ws)==tree(self.rec/'checkpoint/entry-workspace'),'Restored workspace differs.')
        require(settings(self.config())==saved['settings'] and state_tree(self.home)==saved['trees'],'Restored Harness state differs.')
        self.pending.rename(attempt/'restore-result.json')
        print('RESTORE_PASS: Lesson08 entry restored; P1 code retained, blank policy, no P2 approval.')
        print('BACKUP: records/'+attempt.name)
        print('Start Hermes, open a NEW Chat, then check start. Do not repeat prepare.')

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('action',choices=['preflight','prepare','check','approve','collect','restore']);ap.add_argument('stage',nargs='?',default='start',choices=['start','policy','approved','implemented','final']);args=ap.parse_args()
    try:
        require(os.getuid()!=0,'Run as hermes, not root.')
        c=Course()
        if args.action=='check':c.compare(args.stage)
        else:getattr(c,args.action)()
    except Exception as e:
        print('STOP: '+str(e),file=sys.stderr);sys.exit(1)
