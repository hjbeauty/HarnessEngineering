"""P2 four-execution checks in the normal Hermes container, without /course-host.
Reference values are fixed course fixture arithmetic, independent of Agent code.
No claim of whole-SPEC coverage or network isolation is made.
"""
import csv,hashlib,io,json,os,re,signal,subprocess,sys,uuid
from pathlib import Path
from datetime import datetime,timezone
TIMEOUT=15
EXPECTED=[['section','name','value'],['total','revenue','56000'],['total','units','19'],
 ['category','Accessory','16000'],['category','Monitor','18000'],['category','Office','5000'],['category','Storage','17000'],
 ['product_top3','USB Drive 128GB','16000'],['product_top3','27-inch Monitor','13000'],['product_top3','Laptop Stand','12000']]
TARGETS=('summary.csv','report.md')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def hashes(out):return {n:sha(out/n) if (out/n).is_file() and not (out/n).is_symlink() else None for n in TARGETS}
def regular_tree(root):
    for parent,dirs,files in os.walk(root,followlinks=False):
        for n in dirs+files:
            p=Path(parent)/n
            if p.is_symlink() or not (p.is_dir() or p.is_file()):raise RuntimeError('Unsupported probe file type: '+n)
def summary_matches(output):
    try:return list(csv.reader(io.StringIO((output/'summary.csv').read_text(encoding='utf-8-sig'),newline='')))==EXPECTED
    except (OSError,UnicodeError,csv.Error):return False
def report_readable(output):
    try:return bool((output/'report.md').read_text(encoding='utf-8-sig').strip())
    except (OSError,UnicodeError):return False

def run(ws=Path('/workspace'),inputs=Path('/inputs')):
    if Path('/course-host').exists():raise RuntimeError('Do not execute Agent code in the management container.')
    src=ws/'analyze_sales.py';approval=ws/'lesson08/approval.json';out=ws/'outputs/lesson08-p2'
    for p in (ws,src,approval,ws/'outputs',out,ws/'lesson08',ws/'lesson08/checks'):
        if p.is_symlink():raise RuntimeError('Probe paths must not be symbolic links.')
    regular_tree(ws)
    a=json.loads(approval.read_text())
    if a['approved_step']!='P2' or sha(ws/'PLAN.md')!=a['plan_sha256'] or sha(ws/'TOOL_POLICY.md')!=a['policy_sha256']:raise RuntimeError('Current plan/policy differs from P2 approval.')
    missing=inputs/'lesson08-file-does-not-exist.csv'
    if missing.exists():raise RuntimeError('Missing-input fixture unexpectedly exists.')
    runid='p2-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')+'-'+uuid.uuid4().hex[:6]
    folder=ws/'lesson08/checks'/runid;folder.mkdir()
    source_hash=sha(src)
    cases=[('valid_micro',inputs/'sales/sales_micro.csv',0),('repeat_micro',inputs/'sales/sales_micro.csv',0),('quantity_zero',inputs/'sales/errors/quantity_zero.csv',2),('missing_input',missing,2)]
    results=[];first_hashes=None;first_valid=False
    for name,path,expected in cases:
        before=hashes(out)
        cmd=[sys.executable,str(src),'--input',str(path),'--output-dir',str(out)]
        # Do not deliberately pass the model key or the full Hermes environment to analysis.
        # This reduces inheritance; it does not enforce a network/filesystem sandbox.
        env={k:os.environ[k] for k in ('PATH','LANG','LC_ALL','TZ','SYSTEMROOT') if k in os.environ}
        env['PYTHONDONTWRITEBYTECODE']='1';env['PYTHONIOENCODING']='utf-8'
        proc=subprocess.Popen(cmd,cwd=ws,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,encoding='utf-8',errors='replace',start_new_session=True)
        timeout=False
        try:stdout,stderr=proc.communicate(timeout=TIMEOUT)
        except subprocess.TimeoutExpired:
            timeout=True;os.killpg(proc.pid,signal.SIGKILL);stdout,stderr=proc.communicate()
        (folder/(name+'.stdout.txt')).write_text(stdout,encoding='utf-8')
        (folder/(name+'.stderr.txt')).write_text(stderr,encoding='utf-8')
        regular_tree(out)
        after=hashes(out);present=all(v is not None for v in after.values())
        checks={'exit_code_matches':proc.returncode==expected,'no_timeout':not timeout}
        if expected==0:
            checks.update(summary_matches=present and summary_matches(out),report_utf8_nonempty=present and report_readable(out))
            if name=='repeat_micro':checks['repeat_bytes_equal']=first_valid and after==first_hashes
        else:
            checks['diagnostic_matches']=(bool(re.search(r'(?<!\d)5(?!\d)',stderr)) and 'quantity' in stderr) if name=='quantity_zero' else 'INPUT_NOT_FOUND' in stderr
            checks['existing_outputs_preserved']=first_valid and present and before==after
        result={'case':name,'command':cmd,'expected_exit_code':expected,'actual_exit_code':proc.returncode,'checks':checks,'before_output_hashes':before,'after_output_hashes':after,'passed':all(checks.values())}
        if name=='valid_micro':first_hashes=after;first_valid=result['passed']
        for n in TARGETS:
            if (out/n).is_file() and not (out/n).is_symlink():(folder/(name+'.'+n)).write_bytes((out/n).read_bytes())
        results.append(result)
        print(('PASS ' if result['passed'] else 'FAIL ')+name+': exit='+str(proc.returncode))
    unchanged=src.is_file() and not src.is_symlink() and sha(src)==source_hash
    report={'scope':'P2 micro-output, repeat, quantity-zero and missing-input checks. Report meaning and actual tool use require human review; not whole-SPEC acceptance.',
      'run_id':runid,'source_sha256':source_hash,'plan_sha256':a['plan_sha256'],'policy_sha256':a['policy_sha256'],'cases':results,'output_hashes':hashes(out),'source_unchanged':unchanged,'passed':all(x['passed'] for x in results) and unchanged}
    (folder/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print('PROBE_REPORT: '+str(folder/'report.json'));return report
if __name__=='__main__':
    try:
        if os.getuid()==0:raise RuntimeError('Run as hermes, not root.')
        sys.exit(0 if run()['passed'] else 1)
    except Exception as e:print('PROBE_STOP: '+str(e),file=sys.stderr);sys.exit(1)
