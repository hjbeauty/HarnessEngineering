# 8교시: 필요한 도구 범위에서 P2 완성하기

## 목적
7교시의 P1 입력 검사 코드에 P2 계산과 두 결과 파일 생성을 추가합니다. PLAN.md의 P2를 진행하며 SPEC.md와 AC-01·AC-02·AC-03을 근거로 삼습니다. P3의 관계 검사 등은 이번 범위에 포함하지 않습니다.

## 단계와 변경 파일
- 정책 단계: Agent는 TOOL_POLICY.md만 작성합니다. 교육생이 읽고 필요한 보완을 요청합니다.
- 승인 단계: 교육생이 lesson08.ps1 approve로 P2 승인 기록을 남깁니다. 이때 PLAN과 정책의 해시가 함께 기록됩니다.
- 구현 단계: Agent는 lesson08/approval.json을 확인하고 analyze_sales.py만 수정합니다. 계획·정책·명세·승인 파일은 고정합니다.
- 실행 단계: 교육생이 lesson08.ps1 test를 실행합니다. Agent는 Terminal·Python 실행·py_compile·lint·패키지 설치·외부 검색을 하지 않습니다.

## P1과 P2의 차이
P1은 정상 입력에서 INPUT_VALID rows=N만 출력했습니다. P2에서는 P1 입력 규칙과 오류 정책을 유지하고, 정상 입력이면 SPEC 3절에 맞는 summary.csv와 report.md를 생성합니다. P1의 stdout 문자열은 P2 통과 조건이 아닙니다. 이전 lesson07 test는 P1의 무출력·보존 계약을 검사하므로 P2 구현 뒤 다시 실행하지 않습니다.

## 결과 위치와 내용
- 실행 인터페이스: python analyze_sales.py --input 입력경로 --output-dir 결과폴더
- 이번 결과 폴더: /workspace/outputs/lesson08-p2
- summary.csv: section,name,value 열. total 2행, 카테고리 이름 순, 매출 상위 제품 순으로 씁니다.
- report.md: UTF-8 한국어 문서. 총매출·카테고리 집계·상위 3개 제품과 금액을 구분하고 원 단위를 표시합니다. 제목·표 모양은 필수 내용을 만족하는 범위에서 선택합니다.
- 모든 입력 검사 후 결과를 생성·교체합니다. 수량 0을 제외하고 계산을 계속하는 등 임의 보정은 하지 않습니다.
- 동일 입력을 두 번 실행했을 때 각 파일의 바이트가 같아야 합니다. 현재 시각·입력 파일명·임시 경로를 결과에 넣지 않습니다.

## 확인할 네 번의 실행
1. valid_micro: sales_micro.csv. 종료코드 0, 총매출 56000, 총수량 19, 지정 집계·순서, 두 결과 파일.
2. repeat_micro: 같은 입력·같은 결과 폴더로 재실행. 종료코드 0, 첫 실행과 파일별 SHA-256 동일.
3. quantity_zero: errors/quantity_zero.csv. 종료코드 2, stderr에 CSV 레코드 5·quantity·위반 이유 또는 코드. 직전 정상 출력 유지.
4. missing_input: 존재하지 않는 /inputs/lesson08-file-does-not-exist.csv. 종료코드 2, INPUT_NOT_FOUND. 직전 정상 출력 유지.

검사 도구는 각 실행을 최대 15초 기다립니다. 네트워크·추가 라이브러리는 이 분석에 필요하지 않습니다. 요약 CSV의 전체 값과 순서, 반복 바이트, 보존을 자동 검사합니다. 보고서 의미·오류 설명의 적절성·실제 도구 범위 준수는 사람이 읽어 판정합니다. 네 실행 통과를 전체 SPEC 또는 P3 완료라고 하지 않습니다.

## 실패 시
교육생이 로그를 보존하고 원인을 확인합니다. 승인 범위의 코드 문제이면 Agent에게 해당 문제만 수정하도록 요청하고 한 번 재검사합니다. 재실패하거나 정책·계획 변경이 필요하면 멈추고 기록합니다. 처음부터 다시 진행할 때는 교육생이 조건부 restore를 사용합니다.
