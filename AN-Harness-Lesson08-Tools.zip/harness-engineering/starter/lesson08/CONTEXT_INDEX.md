# Context를 읽는 순서

적용 범위: 8교시 도구 정책과 P2 계산·출력 구현.

1. context/constraints.md: 이번 단계의 권한과 변경 범위
2. context/environment.md: 이어받은 실행 환경
3. context/sales_business_context.md: 단가·매출·해석의 의미
4. context/conventions.md: UTF-8·한국어 등 작성 관례
5. SPEC.md: 공통 입력·출력 계약
6. PLAN.md: 7교시에서 검토한 P1·P2·P3 계획
7. lesson08/ACCEPTANCE.md: 이어받은 AC-01·AC-02·AC-03
8. lesson08/TASK.md: 이번 P2 작업과 시험
9. TOOL_POLICY.md: 작성 중이거나 승인된 도구 사용 정책
10. analyze_sales.py: 7교시에서 만든 P1 코드

추가 읽기 입력은 /inputs/sales/sales_micro.csv와 /inputs/sales/errors/quantity_zero.csv입니다. 승인 구현 요청에서는 lesson08/approval.json도 읽습니다. 실제 실행과 관찰하지 않은 결과를 완료로 쓰지 않습니다.
