# 8교시 실습 자료

**AI Native 소프트웨어 개발: Harness Engineering — 학습 가이드북**

`08_tool_harness_preview.html`을 브라우저에서 열거나 `08_tool_harness.md`를 읽으며 시작합니다. 본문에 폴더·파일·PowerShell·Python 프로그램의 역할과 요청문·기대 출력·기록 방법을 설명했습니다. 같은 역할 설명을 `08_files_commands.md`에서도 볼 수 있습니다.

ZIP의 `harness-engineering` 폴더 내용을 기존 `C:\AI-Native\harness-engineering`에 합칩니다. `lesson08.ps1`과 기존 `compose.yaml`이 같은 위치에 있어야 합니다. 개인 workspace·records·인증 정보·Compose·공통 CSV와 앞 교시 스크립트는 포함하지 않습니다. 앞 교시 작업 폴더를 삭제하지 않습니다.

7교시에서 P1 실행 검사와 최종 검사를 통과한 상태가 필요합니다. 8교시 prepare는 이전 상태를 확인하고 보존합니다. 정상 진행은 prepare → healthy·새 Chat·check start → 정책 작성·검토 → P2 승인 → 구현 → 네 실행·사람 검토 → 최종 기록 순서입니다.

실수로 시작 지점부터 다시 해야 할 때만 가이드북 7절의 restore를 사용합니다. 복원 뒤에는 prepare를 반복하지 않고 컨테이너 시작·새 Chat·check start 뒤 정책 작성부터 진행합니다.

`templates/tool_audit.md`는 빈 양식, `examples/tool_audit_stages`는 단계별 작성 흐름, `examples/tool_audit_example.md`는 실제 실습을 바탕으로 한 최종 기록 예시입니다. 자신의 실제 결과로 기록합니다.

`PACKAGE_SHA256.json`은 ZIP에 배포된 파일의 SHA-256 목록입니다. 프로그램 실행 성공을 나타내는 보고서가 아닙니다.
