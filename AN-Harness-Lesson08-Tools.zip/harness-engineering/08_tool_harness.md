# 08. Tool Harness: 필요한 도구와 권한만 사용하기

**AI Native 소프트웨어 개발: Harness Engineering — 학습 가이드북**

## 1) 이번 교시에서 해결할 문제

입력 검사를 끝낸 Agent가 “계산에 필요한 패키지를 설치하고, 인터넷에서 환율도 찾아오겠습니다”라고 한다면 그대로 진행해도 될까요? 이번 판매 데이터는 원 단위로 주어져 있고, Python에 기본으로 포함된 기능으로 처리할 수 있습니다. 먼저 해야 할 일과 사용할 도구의 범위를 정하면 이런 불필요한 작업을 줄일 수 있습니다.

7교시에서는 전체 작업을 P1 입력 검사, P2 계산·보고서 생성, P3 더 넓은 검증으로 나누고 P1을 구현했습니다. 이번에는 **P2를 승인할 때 필요한 읽기·쓰기·실행의 범위를 정한 뒤 실제 코드와 결과를 확인**합니다. 도구 사용 정책은 “누가, 어느 파일에, 어떤 행동을 할 수 있는가”를 적은 작업 규칙입니다.

Agent가 `analyze_sales.py`에 계산과 출력을 추가하면 교육생이 네 번 실행합니다. **정상 10행**, **같은 입력 재실행**, **수량 0인 오류 입력**, **없는 입력 파일**을 차례대로 사용합니다. 첫 실행에서는 결과를 만들고, 나머지 실행에서는 결과가 반복 가능하고 오류에도 보존되는지 확인합니다.

## 2) 학습목표와 완료 상태

- 작업에 필요한 도구와 대상 경로를 구체적으로 정할 수 있습니다.
- 정책 문서의 지시와 실제 환경에서 강제되는 제한을 구분할 수 있습니다.
- 승인한 P2만 구현하고, 네 번의 실행 결과와 실제 도구 사용을 근거로 판단할 수 있습니다.

완료하면 `workspace/TOOL_POLICY.md`, P2가 추가된 `workspace/analyze_sales.py`, `workspace/outputs/lesson08-p2/summary.csv`와 `report.md`, `records/lesson08/tool_audit.md` 및 실행·세션 기록이 남습니다. **전체 명세의 모든 입력을 검증하는 P3는 이번 완료 범위에 포함하지 않습니다.**

## 3) 시작 전 준비와 파일의 역할

### 3.1 이어받을 상태 확인

사용 화면은 **Windows PowerShell, Hermes 웹 대시보드, 메모장**입니다. Windows 작업 폴더는 `C:\AI-Native\harness-engineering`입니다. 이 문서의 `powershell` 블록은 모두 Windows PowerShell에 입력합니다. Hermes 요청문은 웹 대시보드의 Chat에 넣습니다.

2·3교시에서 설치·모델 연결·Baseline 보존을 마치고, 7교시에서 P1의 세 사례 검사와 최종 검사를 통과한 상태로 시작합니다. Baseline은 이후 결과와 비교할 수 있도록 보관한 3교시의 최초 실행 기록입니다.

| 필요한 상태 | 이번에 필요한 이유 |
|---|---|
| 7교시의 현재 `analyze_sales.py`와 통과한 실행 기록 | P1을 그대로 이어받아 P2만 추가하기 위해 |
| 검토·승인한 `PLAN.md`와 공통 `SPEC.md` | P2의 범위와 계산·출력 기준을 확인하기 위해 |
| `workspace/lesson07/ACCEPTANCE.md` | AC-01 정상 입력, AC-02 오류와 보존, AC-03 반복 실행의 확인 기준을 이어받기 위해 |
| 3교시 Baseline 및 공통 입력 | 이전 기록과 원본을 유지했는지 확인하기 위해 |

`prepare`는 현재 P1 코드·PLAN이 7교시의 통과 기록과 일치하는지 먼저 확인합니다. 이어서 `lesson07.ps1 check final`과 Baseline 검사를 실행합니다. 이전 교시의 필수 상태가 맞지 않으면 화면의 이유를 해결하고 다시 준비합니다. **P1 미완료 상태를 P2 완료 코드로 대신 덮어쓰는 방식은 사용하지 않습니다.**

### 3.2 Windows와 컨테이너의 경로

컨테이너는 Hermes와 분석 프로그램을 실행하는 별도의 Linux 실행 환경입니다. 교육생은 Windows에서 명령을 입력하고, 스크립트가 Docker를 통해 컨테이너의 프로그램을 호출합니다. 이번 실습에서 Ubuntu 터미널을 따로 열 필요는 없습니다.

| Windows에서 보이는 위치 | 컨테이너에서 보이는 위치 | 용도 |
|---|---|---|
| `workspace/` | `/workspace/` | Agent가 읽는 문서와 수정하는 코드 |
| `inputs/` | `/inputs/` | 읽기 전용 원본 CSV |
| `course-tools/` | `/course-tools/` | 읽기 전용 교육용 검사 프로그램 |
| `records/lesson08/` | 일반 Chat에 별도 기록 경로로 제공하지 않음 | 교육생의 관찰 기록·승인 사본·수집된 실행 로그 |

`prepare`나 `restore`를 실행하면 `lesson08.ps1`이 준비·백업 작업을 맡을 **관리용 보조 컨테이너**를 잠깐 실행합니다. 이 안에서 교육용 관리 프로그램인 `lesson08_tools.py`가 시작 파일을 준비하거나 작업 기록을 보관합니다. 교육생이 이 컨테이너에 직접 접속할 필요는 없습니다.

**`/course-host`는 Windows의 프로젝트 폴더 `C:\AI-Native\harness-engineering`을 관리용 보조 컨테이너 안에서 찾아갈 때 사용하는 경로입니다.** Docker가 두 경로를 연결하므로, 관리 프로그램은 다음과 같은 이름으로 Windows의 파일에 접근합니다.

| Windows에 있는 폴더 | 관리용 보조 컨테이너 안의 경로 | 관리 프로그램이 하는 일 |
|---|---|---|
| `C:\AI-Native\harness-engineering\starter` | `/course-host/starter` | 교시 시작 자료를 읽음 |
| `C:\AI-Native\harness-engineering\workspace` | `/course-host/workspace` | 실습할 작업 파일을 준비하거나 복원함 |
| `C:\AI-Native\harness-engineering\records` | `/course-host/records` | 이전 작업과 검사·승인 기록을 보관함 |

이 연결은 파일을 다른 곳에 복사하는 것이 아닙니다. 예를 들어 관리 프로그램이 `/course-host/records`에 백업을 저장하면 Windows의 `records` 폴더에도 그 파일이 보입니다. 시작 자료·작업 파일·기록 폴더를 함께 다뤄야 하므로 프로젝트 폴더 전체를 연결하는 것입니다.

Agent가 작성한 `analyze_sales.py`는 **일반 Hermes 컨테이너에서 실행**합니다. 여기서는 코드가 `/workspace/analyze_sales.py`에 보이고, 관리용 연결인 `/course-host`는 추가하지 않습니다. 백업과 승인 기록을 다루는 넓은 접근 범위에서 분석 코드가 실행되지 않도록 실행 장소를 구분한 것입니다. 이 구분과 별도로, 실제 도구 사용과 파일 변경이 허용 범위에 맞았는지도 확인합니다.

### 3.3 사용하는 폴더와 파일

`starter`는 시작 자료, `workspace`는 실제 작업 공간, `templates`는 빈 기록 양식, `records`는 교육생의 기록, `examples`는 작성 방법을 보는 예시입니다. 예시를 읽는 것과 자신의 결과를 기록하는 것은 별개의 작업입니다.

| 폴더·파일 | 주요 내용과 역할 | 누가 언제 사용하는가 |
|---|---|---|
| `starter/lesson08/` | 현재 경계·읽기 순서·빈 정책·실습 요청문 | `prepare`가 workspace에 복사. 교육생은 starter를 편집하지 않음 |
| `workspace/CONTEXT_INDEX.md` | 문서와 코드를 읽을 순서 | 새 Chat에서 Agent가 먼저 읽음 |
| `workspace/context/` | 경계, 환경, 판매 데이터 의미, 작성 관례의 네 문서 | Agent와 교육생이 판단 근거로 읽음. 준비 시 8교시 경계만 바뀜 |
| `workspace/SPEC.md` | 입력·계산·출력·오류·정렬 기준 | 6교시 정본을 그대로 읽음 |
| `workspace/PLAN.md` | P1·P2·P3의 계획 | 7교시 검토본을 그대로 읽음 |
| `workspace/TOOL_POLICY.md` | 행동별 주체·대상·조건·기록 | 정책 단계에서 Agent가 작성. 승인 후 고정 |
| `workspace/analyze_sales.py` | P1 입력 검사에 P2 계산·출력을 추가할 코드 | 승인 뒤 Agent가 이 파일만 수정 |
| `workspace/lesson08/TASK.md` | P2의 작업 범위, 네 실행, 성공 기준 | 모든 단계의 작업 안내 |
| `workspace/lesson08/ACCEPTANCE.md` | 7교시에서 이어받은 인수조건 사본 | `prepare`가 복사. 인수조건은 완료 여부를 판단할 약속 |
| `workspace/lesson08/*_request.txt` | 정책 작성, P2 구현, 범위 판단의 요청문 | 해당 단계에서 PowerShell로 클립보드에 복사 후 Chat에 전송 |
| `workspace/lesson08/approval.json` | P2 승인 단계와 승인한 PLAN·정책 해시 | `approve`가 생성, Agent는 읽기만 함 |
| `inputs/sales/sales_micro.csv` | 손으로도 계산을 확인할 수 있는 정상 10행 | 정상·반복 실행에 사용 |
| `inputs/sales/errors/quantity_zero.csv` | 레코드 5의 quantity가 0인 입력 | 오류 위치와 결과 보존 확인 |
| `workspace/outputs/lesson08-p2/` | 프로그램의 `summary.csv`, `report.md` | 정상 실행이 생성·교체. 오류 실행은 기존 바이트 유지 |
| `workspace/lesson08/checks/p2-…/` | 실행별 명령·stdout·stderr·출력 사본·검사 보고서 | 검사 도구가 자동 생성 |
| `templates/tool_audit.md` | 비어 있는 관찰 기록 양식 | `prepare`가 records로 복사 |
| `records/lesson08/tool_audit.md` | 처음부터 마지막까지 누적하는 나의 기록 | 교육생이 메모장에서 단계별로 작성 |
| `records/lesson08/check-*.json` | 파일·저장 설정의 단계별 관찰 | `check`와 일부 명령이 자동 생성 |
| `records/lesson08/approved-TOOL_POLICY.md`, `approved-PLAN.md`, `approved-policy.json` | 승인한 문서 사본과 승인 정보 | `approve`가 생성. 이후 변경 여부를 대조 |
| `records/lesson08/probe-runs/p2-…/` | workspace 검사 로그의 보관 사본 | `test`가 실행 뒤 수집 |
| `records/lesson08/latest-probe.json` | 가장 최근 수집한 실행 보고서 | 최종 검사와 실행 폴더 찾기에 사용 |
| `records/lesson08/*_response.md`, `session*.json` | Agent 응답 원문과 대화·도구 이력 | 교육생이 저장·내보내 보관 |
| `records/lesson08/checkpoint/` | 시작 파일·관련 설정·Memory·Skill의 복원 원본 | prepare가 보관. 직접 편집하지 않음 |
| `records/lesson08/prior-workspace/` 등 준비 백업 | 준비 전 작업의 보존 사본 | 관리 도구가 보관 |
| `records/lesson08-attempt-…/` | 복원 전 시도의 작업과 기록 | restore 때 자동 생성 |
| `examples/tool_audit_stages/` | 기록이 단계마다 늘어나는 예시 | 필요할 때 참고. 자신의 기록을 대신하지 않음 |

### 3.4 스크립트는 무엇을 하는가

| 파일 | 역할 | 분석 코드를 실행하는가 |
|---|---|---|
| `lesson08.ps1` | PowerShell의 실행 창구. 검사 순서, 컨테이너 중지·시작, Python 호출을 연결 | `test`에서 일반 컨테이너의 검사 도구를 호출 |
| `course-tools/lesson08_tools.py` | 진입 조건 확인, 시작 상태 백업, 승인 저장, 파일·설정 비교, 로그 수집, 복원 | 직접 실행하지 않음 |
| `course-tools/lesson08_probe.py` | 네 번의 실행과 기대값 비교, 출력·오류·파일 해시 기록 | 일반 컨테이너에서 실행당 최대 15초 기다림 |
| 기존 `lesson07.ps1` | 8교시 준비 전에 P1 완료 상태 확인 | 준비 과정에서는 final 검사만 호출 |
| 기존 `lesson03.ps1` | Baseline이 보존됐는지 확인 | `verify`만 사용 |

`probe`는 준비된 입력을 넣어 동작을 확인하는 검사 프로그램입니다. `check`가 작업 파일과 설정을 살펴보는 것과 달리, `test`는 실제로 분석 코드를 실행합니다.

```mermaid
flowchart TD
  P["PowerShell · lesson08.ps1"] --> M["관리 도구 · 준비와 기록"]
  P --> T["일반 컨테이너 · 실행 검사"]
  T --> C["analyze_sales.py"]
  C --> O["결과 파일과 오류 메시지"]
  O --> M
```

아래 명령표는 역할을 미리 보는 표입니다. 지금 한꺼번에 실행하지 않고 단계별 실습의 순서를 따릅니다.

| 명령 | 목적과 변경되는 것 |
|---|---|
| `prepare` | P1 완료 확인, 이전 작업 보존, 빈 정책·요청·기록과 복원 지점 준비, Hermes 재시작 |
| `check start` | 준비한 시작 파일·관련 설정의 일치 확인, JSON 기록 |
| `check policy` | 정책 파일만 변경된 상태인지 확인, JSON 기록 |
| `approve` | 검토한 정책·PLAN 사본과 P2 승인 기록 생성 |
| `check implemented` | 승인된 PLAN·정책을 유지하면서 코드와 허용된 실행 산출물만 달라졌는지 확인 |
| `test` | 네 실행, 값·순서·반복·보존 검사, 실행 로그 수집 |
| `check final` | 현재 코드·PLAN·정책·결과 파일이 통과한 실행과 이어지는지 확인 |
| `restore` | 현재 시도를 보관하고 8교시 시작 상태로 복원. Hermes는 중지 상태로 남음 |

## 4) 실습에 필요한 핵심 개념

**최소 권한**은 현재 작업에 필요한 행동만, 필요한 대상에 허용하는 원칙입니다. “쓰기 허용”보다 “승인 뒤 analyze_sales.py만 수정”이 구체적입니다. 이번 정책에는 Agent의 코드 쓰기와 프로그램이 실행 중 결과를 쓰는 범위를 따로 적습니다.

| 구분 | 이번 실습의 예 | 확인 방법 |
|---|---|---|
| 할 수 있는 행동 | 파일 읽기·쓰기, 프로그램 실행 | 도구 목록과 실행 명령 |
| 허용할 대상 | 지정 문서·코드·결과 폴더 | 정책과 실제 경로 대조 |
| 허용할 조건 | P2 승인 이후 코드 수정 | 승인 기록과 대화 순서 대조 |
| 남길 증거 | 원문 응답, 도구 이력, 종료코드, 결과 파일 | records와 세션 JSON 보관 |

### 문서, 환경 제한, 사후 검사는 역할이 다르다

`TOOL_POLICY.md`는 Agent에게 전달하는 규칙입니다. 이 파일을 만들었다고 도구가 자동으로 제거되거나 네트워크가 끊어지지는 않습니다. `/inputs`와 `/course-tools`의 읽기 전용 연결은 실제 파일시스템 제한입니다. `check`는 변경 후 파일과 저장 설정을 비교하는 관찰입니다. 각 역할을 합쳐 작업을 통제합니다.

분석 프로그램에는 환율 조회나 모델 API 호출이 필요 없습니다. Hermes가 OpenRouter 모델에 연결하는 통신은 계속 필요합니다. 검사 도구는 분석 자식 프로세스에 전달하는 환경 변수를 줄이지만, 이것을 비밀 접근이나 네트워크의 완전한 차단으로 해석하지 않습니다. 이번에는 불필요한 접속을 시도하지 않고 요청과 도구 이력으로 범위 준수를 확인합니다.

### 종료코드·출력·해시 읽기

- **종료코드**는 프로그램이 끝나면서 남기는 숫자입니다. 이번 명세에서 정상은 `0`, 입력 오류는 `2`입니다. 수량 0 사례의 종료코드 `2`는 기대한 오류 처리입니다.
- **stdout**은 일반 메시지, **stderr**는 오류 설명을 보내는 통로입니다. 검사 도구가 각각 `.stdout.txt`, `.stderr.txt`로 저장합니다.
- **SHA-256 해시**는 파일의 바이트로 계산한 64자리 값입니다. 같은 파일의 실행 전후 해시가 같으면 바이트가 유지됐는지 확인할 수 있습니다. `summary.csv`와 `report.md` 서로의 해시를 비교하는 것이 아니라, 각 파일을 자신의 이전 결과와 비교합니다.

## 5) 전체 작업 흐름

| 단계 | 하는 일과 이유 | 기록의 변화 |
|---|---|---|
| 1 | P1과 이전 기록을 유지하며 8교시 시작 상태 준비 | 1절 시작 상태 |
| 2 | 도구 정책 작성·검토로 필요한 행동과 범위 확정 | 2절 정책 검토 |
| 3 | 검토한 정책·PLAN에 연결하여 P2만 승인 | 3절 승인 항목 |
| 4 | 승인한 코드 한 파일에 P2 구현 | 3절 구현 항목 갱신 |
| 5 | 네 실행과 사람 검토로 결과 확인 | 4절 실행 결과로 교체 |
| 6 | 불필요한 도구 제안 판단·최종 검사·보관 | 5절 종료, 1절 세션 파일명 갱신 |

이번 프로그램이 만드는 결과는 **매출 집계를 담은 `summary.csv`와 한국어 설명을 담은 `report.md`**입니다. 두 파일은 `workspace/outputs/lesson08-p2/`에 저장합니다.

예를 들어 어제 정상적으로 만든 보고서가 있는데, 오늘 입력한 CSV에 수량이 0인 행이 들어 있다고 생각해 봅시다. 프로그램이 실행하자마자 기존 결과 파일을 비우고 나중에 입력 오류를 발견하면, 새 결과도 만들지 못하고 이전 결과까지 잃을 수 있습니다.

이를 막으려면 **먼저 CSV의 모든 행이 입력 규칙에 맞는지 검사하고, 오류가 없을 때만 `summary.csv`와 `report.md`를 만들거나 새 내용으로 바꾸도록** 구현해야 합니다. 검사 중 오류를 발견하면 오류를 알리고 종료하며, 기존 두 파일은 그대로 둡니다.

검사 도구는 다음 순서로 이 동작을 확인합니다.

1. 정상 10행으로 `summary.csv`와 `report.md`를 생성합니다. 같은 입력으로 한 번 더 실행해 각 파일의 내용이 같은지도 확인합니다.
2. 두 결과 파일을 그대로 둔 채 수량 0인 CSV로 실행합니다. 오류를 보고하고 종료했는지, 실행 전후에 두 파일의 바이트가 유지됐는지 확인합니다.
3. 이어서 존재하지 않는 입력 파일 경로로 실행하고, 오류를 보고하면서 두 결과 파일을 유지하는지 같은 방식으로 확인합니다.

즉, 오류 메시지가 나왔다는 사실에 더해 **앞서 만들어 둔 정상 결과도 보존됐는지**까지 검사합니다.

```mermaid
flowchart TD
  I["입력 CSV"] --> V{"모든 입력이 유효한가?"}
  V -->|예| C["계산 · 두 결과 생성 또는 교체"]
  V -->|아니오| E["첫 오류 기록 · 종료코드 2"]
  C --> N["새 정상 결과"]
  E --> K["기존 두 결과 유지"]
```

## 6) 단계별 실습

아래 주요 출력과 기록은 실제 실습을 바탕으로 한 예시입니다. 파일명·해시·도구 횟수는 본인의 결과로 바꿉니다. 명령은 코드 블록에서 복사하고, 예시의 통과 결과는 직접 확인한 뒤 기록합니다. 보고서 내용에 대한 판단은 `report.md`를 읽고 작성합니다.

### 단계 1. ZIP을 합치고 시작 상태 준비하기

#### 1-1. 압축 해제 위치 확인

다운로드한 `AN-Harness-Lesson08-Tools.zip`의 속성에 ‘차단 해제’가 있으면 적용한 뒤 압축을 풉니다. 압축 안의 `harness-engineering` 폴더 내용을 기존 `C:\AI-Native\harness-engineering`에 합칩니다. ZIP에는 8교시 자료만 들어 있으며 개인의 `workspace`, `records`, `.env`, `compose.yaml`, 원본 CSV는 들어 있지 않습니다.

`lesson08.ps1`과 기존 `compose.yaml`이 같은 폴더에 있어야 합니다. `harness-engineering` 아래에 같은 이름의 폴더를 한 번 더 만들지 않도록 확인합니다. 이전 폴더를 삭제해서 새 ZIP으로 교체하지 않습니다.

**PowerShell**에서 입력합니다.

```powershell
Set-Location 'C:\AI-Native\harness-engineering'
Get-Location
Test-Path .\compose.yaml
Test-Path .\lesson08.ps1
Test-Path .\course-tools\lesson08_tools.py
Test-Path .\course-tools\lesson08_probe.py
Test-Path .\starter\lesson08\TOOL_POLICY.md
Test-Path .\templates\tool_audit.md
Test-Path .\workspace\analyze_sales.py
Test-Path .\workspace\PLAN.md
Test-Path .\workspace\SPEC.md
Test-Path .\workspace\lesson07\ACCEPTANCE.md
Test-Path .\records\lesson07\latest-probe.json
Test-Path .\inputs\sales\sales_micro.csv
Test-Path .\inputs\sales\errors\quantity_zero.csv
```

작업 위치가 맞고 `Test-Path`가 모두 `True`인지 확인합니다. `False`이면 새 자료의 압축 해제 위치인지, 이전 교시에서 만들어야 할 파일이 빠졌는지 위 표로 구분합니다. 파일이 있다는 것만으로 내용까지 올바른 것은 아니며 다음 준비 명령이 진입 상태를 검사합니다.

#### 1-2. 준비 명령의 역할을 알고 실행

```powershell
Unblock-File -LiteralPath .\lesson03.ps1
Unblock-File -LiteralPath .\lesson07.ps1
Unblock-File -LiteralPath .\lesson08.ps1
.\lesson08.ps1 prepare
```

`Unblock-File`은 다운로드한 PowerShell 스크립트의 차단 표시를 해제합니다. `prepare`는 다음 순서로 일합니다.

1. 현재 P1 코드·PLAN과 7교시 통과 기록을 대조하고, 7교시 final·Baseline 보존을 확인합니다.
2. Hermes를 중지하고 이전 workspace 및 8교시에 영향을 주는 설정·Memory·Skill 상태를 보관합니다.
3. P1 코드·SPEC·PLAN을 유지하면서 8교시의 읽기 순서·경계·빈 정책·요청을 준비합니다. 인수조건을 복사하고 비어 있는 P2 결과 폴더를 만듭니다.
4. `records/lesson08/tool_audit.md`와 복원 원본을 만들고 Hermes를 다시 시작합니다.

정상 출력의 주요 메시지는 다음과 같습니다. 컨테이너 생성·중지 메시지와 검사 JSON은 생략한 예시입니다.

```text
PREFLIGHT_PASS: Lesson07 P1 source and plan match the saved result.
CHECK_PASS: final
BASELINE_INTEGRITY_PASS
PREFLIGHT_PASS: Lesson07 P1 source and plan match the saved result.
PREPARE_PASS: Lesson07 P1 preserved; Lesson08 entry checkpoint saved.
BASELINE_INTEGRITY_PASS
Next: check healthy, open a NEW Hermes Chat, then .\lesson08.ps1 check start
```

여기의 첫 `CHECK_PASS: final`은 준비 과정에서 호출한 **7교시 검사**입니다. `PREPARE_PASS`가 나오면 준비를 반복하지 않고 다음으로 갑니다. 중지 이유가 나오면 7)의 문제 해결표를 따릅니다.

#### 1-3. healthy 확인과 새 Chat

```powershell
docker compose ps
```

상태 출력의 필요한 두 열만 발췌한 예시입니다. 실행 시간은 달라집니다.

```text
NAME                         STATUS
an-harness-course-hermes-1    Up About a minute (healthy)
```

`STATUS`의 `(healthy)`는 컨테이너의 상태 검사를 통과했다는 뜻입니다. `(health: starting)`이면 잠시 뒤 같은 명령으로 확인합니다. 이것은 분석 프로그램의 정확성 검사와는 다릅니다.

Hermes 웹 대시보드 `http://127.0.0.1:9119`를 열고 **새 Chat**을 만듭니다. 7교시 대화에 이어 쓰지 않습니다. 새 Chat에 다음을 한 줄씩 입력합니다.

```text
/title tools-lesson08
/model z-ai/glm-5.3-flash
/reasoning low
/status
```

제목, 모델, 추론 설정을 확인합니다. 추론 설정 `low`는 이번 과정에서 비교 조건을 맞추기 위해 사용하는 Hermes 설정입니다. 상태 화면의 표시와 저장 설정은 관찰 기록에 남깁니다.

#### 1-4. 시작 검사 출력 읽기

```powershell
.\lesson08.ps1 check start
```

**시작 검사 출력 예시:**

```json
{
  "stage": "start",
  "workspace_matches": true,
  "workspace_differences": [],
  "settings_match": true,
  "settings_differences": [],
  "memory_and_skills_unchanged": true,
  "common_inputs_unchanged": true,
  "earlier_lesson_records_unchanged": true,
  "spec_sha256": "80813a38ca366a3a8e1e454e039a7d677cd5aebdfa1aa5edcdb836a557bc3475",
  "plan_sha256": "bd124587cdc364a2d1fdeaa46a1b799d9fe26afa58563c03749b51767f1af414",
  "policy_sha256": "8a6ceb84c5f3df4bab7c06457705115badc143da2d4acfc171e3d419ff755af9",
  "p2_probe_current_and_passed": null,
  "scope": "Stage-specific file observations and saved settings; review plan quality, actual tool use and approval in the Chat."
}
```

```text
RECORDED: records/lesson08/check-start-20260911T153645463655Z-3de0a7.json
START_READY
```

`workspace_matches`는 8교시 진입 파일과 일치하는지, `settings_match`는 준비 당시의 관련 저장 설정과 일치하는지를 뜻합니다. 차이가 없으면 각각의 `differences` 목록은 `[]`입니다. Memory·Skill, 공통 입력, 앞 교시 기록의 유지 여부도 함께 확인합니다.

`spec_sha256`, `plan_sha256`, `policy_sha256`은 각각 현재 `workspace/SPEC.md`, `PLAN.md`, `TOOL_POLICY.md`의 내용으로 계산한 값입니다. `check-start-…json` 파일명의 시각·식별자를 뜻하지 않습니다. 정책을 작성하면 `policy_sha256`은 바뀌고, 그대로 유지하는 SPEC와 PLAN의 해시는 바뀌지 않아야 합니다.

`p2_probe_current_and_passed: null`은 이 단계에서 현재 P2 실행 결과와의 연결을 판정하지 않았다는 뜻입니다. 최종 검사에서 실제 통과 기록과 대조하여 `true`인지 확인합니다. `scope`는 이 검사가 파일과 저장 설정 관찰이며, 내용의 타당성과 실제 도구 사용은 Chat에서 검토해야 한다는 범위를 설명합니다.

#### 1-5. 기록 시작

```powershell
notepad .\records\lesson08\tool_audit.md
```

준비 명령이 만든 양식의 **1절만** 아래처럼 채웁니다. 이후 절은 지우지 말고 해당 단계가 되었을 때 작성합니다. 검사 파일명은 자신의 `RECORDED` 출력에서 가져옵니다.

```markdown
## 1. 시작 상태
- 작성자 / 날짜: Nuguna / 2026-09-12
- 모델 / 추론 설정: z-ai/glm-5.3-flash / low
- Chat 이름 / 세션 JSON: tools-lesson08 / 내보내기 전
- 이어받은 것: 7교시의 SPEC.md·PLAN.md·인수조건과 P1 입력 검사 코드
- prepare / healthy / check start 결과: PREPARE_PASS / healthy / START_READY
- 시작 검사 파일: check-start-20260911T153645463655Z-3de0a7.json
```

Ctrl+S로 저장하고 닫습니다. 앞으로 이 파일을 계속 채웁니다.

### 단계 2. 도구 정책을 작성하고 사람이 검토하기

#### 2-1. 작업·인수조건·빈 정책 읽기

```powershell
notepad .\workspace\lesson08\TASK.md
notepad .\workspace\lesson08\ACCEPTANCE.md
notepad .\workspace\TOOL_POLICY.md
```

TASK에서 **P2는 결과 파일을 만들지만 P1의 입력 오류 규칙은 유지한다**는 점을 확인합니다. 7교시의 정상 메시지 `INPUT_VALID rows=10`은 입력 검사 단계의 중간 결과였고, 이번 정상 실행의 핵심은 두 결과 파일입니다.

정책의 빈 표에는 도구 이름만 적는 것이 아니라 대상과 주체를 적게 됩니다. 파일을 읽고 창을 닫은 뒤 정책 요청을 준비합니다.

#### 2-2. 정책 작성 요청 보내기

```powershell
Get-Content -Raw -Encoding utf8 .\workspace\lesson08\policy_request.txt | Set-Clipboard
```

`Get-Content`는 요청 파일 전체를 읽고, `Set-Clipboard`는 그 내용을 클립보드에 넣습니다. Chat 입력창에 붙여넣은 뒤 전체 요청이 들어갔는지 보고 전송합니다. 파일에 들어 있는 요청은 다음과 같습니다.

```text
/workspace/CONTEXT_INDEX.md와 거기에 나열된 문서·기존 P1 코드를 읽으세요.
/inputs/sales/sales_micro.csv와 /inputs/sales/errors/quantity_zero.csv도 읽으세요.
/workspace/lesson08/TASK.md의 P2를 수행하는 데 필요한 도구 사용 정책을 /workspace/TOOL_POLICY.md에 작성하세요.
행동별로 주체, 대상 경로, 허용 조건, 남길 기록을 표로 구분하세요.
정책 단계는 TOOL_POLICY.md만, P2 승인 뒤에는 analyze_sales.py만 변경할 수 있습니다.
실행은 교육생이 PowerShell에서 lesson08.ps1 test로 수행합니다. Agent는 명령을 실행하지 않습니다.
네트워크·패키지 설치·설정·Memory·Skill·비밀 접근이 왜 필요하지 않은지 설명하세요.
실패 시 증거 보존, 원인 하나 수정, 한 번 재검사와 중단 조건을 포함하세요.
문서 지시와 실제 운영체제 제한, 검사 후 관찰을 구분하세요. 정책 파일 자체가 권한을 강제한다고 쓰지 마세요.
정책 파일 외에 코드·계획·명세·설정 등을 변경하지 마세요.
실제로 사용한 도구와 변경 파일, 아직 승인하지 않은 일을 요약하고 멈추세요. P2 구현은 아직 승인하지 않았습니다.
```

Agent가 정책 파일을 작성하고 멈출 때까지 기다립니다. 코드 수정이나 실행이 함께 제안되면 지금은 정책 작성 단계라고 알리고 구현은 진행하지 않습니다.

#### 2-3. 파일 검사와 내용 검토

```powershell
.\lesson08.ps1 check policy
notepad .\workspace\TOOL_POLICY.md
```

정책 해시는 새로 작성한 내용의 값으로 바뀝니다. `CHECK_PASS: policy`는 허용한 정책 파일 변경과 보호 대상 유지가 검사 기준에 맞았다는 뜻입니다. 정책이 과도한 권한을 주는지까지 자동 판정한 것은 아닙니다.

| 검토할 항목 | 적절한 정책의 예 | 수정이 필요한 경우 |
|---|---|---|
| 읽기 대상 | 지정 문서·코드·정상/오류 CSV | 사용자 홈·환경 변수 전체·API Key까지 읽겠다고 함 |
| 정책 단계 쓰기 | TOOL_POLICY.md만 작성 | 정책을 만들면서 코드도 바꾸겠다고 함 |
| 승인 뒤 코드 쓰기 | analyze_sales.py만 수정 | SPEC·PLAN·승인 파일을 바꾸겠다고 함 |
| 실행 주체 | 교육생이 lesson08.ps1 test 실행 | Agent가 Terminal·lint·패키지 설치를 실행하겠다고 함 |
| 프로그램 결과 | outputs/lesson08-p2의 두 파일 | 앞 교시 결과나 임의 경로를 덮어쓰겠다고 함 |
| 실패 처리 | 로그 보존, 원인 하나 수정, 한 번 재검사, 재실패 시 중단 | 성공할 때까지 반복하거나 범위를 자동 확대함 |
| 실제 제한 설명 | 문서 지시·읽기 전용 연결·사후 검사 구분 | 정책 파일만 만들면 네트워크가 강제 차단된다고 함 |

표에 맞으면 검토 의견을 기록하고 단계 3으로 갑니다. 수정할 내용이 있으면 **승인 전에** 같은 Chat에서 해당 내용만 보완합니다. 예를 들어 실행 주체가 잘못 적혀 있을 때는 다음을 보냅니다.

```text
TOOL_POLICY.md의 실행 주체를 보완하세요.
프로그램 실행과 문법 점검은 Agent가 수행하지 않습니다.
교육생이 PowerShell에서 lesson08.ps1 test로 검사한다는 TASK의 범위를 반영하세요.
TOOL_POLICY.md만 수정하고 변경한 내용을 요약한 뒤 멈추세요.
P2 구현은 아직 승인하지 않았습니다.
```

**정책을 검토하고 보완한 실제 예시:** 최초 정책에는 CSV 읽기 범위가 넓고, 읽기 도구 이력이 남지 않는다는 설명과 실행 장소·로그 작성 주체가 부정확한 부분이 있었습니다. 다음 여덟 항목을 보완했습니다.

| 보완할 내용 | 보완 후 기준 |
|---|---|
| CSV 범위 | sales_micro.csv와 errors/quantity_zero.csv 두 파일로 한정 |
| 읽기 기록 | 읽기 호출도 세션 이력에 남고 응답에 실제 파일·도구를 요약 |
| 읽기 전용 | Agent가 변경을 시도하지 않는 지시와 파일시스템의 쓰기 차단을 구분 |
| 실행 장소 | 교육생의 PowerShell 명령 → 일반 Hermes 컨테이너의 검사 도구 → 분석 코드 |
| 로그 작성 | 검사 도구가 자동 생성하고 스크립트가 records로 수집, 교육생은 판단 기록 |
| 결과 쓰기 | 분석 프로그램의 summary.csv·report.md 생성을 별도로 명시 |
| 환경 정보 | 실행으로 확인하지 않은 Python 버전을 관찰 결과처럼 쓰지 않음 |
| 재검사 | 수정 뒤 한 번 재검사하고 재실패하면 중단 |

최초 작성은 Read File 13회·Write File 1회, 보완은 Write File 1회였습니다. 자신의 정책에도 같은 문제가 있는지 읽고, 해당하는 항목만 수정 요청합니다. 수정한 정책을 다시 검사한 실제 출력은 다음과 같습니다.

**보완 후 정책 검사 출력 발췌 예시:**

```json
{
  "stage": "policy",
  "workspace_matches": true,
  "workspace_differences": [],
  "plan_sha256": "bd124587cdc364a2d1fdeaa46a1b799d9fe26afa58563c03749b51767f1af414",
  "policy_sha256": "818371c919aee8aea723aeb5a3fc2eb1a0a6322e9e878fb541737c14177cf8b0",
  "p2_probe_current_and_passed": null
}
```

```text
RECORDED: records/lesson08/check-policy-20260911T155929570809Z-359a70.json
CHECK_PASS: policy
```

보완했다면 `check policy`를 다시 실행하고 정책을 다시 읽습니다. 보완 요청은 실제 문제에 맞게 작성합니다. 적절한 정책에 일부러 결함을 만들거나 불필요한 보완을 반복하지 않습니다.

#### 2-4. 응답 보관과 2절 작성

```powershell
notepad .\records\lesson08\policy_response.md
notepad .\records\lesson08\tool_audit.md
```

`policy_response.md`에는 **정책 작성이 끝난 뒤 Agent가 보낸 마지막 요약 응답 전체**를 그대로 붙여넣습니다. 요청문, 화면 상태줄, 긴 파일 변경 diff는 넣지 않습니다. 실제 도구 호출과 전체 대화는 세션 JSON으로 따로 보관합니다. `/copy`를 사용했다면 붙여넣은 내용이 해당 응답인지 확인합니다. 보완 응답은 `policy_revision_response.md`에 별도로 저장합니다.

`tool_audit.md`의 **2절을** 다음 예시와 같은 형태로 작성합니다. 아래는 정책 보완 후의 기록입니다. 보완 전 의견을 유지하고 보완 요청·결과·새 검사 파일명을 추가합니다. 보완이 필요 없었다면 그 이유를 적습니다.

```markdown
## 2. 도구 정책 검토
- 정책 단계 변경 파일: TOOL_POLICY.md 하나
- 최초 작성 도구: Read File 13회, Write File 1회
- 최초 검토 의견: CSV 읽기 범위, 읽기 기록, 실행 장소와 로그 작성 주체, 프로그램 출력 권한, 환경 정보와 재검사 표현을 보완해야 한다.
- 보완 요청 / 결과: 여덟 항목의 보완을 요청했다. 두 CSV로 읽기를 한정하고, 세션의 읽기 이력·일반 컨테이너 실행·자동 로그 수집·분석 프로그램의 결과 쓰기를 구분했다. 읽기 전용 지시와 강제 제한을 나누고, 미확인 Python 버전을 생략했으며 재검사를 한 번으로 통일했다.
- 보완 도구 / 변경 파일: Write File 1회 / TOOL_POLICY.md
- 보완 후 검사 결과 / 파일명: CHECK_PASS: policy / check-policy-20260911T155929570809Z-359a70.json
- 보완 후 정책 해시: 818371c919aee8aea723aeb5a3fc2eb1a0a6322e9e878fb541737c14177cf8b0
- 실행 주체: 교육생이 PowerShell에서 lesson08.ps1 test를 실행하고, 일반 Hermes 컨테이너의 검사 도구가 분석 코드를 실행한다. Agent는 명령을 실행하지 않는다.
- 프로그램 결과: /workspace/outputs/lesson08-p2/summary.csv와 report.md. 모든 입력 검사 후 생성·교체하며 입력 오류에서는 기존 파일을 보존한다.
- 필요하지 않은 행동: 환율 조회·패키지 설치·설정·Memory·Skill 변경. 원 단위 집계는 표준 라이브러리로 수행한다.
- 문서와 제한의 구분: 정책은 행동 지시이며 읽기 전용 마운트는 환경의 제한이다. 정책 작성이 네트워크 강제 차단을 뜻하지 않는다.
- 응답 보관: policy_response.md / policy_revision_response.md
- 현재 판단: 보완된 정책을 검토했다. P2 구현은 아직 승인하지 않았다.
```

Ctrl+S로 저장합니다. 이 단계에서는 P2 구현 승인을 보내지 않았습니다.

### 단계 3. 검토한 정책으로 P2만 승인하기

#### 3-1. 승인 명령 실행

정책의 변경 범위와 실행 주체가 적절하다고 판단했으면 PowerShell에서 입력합니다.

```powershell
.\lesson08.ps1 approve
Get-Content -Raw -Encoding utf8 .\records\lesson08\approved-policy.json
```

주요 출력은 다음과 같습니다. `approve`가 내부에서 실행한 정책 검사 JSON은 생략했습니다.

```text
CHECK_PASS: policy
APPROVE_PASS: reviewed policy saved; P2 only. Send the P2 request in Hermes Chat.
```

**승인 파일 예시:**

```json
{
  "approved_step": "P2",
  "plan_sha256": "bd124587cdc364a2d1fdeaa46a1b799d9fe26afa58563c03749b51767f1af414",
  "policy_sha256": "818371c919aee8aea723aeb5a3fc2eb1a0a6322e9e878fb541737c14177cf8b0",
  "created_utc": "20260911T160351902271Z-368df2",
  "allowed_change": [
    "analyze_sales.py"
  ],
  "allowed_execution": "Student runs lesson08.ps1 test; Agent does not run commands",
  "approval_scope": "P2 implementation only; no P3, settings, Memory or Skill changes. Not a blanket tool permission."
}
```

`approved_step`은 P2, `allowed_change`는 코드 한 파일입니다. `plan_sha256`과 `policy_sha256`은 **어느 계획과 정책을 검토해 승인했는지** 연결하는 값입니다. `created_utc`는 승인 시점을 구분하는 값이며 파일 내용의 해시가 아닙니다.

이 명령은 승인 기록을 남깁니다. **Chat에 구현 요청을 자동으로 보내지는 않습니다.** 또한 Hermes의 모든 도구 호출을 포괄적으로 허용하는 설정 변경도 아닙니다. 정책·계획을 바꾸어야 할 문제가 남았다면 구현 요청을 보내기 전에 멈추고 검토합니다.

#### 3-2. 3절의 승인 내용을 기록

```powershell
notepad .\records\lesson08\tool_audit.md
```

2절의 현재 판단을 “정책 검토를 마치고 P2 승인 기록을 남겼다”로 바꿉니다. **3절은 아래처럼 작성**하고, 구현 요청·실제 도구·구현 검사 항목은 아직 실행 전으로 둡니다.

```markdown
## 3. 승인과 구현
- 승인한 단계: P2 계산·출력 구현
- 승인하지 않은 단계: P3 더 넓은 검증
- approve 결과 / 승인 기록: APPROVE_PASS / approved-policy.json
- 승인 PLAN 해시: bd124587cdc364a2d1fdeaa46a1b799d9fe26afa58563c03749b51767f1af414
- 승인 정책 해시: 818371c919aee8aea723aeb5a3fc2eb1a0a6322e9e878fb541737c14177cf8b0
- Chat에 보낸 P2 구현 요청: 아직 보내기 전
- 실제 도구 / 변경 파일: 구현 요청 전
- check implemented 결과 / 파일명: 구현 뒤 작성
- 구현 응답 보관 파일: 구현 뒤 implementation_response.md에 저장
```

### 단계 4. 승인한 코드만 구현하기

#### 4-1. 같은 Chat에 P2 구현 요청 보내기

```powershell
Get-Content -Raw -Encoding utf8 .\workspace\lesson08\implement_request.txt | Set-Clipboard
```

정책을 작성한 `tools-lesson08` Chat에 붙여넣고 전송합니다. 요청 내용은 다음과 같습니다.

```text
/workspace/lesson08/approval.json을 읽고 P2 승인 범위와 /workspace/TOOL_POLICY.md를 확인하세요.
/workspace/CONTEXT_INDEX.md의 문서, PLAN.md의 P2, SPEC.md, lesson08/ACCEPTANCE.md, lesson08/TASK.md와 기존 analyze_sales.py를 읽으세요.
지정된 두 CSV가 필요하면 읽어도 됩니다.
승인된 P2만 /workspace/analyze_sales.py에 구현하세요. P1 입력 규칙과 첫 오류 처리를 유지하고 SPEC의 계산과 두 출력 파일 생성을 추가하세요.
실행 인터페이스는 python analyze_sales.py --input 입력경로 --output-dir 결과폴더입니다.
이번 출력 위치는 /workspace/outputs/lesson08-p2입니다. 정상 입력 전체 검사 후 두 파일을 생성·교체하고 오류 시 기존 파일의 바이트를 유지하도록 구현하세요.
표준 라이브러리만 사용하세요. 계획·정책·명세·Context·인수조건·승인·요청·로그·설정·Memory·Skill은 변경하지 마세요.
프로그램 실행·py_compile·lint·패키지 설치·외부 검색은 하지 마세요. 교육생이 PowerShell에서 실행 검사합니다.
변경 파일, 실제 도구, 구현 범위와 아직 실행하지 않은 검사를 요약하고 파일 작성이 끝나면 멈추세요.
```

기존 P1의 입력 검사·첫 오류 처리를 유지하면서, 모든 입력이 유효할 때 계산과 출력을 수행하도록 바뀝니다. 이때 Agent가 해야 하는 일은 코드 작성입니다. 실행은 다음 단계에서 교육생이 합니다.

#### 4-2. 변경 파일 확인

```powershell
.\lesson08.ps1 check implemented
Get-Item .\workspace\analyze_sales.py
notepad .\records\lesson08\implementation_response.md
```

**구현 검사 출력 발췌 예시:**

```json
{
  "stage": "implemented",
  "workspace_matches": true,
  "workspace_differences": [],
  "plan_sha256": "bd124587cdc364a2d1fdeaa46a1b799d9fe26afa58563c03749b51767f1af414",
  "policy_sha256": "818371c919aee8aea723aeb5a3fc2eb1a0a6322e9e878fb541737c14177cf8b0",
  "p2_probe_current_and_passed": null
}
```

```text
RECORDED: records/lesson08/check-implemented-20260911T161400604532Z-6d8a66.json
CHECK_PASS: implemented
```

`workspace_matches: true`는 시작 파일과 전부 같다는 뜻이 아니라 **해당 단계에 허용된 변경을 제외한 나머지가 맞는다**는 뜻입니다. 코드는 바뀔 수 있지만 SPEC·PLAN·승인 정책은 유지되어야 합니다. `Get-Item`은 파일 존재와 크기를 보여주며, 특정 바이트 수와 일치할 필요는 없습니다.

`implementation_response.md`에 코드 작성이 끝난 뒤의 Agent 최종 요약을 원문 그대로 저장합니다. “실행했다”, “검사를 통과했다”는 표현이 있다면 실제 도구 이력과 대조하고, 근거가 없으면 자신의 기록에서는 실행 완료로 쓰지 않습니다.

#### 4-3. 기록의 3절을 갱신

`tool_audit.md`의 3절에서 다음 항목을 실제 결과로 교체합니다. 승인 당시 해시는 유지합니다.

```markdown
- Chat에 보낸 P2 구현 요청: lesson08/implement_request.txt의 전체 내용을 tools-lesson08 Chat에 전송함
- 실제 도구 / 변경 파일: Read File 6회, Patch 6회 / analyze_sales.py
- check implemented 결과 / 파일명: CHECK_PASS: implemented / check-implemented-20260911T161400604532Z-6d8a66.json
- 구현 파일 확인: analyze_sales.py, 12,479바이트
- 구현 응답 보관 파일: implementation_response.md
```

4절은 아직 실행 전 상태로 둡니다. 코드가 생성된 것과 결과 파일이 올바르게 만들어지는 것은 다음 실행으로 구분해 확인합니다.

### 단계 5. 네 번 실행하고 결과를 읽기

#### 5-1. 실행 순서와 기대값 확인

`lesson08.ps1 test` 한 번이 아래 네 실행을 순서대로 수행합니다. 수량 0과 없는 입력은 오류를 일부러 확인하는 사례입니다.

| 실행 이름 | 입력과 목적 | 기대 결과 |
|---|---|---|
| `valid_micro` | 정상 10행으로 계산·출력 | 종료코드 0, 정확한 summary.csv, UTF-8의 비어 있지 않은 report.md |
| `repeat_micro` | 같은 입력·같은 결과 폴더로 재실행 | 종료코드 0, 첫 실행과 각 파일의 바이트 동일 |
| `quantity_zero` | 수량 0을 오류로 처리 | 종료코드 2, 레코드 5·quantity·이유, 기존 두 결과 유지 |
| `missing_input` | 없는 파일 경로를 오류로 처리 | 종료코드 2, INPUT_NOT_FOUND, 기존 두 결과 유지 |

두 오류 사례의 보존 대상은 **이번 정상 실행이 만든 실제 결과**입니다. 7교시에서 보존용으로 둔 시험 파일과 구분합니다. 반복 확인도 stdout 문구가 아니라 `summary.csv`와 `report.md` 각각의 바이트를 비교합니다.

```powershell
.\lesson08.ps1 test
```

**정상 출력의 주요 메시지 예시:** 내부 `check implemented`의 JSON과 컨테이너 메시지는 생략했습니다.

```text
CHECK_PASS: implemented
PASS valid_micro: exit=0
PASS repeat_micro: exit=0
PASS quantity_zero: exit=2
PASS missing_input: exit=2
PROBE_REPORT: /workspace/lesson08/checks/p2-20260911T162113309861Z-f5861e/report.json
RECORDED: records/lesson08/probe-runs/p2-20260911T162113309861Z-f5861e/report.json
CHECK_PASS: implemented
P2_CHECK_PASS: four executions passed. Review report content and tool history; P3 remains outside scope.
```

`P2_CHECK_PASS`까지 확인합니다. 내부 `check implemented`의 `p2_probe_current_and_passed`는 여전히 `null`일 수 있습니다. 이 필드는 `check final`에서 현재 파일과 통과 기록의 연결을 판정할 때 `true`가 됩니다.

#### 5-2. 실제 실행 폴더와 보고서 열기

다음 명령은 최근 수집한 보고서에서 실행 식별자인 `run_id`를 읽고, 그 실행 폴더를 `$runPath`라는 PowerShell 변수에 담습니다. 예시의 폴더 이름을 직접 타이핑하지 않아도 됩니다.

```powershell
$probeRecord = Get-Content -Raw -Encoding utf8 .\records\lesson08\latest-probe.json | ConvertFrom-Json
$runPath = Join-Path '.\records\lesson08\probe-runs' $probeRecord.run_id
$runPath
Get-Content -Raw -Encoding utf8 (Join-Path $runPath 'report.json')
Get-Content -Encoding utf8 (Join-Path $runPath 'quantity_zero.stderr.txt')
Get-Content -Encoding utf8 (Join-Path $runPath 'missing_input.stderr.txt')
```

`report.json`은 **검사 도구의 보고서**, `report.md`는 **판매 분석 프로그램이 생성한 보고서**입니다. 확장자와 폴더로 구분합니다. 검사 도구는 각 실행의 stdout·stderr와 당시 두 결과 파일의 사본도 보관합니다.

**검사 보고서 발췌 예시:** `cases`의 실행 명령은 생략하고 판정과 파일별 전후 해시를 남겼습니다.

```json
{
  "scope": "P2 micro-output, repeat, quantity-zero and missing-input checks. Report meaning and actual tool use require human review; not whole-SPEC acceptance.",
  "run_id": "p2-20260911T162113309861Z-f5861e",
  "source_sha256": "eaefcc71537bad37378d30e30b37f1cb1b7e70ef8b1ba8de29a84fcc58cf4eca",
  "plan_sha256": "bd124587cdc364a2d1fdeaa46a1b799d9fe26afa58563c03749b51767f1af414",
  "policy_sha256": "818371c919aee8aea723aeb5a3fc2eb1a0a6322e9e878fb541737c14177cf8b0",
  "cases": [
    {
      "case": "valid_micro",
      "actual_exit_code": 0,
      "checks": {
        "exit_code_matches": true,
        "no_timeout": true,
        "summary_matches": true,
        "report_utf8_nonempty": true
      },
      "passed": true,
      "expected_exit_code": 0,
      "before_output_hashes": {
        "summary.csv": null,
        "report.md": null
      },
      "after_output_hashes": {
        "summary.csv": "9fbca724b702d7d656d5c95ed8cca25a9ff7df63d9c88767eabfee6f7039ecb1",
        "report.md": "9a0f32769cd36d40d71a33cb6b7454c5e0b81a3207b70bf5da016cf5bf01338a"
      }
    },
    {
      "case": "repeat_micro",
      "actual_exit_code": 0,
      "checks": {
        "exit_code_matches": true,
        "no_timeout": true,
        "summary_matches": true,
        "report_utf8_nonempty": true,
        "repeat_bytes_equal": true
      },
      "passed": true,
      "expected_exit_code": 0,
      "before_output_hashes": {
        "summary.csv": "9fbca724b702d7d656d5c95ed8cca25a9ff7df63d9c88767eabfee6f7039ecb1",
        "report.md": "9a0f32769cd36d40d71a33cb6b7454c5e0b81a3207b70bf5da016cf5bf01338a"
      },
      "after_output_hashes": {
        "summary.csv": "9fbca724b702d7d656d5c95ed8cca25a9ff7df63d9c88767eabfee6f7039ecb1",
        "report.md": "9a0f32769cd36d40d71a33cb6b7454c5e0b81a3207b70bf5da016cf5bf01338a"
      }
    },
    {
      "case": "quantity_zero",
      "actual_exit_code": 2,
      "checks": {
        "exit_code_matches": true,
        "no_timeout": true,
        "diagnostic_matches": true,
        "existing_outputs_preserved": true
      },
      "passed": true,
      "expected_exit_code": 2,
      "before_output_hashes": {
        "summary.csv": "9fbca724b702d7d656d5c95ed8cca25a9ff7df63d9c88767eabfee6f7039ecb1",
        "report.md": "9a0f32769cd36d40d71a33cb6b7454c5e0b81a3207b70bf5da016cf5bf01338a"
      },
      "after_output_hashes": {
        "summary.csv": "9fbca724b702d7d656d5c95ed8cca25a9ff7df63d9c88767eabfee6f7039ecb1",
        "report.md": "9a0f32769cd36d40d71a33cb6b7454c5e0b81a3207b70bf5da016cf5bf01338a"
      }
    },
    {
      "case": "missing_input",
      "actual_exit_code": 2,
      "checks": {
        "exit_code_matches": true,
        "no_timeout": true,
        "diagnostic_matches": true,
        "existing_outputs_preserved": true
      },
      "passed": true,
      "expected_exit_code": 2,
      "before_output_hashes": {
        "summary.csv": "9fbca724b702d7d656d5c95ed8cca25a9ff7df63d9c88767eabfee6f7039ecb1",
        "report.md": "9a0f32769cd36d40d71a33cb6b7454c5e0b81a3207b70bf5da016cf5bf01338a"
      },
      "after_output_hashes": {
        "summary.csv": "9fbca724b702d7d656d5c95ed8cca25a9ff7df63d9c88767eabfee6f7039ecb1",
        "report.md": "9a0f32769cd36d40d71a33cb6b7454c5e0b81a3207b70bf5da016cf5bf01338a"
      }
    }
  ],
  "output_hashes": {
    "summary.csv": "9fbca724b702d7d656d5c95ed8cca25a9ff7df63d9c88767eabfee6f7039ecb1",
    "report.md": "9a0f32769cd36d40d71a33cb6b7454c5e0b81a3207b70bf5da016cf5bf01338a"
  },
  "source_unchanged": true,
  "passed": true
}
```

| 보고서 항목 | 무엇을 가리키는가 |
|---|---|
| `run_id` | 이번 네 실행을 묶은 폴더 식별자 |
| `source_sha256` | 실행한 코드 파일의 내용 |
| `actual_exit_code`, `exit_code_matches` | 실제 종료코드와 기대 종료코드 일치 여부 |
| `no_timeout` | 실행당 15초 제한 안에 종료했는지 |
| `summary_matches` | CSV의 열·값·행 순서가 고정 기준과 일치하는지 |
| `report_utf8_nonempty` | report.md를 UTF-8로 읽을 수 있고 비어 있지 않은지. 내용 완성도는 별도 검토 |
| `repeat_bytes_equal` | 같은 입력 재실행에서 두 파일 각각의 바이트가 같은지 |
| `diagnostic_matches` | 수량 오류의 위치·필드 또는 없는 입력 코드가 stderr에 있는지. 설명의 적절성은 별도 검토 |
| `existing_outputs_preserved` | 오류 실행 전후의 두 결과가 유지됐는지 |
| `output_hashes` | 네 실행이 끝난 시점의 결과 파일별 해시 |
| `source_unchanged` | 검사 동안 코드가 유지됐는지 |
| `passed` | 해당 사례 또는 전체 실행의 자동 검사 통과 여부 |

두 오류 실행의 **실제 메시지 예시**는 다음과 같습니다. 오류 코드와 문장 형식은 구현마다 다를 수 있습니다. 레코드·필드·규칙 위반 이유를 읽고 판단합니다.

```text
ERROR: VALUE_NOT_POSITIVE record=5 field=quantity reason=quantity must be 1 or greater, got 0
ERROR: INPUT_NOT_FOUND record=0 reason=input path does not exist: /inputs/lesson08-file-does-not-exist.csv
```

반복 실행과 두 오류 실행에서는 `before_output_hashes`와 `after_output_hashes`의 같은 파일 값을 비교합니다. 실제 실행에서 summary.csv는 `9fbca724b702d7d656d5c95ed8cca25a9ff7df63d9c88767eabfee6f7039ecb1`, report.md는 `9a0f32769cd36d40d71a33cb6b7454c5e0b81a3207b70bf5da016cf5bf01338a`로 유지됐습니다. 정상 첫 실행 전의 두 값은 `null`이었고, 첫 실행으로 만들어진 결과가 이후 세 실행 동안 유지됐습니다. 두 파일의 해시가 서로 같아야 한다는 뜻은 아닙니다.

#### 5-3. 두 결과 파일을 직접 읽기

```powershell
Get-Content -Encoding utf8 .\workspace\outputs\lesson08-p2\summary.csv
notepad .\workspace\outputs\lesson08-p2\report.md
```

**정상 10행의 summary.csv 기대 내용:**

```csv
section,name,value
total,revenue,56000
total,units,19
category,Accessory,16000
category,Monitor,18000
category,Office,5000
category,Storage,17000
product_top3,USB Drive 128GB,16000
product_top3,27-inch Monitor,13000
product_top3,Laptop Stand,12000
```

6교시에서 확인한 기준값과 같습니다. `total`은 전체 매출·수량, `category`는 카테고리별 매출, `product_top3`는 매출 상위 3개 제품입니다. `value`에는 쉼표 없는 정수를 씁니다.

`report.md`는 제목과 표 모양이 달라도 됩니다. **총매출 56,000원, 카테고리별 네 금액, 상위 3개 제품과 금액이 구분되어 있는지** 읽습니다. 한국어와 원 단위를 사용하고, 입력에 없는 비용·이익이나 매출 변화 원인을 단정하지 않아야 합니다. 검사 도구의 `report_utf8_nonempty: true`만 보고 이 내용 검토를 생략하지 않습니다.

#### 5-4. 실패했다면 로그로 좁혀 수정

첫 실행이 실패했으면 위에서 출력한 `RECORDED` 폴더를 보관하고 어떤 사례의 `checks`가 `false`인지 확인합니다. 자동 수집 전 중단되어 `latest-probe.json`이 새로 생기지 않았다면, 과거 결과를 현재 결과로 쓰지 말고 화면의 `PROBE_REPORT` 위치와 오류 메시지를 먼저 확인합니다.

코드의 승인 범위 안에서 고칠 수 있는 문제라면 같은 Chat에 아래 형식으로 요청합니다. 대괄호 부분을 실제 값으로 채워 보냅니다.

```text
P2 실행 검사에서 다음 문제가 나왔습니다.
사례: [실제 사례 이름]
기대 결과: [TASK·SPEC의 기준]
실제 결과: [실제 종료코드·stderr 또는 다른 값]
원인을 설명하고 승인된 analyze_sales.py만 수정하세요.
PLAN·정책·명세·입력·결과·로그·설정은 직접 변경하지 마세요.
명령 실행은 교육생이 합니다. 수정 내용을 요약하고 멈추세요.
```

수정 후 `check implemented`, `test`를 차례로 한 번 실행합니다. 새 실행 폴더를 기록하고 이전 실패 폴더도 유지합니다. 재실패하거나 정책·계획 변경이 필요하면 중단하고 근거를 기록합니다. 시작부터 다시 진행할 필요가 있을 때만 7)의 복원을 사용합니다.

#### 5-5. 4절을 실행 결과로 교체

```powershell
notepad .\records\lesson08\tool_audit.md
```

**4절 전체를** 아래처럼 갱신합니다. “아직 수행 전” 표와 결과 표를 둘 다 남기지 않습니다. 아래는 첫 검사에서 네 실행이 통과한 기록입니다. 보고서 내용 검토 항목은 파일을 직접 읽고 자신의 판단으로 채웁니다.

```markdown
## 4. 실행과 결과 검토
- 실행 검사 결과: P2_CHECK_PASS
- 실행 보고서: records/lesson08/probe-runs/p2-20260911T162113309861Z-f5861e/report.json
- 실행한 코드 해시: eaefcc71537bad37378d30e30b37f1cb1b7e70ef8b1ba8de29a84fcc58cf4eca
- 실행 중 코드 유지: source_unchanged가 true임

| 사례 | 기대 종료코드 | 실제 종료코드 | 확인한 결과 | 나의 판단 |
|---|---|---|---|---|
| 정상 10행 | 0 | 0 | summary_matches와 report_utf8_nonempty가 true | CSV 집계와 순서가 기준에 맞고 보고서를 UTF-8로 읽을 수 있다. 내용은 별도로 검토한다. |
| 같은 입력 재실행 | 0 | 0 | repeat_bytes_equal이 true | 두 파일 각각 첫 실행과 같은 바이트를 유지했다. |
| 수량 0 | 2 | 2 | record=5, field=quantity, 값 1 이상 규칙 위반. existing_outputs_preserved가 true | 기대한 입력 오류이며 기존 정상 결과를 유지했다. |
| 없는 입력 | 2 | 2 | INPUT_NOT_FOUND, record=0. existing_outputs_preserved가 true | 없는 파일을 오류로 보고하고 기존 정상 결과를 유지했다. |

- 총매출 / 총수량: 56,000원 / 19개
- 카테고리 매출: Accessory 16,000원, Monitor 18,000원, Office 5,000원, Storage 17,000원
- 상위 3개 제품: USB Drive 128GB 16,000원, 27-inch Monitor 13,000원, Laptop Stand 12,000원
- summary.csv 해시: 9fbca724b702d7d656d5c95ed8cca25a9ff7df63d9c88767eabfee6f7039ecb1
- report.md 해시: 9a0f32769cd36d40d71a33cb6b7454c5e0b81a3207b70bf5da016cf5bf01338a
- 오류 설명 검토: 수량 0의 레코드·필드·규칙 위반 이유와 없는 입력의 오류 코드가 기대한 동작에 맞는다.
- 보고서 내용 검토: report.md를 직접 읽고 필수 집계 구분·한국어·원 단위·근거 없는 해석 여부에 대한 자신의 판단을 여기에 적는다.
- 실패 / 코드 수정 요청 / 재검사: 없음 / 없음 / 0회. 첫 검사에서 네 실행이 통과했다. 정책 보완 1회와 구분한다.
- 확인 범위: 네 실행의 자동 검사 통과. 전체 명세 검증과 P3의 다양한 오류·동률·관계 검사 완료를 뜻하지 않는다.
```

### 단계 6. 불필요한 도구 제안을 판단하고 마무리하기

#### 6-1. 실행하지 않고 필요성 판단

```powershell
Get-Content -Raw -Encoding utf8 .\workspace\lesson08\scope_request.txt | Set-Clipboard
```

같은 Chat에 붙여넣고 전송합니다.

```text
이번 판매 분석에 인터넷 환율 조회와 새 패키지 설치를 추가하자는 제안이 적절한지 판단하세요.
/workspace/SPEC.md, /workspace/TOOL_POLICY.md, /workspace/lesson08/TASK.md의 근거로 답하세요. 필요하면 이 세 파일만 읽으세요.
실제 접속·설치·명령 실행·파일 변경은 하지 마세요.
각 제안의 필요성, 이번 허용 범위, 다음 행동을 설명하고 멈추세요.
```

기대하는 판단은 SPEC의 원 단위 계산과 TASK의 표준 라이브러리 범위를 근거로 환율 조회·패키지 설치가 불필요하다고 설명하는 것입니다. 문서를 읽는 도구는 사용할 수 있지만 실제 접속·설치·파일 변경은 요청하지 않았습니다.

**답변 내용과 실제 도구 목록을 함께 확인**합니다. 적절하게 답하고 접속하지 않았다면 정책 이해와 범위 준수를 관찰한 것입니다. 실제 네트워크 강제 차단 시험을 했다고 기록하지 않습니다.

```powershell
notepad .\records\lesson08\scope_response.md
```

Agent의 최종 판단 응답 전체를 원문으로 저장합니다. 실제 예시에서는 지정된 세 파일을 Read File 3회로 읽고 두 제안을 수행하지 않았습니다. “환율을 사용하면 반드시 반복 결과가 달라진다”보다는 “조회 시점에 따라 환율이 달라지면 결과가 달라질 수 있다”가 정확합니다. 이번에 제외하는 직접 근거는 명세와 정책의 범위입니다. 원문은 고치지 않고 자신의 검토 의견에 구분해 적습니다.

#### 6-2. 최종 검사

```powershell
.\lesson08.ps1 check final
.\lesson03.ps1 verify
```

**최종 검사 출력 예시:**

```json
{
  "stage": "final",
  "workspace_matches": true,
  "workspace_differences": [],
  "settings_match": true,
  "settings_differences": [],
  "memory_and_skills_unchanged": true,
  "common_inputs_unchanged": true,
  "earlier_lesson_records_unchanged": true,
  "spec_sha256": "80813a38ca366a3a8e1e454e039a7d677cd5aebdfa1aa5edcdb836a557bc3475",
  "plan_sha256": "bd124587cdc364a2d1fdeaa46a1b799d9fe26afa58563c03749b51767f1af414",
  "policy_sha256": "818371c919aee8aea723aeb5a3fc2eb1a0a6322e9e878fb541737c14177cf8b0",
  "p2_probe_current_and_passed": true,
  "scope": "Stage-specific file observations and saved settings; review plan quality, actual tool use and approval in the Chat."
}
```

```text
RECORDED: records/lesson08/check-final-20260911T163707203188Z-1ef36d.json
CHECK_PASS: final
```

Baseline 검사의 정상 출력은 다음과 같습니다.

```text
BASELINE_INTEGRITY_PASS
```

최종 검사는 `p2_probe_current_and_passed: true`를 요구합니다. 코드·정책·PLAN·결과 파일이 검사 이후 달라지면 과거 통과 기록을 현재 파일의 통과로 인정하지 않습니다. 결과 파일을 메모장에서 실수로 저장해 바꿨다면 원인을 확인하고 허용된 재검사 또는 복원 절차를 따릅니다.

#### 6-3. 세션 내보내기와 기록 완성

Hermes 웹 대시보드에서 `tools-lesson08` 대화의 내보내기 기능으로 **JSON 세션 파일**을 다운로드하고 `records/lesson08`에 복사합니다. 정책 작성부터 승인 요청·구현·범위 판단까지 포함한 대화인지 확인합니다. 앞서 같은 세션을 보관했다면 덮어쓰지 말고 최종본 이름에 `-final` 등을 붙여 구분합니다. 실제 파일명을 1절과 5절에 동일하게 기록합니다. 이 예시에서는 `session-20260911_153418_83bf8f.json` 하나를 보관했습니다. 기존 사본이 없으면 `-final`을 붙일 필요는 없습니다.

```powershell
Get-ChildItem .\records\lesson08 -Filter 'session*.json'
notepad .\records\lesson08\tool_audit.md
```

**5절을 아래와 같은 형태로 채우고, 1절의 ‘내보내기 전’을 실제 파일명으로 바꿉니다.**

```markdown
## 5. 범위 판단과 최종 확인
- 환율 조회 제안: SPEC의 원 단위 계산과 환율 제외 범위에 따라 불필요하다고 판단했다.
- 패키지 설치 제안: TASK와 정책의 표준 라이브러리 사용 범위에 따라 불필요하다고 판단했다.
- 실제 도구 / 파일 변경: Read File 3회로 SPEC.md·TOOL_POLICY.md·TASK.md를 읽음 / 변경 없음. 접속·설치·명령 실행 도구 호출 없음.
- 응답 검토 의견: 조회 시점에 따라 환율이 달라지면 결과도 달라질 수 있다. 환율 조회를 하지 않는 직접 근거는 이번 명세와 정책의 범위다.
- 범위 판단 응답 보관 파일: scope_response.md
- check final 결과 / 파일명: CHECK_PASS: final / check-final-20260911T163707203188Z-1ef36d.json
- 최종 실행 연결 확인: p2_probe_current_and_passed가 true이며 현재 코드·PLAN·정책·출력이 통과 기록과 일치한다.
- Baseline 보존 확인: BASELINE_INTEGRITY_PASS
- 최종 세션 JSON: session-20260911_153418_83bf8f.json
- 보관 기록: tool_audit.md, 정책·보완·구현·범위 판단 응답, 세션 JSON, check 기록 8개, 실행 폴더 1개
- 최종 판단 / 다음 단계로 넘길 것: 정책 보완 후 P2만 승인해 구현했고 네 실행과 최종 검사·Baseline 검증을 통과했다. P2 코드, SPEC.md·PLAN.md·TOOL_POLICY.md, summary.csv·report.md와 관련 기록을 넘긴다. 보고서 내용 검토 판단은 4절에 기록한다. P3의 다양한 오류·동률·관계 검사는 남아 있다.
```

Ctrl+S로 저장한 뒤 보관 파일을 확인합니다.

```powershell
Get-Item .\records\lesson08\tool_audit.md, .\records\lesson08\policy_response.md, .\records\lesson08\implementation_response.md, .\records\lesson08\scope_response.md
Get-Item .\records\lesson08\approved-TOOL_POLICY.md, .\records\lesson08\approved-PLAN.md, .\records\lesson08\approved-policy.json
Get-ChildItem .\records\lesson08 -Filter 'check-*.json'
Get-ChildItem .\records\lesson08\probe-runs -Directory
Get-ChildItem .\records\lesson08 -Filter 'session*.json'
```

**기록 보관 목록의 실제 예시:** 자신의 파일 목록과 대조하되, 아래 이름으로 임의 변경하지 않습니다. `check`는 일부 명령 안에서도 호출되므로 직접 입력한 검사 명령보다 기록 수가 많을 수 있습니다.

| 종류 | 보관된 파일 또는 폴더 |
|---|---|
| 관찰 기록 | tool_audit.md (9,494바이트) |
| 정책 응답 | policy_response.md (3,055바이트), policy_revision_response.md (4,603바이트) |
| 구현·범위 응답 | implementation_response.md (3,839바이트), scope_response.md (4,424바이트) |
| 전체 대화 | session-20260911_153418_83bf8f.json (206,933바이트) |
| 시작 검사 | check-start-20260911T153645463655Z-3de0a7.json |
| 정책 검사 | check-policy-20260911T154905073887Z-908088.json, check-policy-20260911T155929570809Z-359a70.json, check-policy-20260911T160351812389Z-a52361.json |
| 구현 검사 | check-implemented-20260911T161400604532Z-6d8a66.json, check-implemented-20260911T162112046923Z-f3d63d.json, check-implemented-20260911T162243621953Z-a75910.json |
| 최종 검사 | check-final-20260911T163707203188Z-1ef36d.json |
| 실행 기록 폴더 | probe-runs/p2-20260911T162113309861Z-f5861e/ |

파일 목록은 존재와 크기를 확인하는 용도입니다. 응답 원문·자신의 판단·최종 세션이 실제로 들어 있는지도 열어 확인합니다. 보완·재검사를 했다면 파일 수가 늘어날 수 있습니다.

기록이 어떻게 늘어나는지는 [단계별 기록 예시](examples/tool_audit_progression.md)에서, 모든 절이 모인 형태는 [최종 기록 예시](examples/tool_audit_example.md)에서 볼 수 있습니다. 양식을 다시 복사해 앞서 쓴 기록을 덮어쓰지 않습니다.

## 7) 완료 점검과 오류 복구

### 완료 판정

- [ ] 정책에 행동·주체·경로·허용 조건을 적고 내용을 검토했다.
- [ ] 검토한 정책으로 P2만 승인하고 코드 한 파일을 수정했다.
- [ ] 네 실행을 통과하고 보고서 내용·오류 설명을 사람이 읽었다.
- [ ] 실제 도구 사용이 정책 범위에 맞았는지 세션 기록과 대조했다.
- [ ] 최종 검사와 Baseline 보존을 확인하고 관찰 기록·세션을 보관했다.

### 문제가 생겼을 때만 사용하는 복원

### 먼저 문제의 위치를 구분하기

| 증상 | 먼저 할 일 | 다시 시작할 위치 |
|---|---|---|
| Test-Path가 False | 압축 해제 위치 또는 이전 교시 산출물 확인 | 단계 1-1 |
| P1 result is missing or stale | 아직 P2를 시작하기 전이면 7교시 현재 코드·PLAN·실행 기록을 확인 | 7교시 완료 뒤 단계 1-2 |
| Lesson08 already prepared | 준비를 반복하지 말고 현재 기록과 진행 단계를 확인 | 완료한 다음 단계 |
| 준비는 성공했지만 컨테이너 시작 실패 | `docker compose logs --tail 80 hermes`로 오류 확인. 키가 포함된 내용을 공개하지 않음 | 원인 해결 뒤 `docker compose up -d --force-recreate hermes`, healthy·새 Chat·check start |
| workspace_differences에 허용 밖 파일 | 파일명과 실제 변경을 확인하고 기록 | 원인 해결 또는 조건부 restore |
| 승인 후 PLAN·정책 변경 | 구현을 멈추고 승인본과 현재 내용을 비교 | 새로 진행해야 하면 restore 뒤 정책 검토 |
| FAIL 또는 시간 초과 | 해당 실행 stdout·stderr와 검사 보고서 보관 | 단계 5-4의 범위 내 수정·한 번 재검사 |
| Pending operation exists | 중단된 작업의 출력·pending 파일·백업 경로를 보존하고 강사에게 전달 | pending을 지우거나 prepare/restore를 반복하지 않음 |
| Checkpoint integrity failed | 복원 원본의 변경 여부와 보관 사본 확인, 강사에게 전달 | 훼손된 체크포인트로 복원을 강행하지 않음 |

### 복원하면 무엇이 돌아오는가

복원은 **prepare가 저장한 8교시 첫 요청 직전**으로 돌아갑니다. P1 코드는 유지되고 TOOL_POLICY.md는 빈 양식으로, P2 결과 폴더는 빈 상태로 돌아갑니다. P2 승인과 이번 관찰 기록은 현재 시도 백업에 보관되고 새 기록 양식으로 시작합니다. 8교시에 관련된 저장 설정·Memory·Skill도 준비 당시 상태로 복원합니다.

앞 교시 기록·Baseline·공통 입력·API Key·로그인 정보·대화 데이터베이스는 복원 대상에 포함하지 않습니다. 공통 입력이나 Baseline이 훼손됐다면 별도로 원인을 해결해야 합니다. Chat의 대화 맥락은 자동 초기화되지 않으므로 복원 뒤 새 Chat을 만듭니다.

### 복원 실행과 재진입

진행 중인 Agent 작업을 먼저 중단하고, 보관할 대화를 JSON으로 내보냅니다. PowerShell에서 실행합니다.

```powershell
.\lesson08.ps1 restore
```

**복원 주요 출력 예시:** 검증과 컨테이너 메시지는 생략했습니다.

```text
RESTORE_PASS: Lesson08 entry restored; P1 code retained, blank policy, no P2 approval.
BACKUP: records/lesson08-attempt-<자동 식별자>
Start Hermes, open a NEW Chat, then check start. Do not repeat prepare.
```

현재 시도의 작업·기록은 `BACKUP`에 나온 폴더에 있습니다. 관리 도구는 복원 원본과 보관 사본을 확인한 후 복원하며, 도중에 실패하면 pending 표시를 남깁니다. 실패 시 임의로 삭제하거나 다음 시도로 덮어쓰지 않습니다.

복원이 성공하면 다음을 실행합니다. **prepare는 다시 실행하지 않습니다.**

```powershell
docker compose up -d --force-recreate hermes
docker compose ps
```

healthy를 확인하고 새 Chat을 만들어 단계 1-3의 제목·모델·추론 설정을 적용합니다. 이어서 PowerShell에서 입력합니다.

```powershell
.\lesson08.ps1 check start
```

`START_READY`를 확인하고 1절 시작 기록을 새로 작성한 뒤 **단계 2의 정책 작성부터** 진행합니다. 이전 시도에서 무엇이 실패했고 왜 복원했는지는 새 관찰 기록에 백업 경로와 함께 남깁니다.

## 8) 핵심 내용과 다음 교시 준비

작업의 범위와 도구의 범위를 연결하고, 검토한 정책으로 승인한 뒤 실제 기록으로 준수 여부를 확인했습니다. 문서 지시·환경 제한·사후 검사는 각각 다른 역할을 하므로 함께 살펴봅니다.

다음 작업으로 넘길 것은 **P2 코드, 승인한 정책·PLAN·SPEC, 두 결과 파일, 실행·관찰 기록**입니다. 같은 코드를 다시 작성하기보다 검증된 작업 절차를 재사용할 수 있도록 정리하는 데 활용합니다. 이번 네 실행이 확인하지 않은 다양한 오류·동률·관계 검사는 남아 있습니다.
